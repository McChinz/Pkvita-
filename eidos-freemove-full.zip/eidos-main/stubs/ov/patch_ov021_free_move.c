/*
 * patches: src/game/ov021/field_player_grid.c FIELD_PLAYER_GRID_Move FIELD_PLAYER_GRID_StopForcedMove FIELD_PLAYER_GRID_ResetHold
 * keeps declarations
 *
 * 360-degree analog movement on the field.
 *
 * The game moves the player one tile at a time: a key picks one of four
 * directions, an animation command walks the model one tile in 8 frames
 * (4 running, 2 on the bike), and everything else (doors, warps, wild
 * grass, trainers, scripts) runs off the tile the player ends on.
 *
 * Here the left stick moves the model freely, in any direction and at any
 * speed the push gives.  The game still sees a tile: the tile under the
 * model's centre is kept as the model's grid position, and when the centre
 * crosses into a new tile the step is reported exactly as a finished grid
 * step is (the core's step kind and phase), so the field's event check
 * runs its per-step checks: position scripts, warps, wild encounters, egg
 * steps, the step counter, Pokemon friendship.
 *
 * Collision: the player is a box FM_RADIUS wide on each side of its centre.
 * A tile the box would newly overlap must pass the same check the grid
 * walk uses (FLDMMDL_MOVE_HitCheckMoveCurrent: blocked tiles, heights,
 * people, the map's edge).  X and Z move separately, so the player slides
 * along walls, and a push into a wall next to an opening nudges the player
 * toward it so doorways and one-tile paths are easy to enter.
 *
 * What stays on the game's grid code:
 *   - the d-pad (FM_DPAD_CLASSIC), so tile-precise walking is still there
 *   - surfing and diving
 *   - ledges: a push into a ledge snaps to the tile and lets the game jump
 *   - ice, spinner and conveyor tiles, hop tiles, the hold before a hop
 *   - any animation command already running (scripts, jumps)
 *
 * When an event starts (a script, a trainer, a battle, a warp), the player
 * is put back on the centre of its tile, so cutscenes that walk the player
 * tile by tile line up.  Opening the menu leaves the player where it is.
 *
 * Analog input: sdk/free_move.c.
 */

typedef unsigned int u32;
typedef unsigned short u16;
typedef short s16;

typedef struct FmVec {
    int x;
    int y;
    int z;
} FmVec;

struct Mmdl;
struct FieldPlayerCore;
struct FieldMap;

/* The grid part of the field player: field_player_grid_types.h's layout. */
typedef struct FieldPlayerGrid {
    u32 state;
    u32 lastResult;
    u32 flags;
    struct FieldPlayerCore *core;
    struct FieldMap *fieldMap;
    u16 holdFrames;
    unsigned char holdEffectPending;
    unsigned char pad_17;
    u16 soundId;
    u16 soundRepeat;
    u32 hopLanded;
} FieldPlayerGrid;

/* field_player_grid_types.h's FieldPlayerGridMoveRequest. */
typedef struct FmMoveRequest {
    u32 keyTrigger;
    u32 keyHeld;
    u16 dir;
    u32 dashAllowed;
    u32 isDash;
} FmMoveRequest;

/* ------------------------------------------------------------------ */
/* Tuning                                                              */
/* ------------------------------------------------------------------ */

/* Half the player's collision box, in position units (one tile 0x10000). */
#define FM_RADIUS            0x4000
/* Speeds in position units a frame at full push (the game's own: one
 * tile in 8 frames walking, 4 running, 2 on the bike). */
#define FM_SPEED_WALK        0x2000
#define FM_SPEED_RUN         0x4000
#define FM_SPEED_CYCLE       0x8000
/* Slowest walk, as a share of FM_SPEED_WALK in 1/4096 (a light push). */
#define FM_MIN_WALK_SHARE    1400
/* Below this push the stick only turns the player (1/4096 units). */
#define FM_TURN_ONLY_PUSH    500
/* A full push runs without B (0 off, 1 on). */
#define FM_AUTORUN           0
/* The d-pad walks tile by tile, as the game does (0: the d-pad moves
 * freely in 8 directions as well). */
#define FM_DPAD_CLASSIC      1
/* How far the wall-slide nudge reaches: within this of an opening's
 * centre line the player is steered into it. */
#define FM_NUDGE_REACH       0x6000
/* Frames between entering a tile and the end-of-step ground effects. */
#define FM_END_DELAY         4

/* ------------------------------------------------------------------ */
/* The game's names                                                    */
/* ------------------------------------------------------------------ */

#define FM_DIR_UP     0
#define FM_DIR_DOWN   1
#define FM_DIR_LEFT   2
#define FM_DIR_RIGHT  3
#define FM_DIR_NONE   9

#define FM_KEY_B      0x0002
#define FM_KEY_RIGHT  0x0010
#define FM_KEY_LEFT   0x0020
#define FM_KEY_UP     0x0040
#define FM_KEY_DOWN   0x0080
#define FM_KEY_DPAD   0x00F0

#define FM_FORM_NORMAL 0
#define FM_FORM_CYCLE  1

#define FM_RESULT_WALK 2

#define FM_DRAWSTA_STOP     0
#define FM_DRAWSTA_WALK_16F 2
#define FM_DRAWSTA_WALK_8F  3
#define FM_DRAWSTA_WALK_4F  4
#define FM_DRAWSTA_WALK_2F  5

#define FM_HIT_OBJECT 0x04

#define FM_STEP_KIND_NONE 0
#define FM_STEP_KIND_WALK 1

/* sdk/free_move.c */
extern int eidos_free_move_stick(int *dx, int *dz);

/* ov010 fldmmdl.c / fldmmdl_move.c */
extern int FLDMMDL_CheckPossibleAcmd(struct Mmdl *mmdl);
extern void FLDMMDL_SetDrawStatus(struct Mmdl *mmdl, u16 drawStatus);
extern u16 FLDMMDL_GetDirDisp(struct Mmdl *mmdl);
extern void FLDMMDL_SetDirAll(struct Mmdl *mmdl, u16 dir);
extern short FLDMMDL_GetGridNowX(struct Mmdl *mmdl);
extern short FLDMMDL_GetGridNowY(struct Mmdl *mmdl);
extern short FLDMMDL_GetGridNowZ(struct Mmdl *mmdl);
extern void FLDMMDL_SetGridNowX(struct Mmdl *mmdl, short x);
extern void FLDMMDL_SetGridNowZ(struct Mmdl *mmdl, int z);
extern void FLDMMDL_GetPos(const struct Mmdl *mmdl, FmVec *out);
extern void FLDMMDL_SetPos(struct Mmdl *mmdl, const FmVec *pos);
extern u32 FLDMMDL_MOVE_HitCheckMoveCurrent(struct Mmdl *mmdl, s16 gridX, s16 height, int gridZ, u16 kind);
extern int FLDMMDL_MOVE_GetMapAttr(struct Mmdl *mmdl, FmVec *pos, u32 *outAttr);
extern int FLDMMDL_MOVE_UpdateHeight(struct Mmdl *mmdl);
extern void FLDMMDL_MOVE_UpdateOldGridPos(struct Mmdl *mmdl);
extern void FLDMMDL_MOVE_AttrProcMoveStartSecond(struct Mmdl *mmdl);
extern void FLDMMDL_MOVE_AttrProcMoveEnd(struct Mmdl *mmdl);

/* ov021 map_attr.c */
extern u16 MAP_ATTR_GetTerrainId(u32 attr);
extern u16 MAP_ATTR_GetFlags(u32 attr);
extern int MAP_ATTR_IsLedgeNorth(u16 terrainId);
extern int MAP_ATTR_IsLedgeSouth(u16 terrainId);
extern int MAP_ATTR_IsLedgeWest(u16 terrainId);
extern int MAP_ATTR_IsLedgeEast(u16 terrainId);
extern int MAP_ATTR_IsNoDash(u16 terrainId);

/* ov021 field_player_core.c */
extern struct Mmdl *FIELD_PLAYER_CORE_GetMmdl(struct FieldPlayerCore *core);
extern void FIELD_PLAYER_CORE_SetStepKind(struct FieldPlayerCore *core, u32 stepKind);
extern void FIELD_PLAYER_CORE_SetStepPhase(struct FieldPlayerCore *core, u32 stepPhase);
extern u32 FIELD_PLAYER_CORE_GetStepPhase(struct FieldPlayerCore *core);
extern u32 FIELD_PLAYER_CORE_GetFormCode(struct FieldPlayerCore *core);
extern int FIELD_PLAYER_CORE_StepFormChange(struct FieldPlayerCore *core);
extern u16 FIELD_PLAYER_CORE_ChooseMoveDirFromKeys(struct FieldPlayerCore *core, u32 keys);

/* ov021 field_player_grid.c: the rest of the unit */
extern int FIELD_PLAYER_GRID_CanStartMove(FieldPlayerGrid *grid, u32 dir);
extern int FIELD_PLAYER_GRID_RunForcedMove(FieldPlayerGrid *grid, u32 dir, int skip);
extern int FIELD_PLAYER_GRID_GetMoveResult(FieldPlayerGrid *grid, FmMoveRequest *request);
extern void FIELD_PLAYER_GRID_BeginMove(FieldPlayerGrid *grid, int result, const FmMoveRequest *request);
extern void FIELD_PLAYER_GRID_ApplyMoveResult(FieldPlayerGrid *grid, u32 result, FmMoveRequest *request);
extern void FIELD_PLAYER_GRID_PlayStepSound(FieldPlayerGrid *grid, int result, int dir);
extern int FIELD_PLAYER_GRID_IsOnForcedMoveTile(FieldPlayerGrid *grid);
extern int FIELD_PLAYER_GRID_IsForcedMoveFlagSet(FieldPlayerGrid *grid);
extern int FIELD_PLAYER_GRID_IsHopFlagSet(FieldPlayerGrid *grid);
extern int FIELD_PLAYER_GRID_IsOnHopStartTile(FieldPlayerGrid *grid);
extern int FIELD_PLAYER_GRID_IsHopping(FieldPlayerGrid *grid);
extern int FIELD_PLAYER_GRID_IsHoldFlagSet(FieldPlayerGrid *grid);
extern void FIELD_PLAYER_GRID_EndHold(FieldPlayerGrid *grid);
extern void FIELD_PLAYER_GRID_ReleaseForcedMove(FieldPlayerGrid *grid);
extern int FIELD_PLAYER_GRID_IsTileBlockingCycle(int attrKind);

/* ------------------------------------------------------------------ */
/* State                                                               */
/* ------------------------------------------------------------------ */

static struct {
    FieldPlayerGrid *grid;  /* the grid this state belongs to (a new map makes a new one) */
    int moving;             /* the walk animation is on */
    int endDelay;           /* frames until the end-of-step effects, 0 none pending */
    int menuRequest;        /* the event that is starting is the menu */
} fm;

static int fm_abs(int v)
{
    return v < 0 ? -v : v;
}

/* ------------------------------------------------------------------ */
/* The game's own grid walk (the original FIELD_PLAYER_GRID_Move)      */
/* ------------------------------------------------------------------ */

static void fm_grid_move(FieldPlayerGrid *grid, u32 keyTrigger, u32 keyHeld, u32 dashAllowed)
{
    FmMoveRequest request;
    u32 dir;
    int result;

    dir = FIELD_PLAYER_CORE_ChooseMoveDirFromKeys(grid->core, keyHeld);
    if (FIELD_PLAYER_GRID_CanStartMove(grid, dir) == 1) {
        FIELD_PLAYER_CORE_StepFormChange(grid->core);
        if (FIELD_PLAYER_GRID_RunForcedMove(grid, dir, 0) == 0) {
            request.keyTrigger = keyTrigger;
            request.keyHeld = keyHeld;
            request.dir = (u16)dir;
            request.dashAllowed = dashAllowed;
            request.isDash = 0;
            result = FIELD_PLAYER_GRID_GetMoveResult(grid, &request);
            FIELD_PLAYER_GRID_BeginMove(grid, result, &request);
            FIELD_PLAYER_GRID_ApplyMoveResult(grid, (u32)result, &request);
            FIELD_PLAYER_GRID_PlayStepSound(grid, result, (int)dir);
        }
    }
}

/* ------------------------------------------------------------------ */
/* Helpers                                                             */
/* ------------------------------------------------------------------ */

static int fm_is_centred(struct Mmdl *mmdl)
{
    FmVec pos;

    FLDMMDL_GetPos(mmdl, &pos);
    return (pos.x & 0xFFFF) == 0x8000 && (pos.z & 0xFFFF) == 0x8000
        && (pos.x >> 16) == FLDMMDL_GetGridNowX(mmdl)
        && (pos.z >> 16) == FLDMMDL_GetGridNowZ(mmdl);
}

/* Ends a pending step's ground effects (grass settling, footprints). */
static void fm_flush_step_end(struct Mmdl *mmdl)
{
    if (fm.endDelay != 0) {
        fm.endDelay = 0;
        FLDMMDL_MOVE_AttrProcMoveEnd(mmdl);
    }
}

static void fm_stop_anim(struct FieldPlayerCore *core, struct Mmdl *mmdl)
{
    fm_flush_step_end(mmdl);
    if (fm.moving) {
        fm.moving = 0;
        FLDMMDL_SetDrawStatus(mmdl, FM_DRAWSTA_STOP);
    }
    /* A step reported this frame (phase 2) must still reach the event
     * check, which turns it into 3; otherwise no step is in flight. */
    if (FIELD_PLAYER_CORE_GetStepPhase(core) == 0) {
        FIELD_PLAYER_CORE_SetStepKind(core, FM_STEP_KIND_NONE);
    }
}

/* Puts the model back on the centre of the tile the game thinks it is on. */
static void fm_snap(struct Mmdl *mmdl)
{
    FmVec pos;

    if (fm_is_centred(mmdl)) {
        return;
    }
    FLDMMDL_GetPos(mmdl, &pos);
    pos.x = ((int)FLDMMDL_GetGridNowX(mmdl) << 16) + 0x8000;
    pos.z = ((int)FLDMMDL_GetGridNowZ(mmdl) << 16) + 0x8000;
    FLDMMDL_SetPos(mmdl, &pos);
    FLDMMDL_MOVE_UpdateHeight(mmdl);
}

static u32 fm_tile_attr(struct Mmdl *mmdl, int tx, int tz, int y, u32 *attr)
{
    FmVec c;

    c.x = (tx << 16) + 0x8000;
    c.y = y;
    c.z = (tz << 16) + 0x8000;
    return (u32)FLDMMDL_MOVE_GetMapAttr(mmdl, &c, attr);
}

/* Whether the player may stand on tile tx, tz, entering it along dir. */
static int fm_tile_free(struct Mmdl *mmdl, u32 form, int tx, int tz, int dir, int y)
{
    u32 hit;
    u32 attr;

    hit = FLDMMDL_MOVE_HitCheckMoveCurrent(mmdl, (s16)tx, FLDMMDL_GetGridNowY(mmdl), tz, (u16)dir);
    if (hit != 0) {
        return 0;
    }
    if (fm_tile_attr(mmdl, tx, tz, y, &attr) != 0) {
        u16 terrain = MAP_ATTR_GetTerrainId(attr);

        /* the grid walk's own extra rule (FIELD_PLAYER_GRID_GetWalkResultOnFoot) */
        if (MAP_ATTR_GetFlags(attr) & 2) {
            return 0;
        }
        if (form == FM_FORM_CYCLE && FIELD_PLAYER_GRID_IsTileBlockingCycle(terrain)) {
            return 0;
        }
    }
    return 1;
}

/* Whether tile tx, tz is a ledge the player jumps down along dir. */
static int fm_is_ledge(struct Mmdl *mmdl, int tx, int tz, int dir, int y)
{
    u32 attr;
    u16 t;

    if (fm_tile_attr(mmdl, tx, tz, y, &attr) == 0) {
        return 0;
    }
    t = MAP_ATTR_GetTerrainId(attr);
    switch (dir) {
    case FM_DIR_UP:    return MAP_ATTR_IsLedgeNorth(t) != 0;
    case FM_DIR_DOWN:  return MAP_ATTR_IsLedgeSouth(t) != 0;
    case FM_DIR_LEFT:  return MAP_ATTR_IsLedgeWest(t) != 0;
    case FM_DIR_RIGHT: return MAP_ATTR_IsLedgeEast(t) != 0;
    }
    return 0;
}

/*
 * Whether the box centred on nx, nz is free.  Tiles the box already
 * overlaps at cx, cz are not checked again (the player is already there),
 * but the tile under the new centre must never hold a person.
 */
static int fm_box_free(struct Mmdl *mmdl, u32 form, int cx, int cz, int nx, int nz, int dir, int y)
{
    int x0 = (nx - FM_RADIUS) >> 16, x1 = (nx + FM_RADIUS - 1) >> 16;
    int z0 = (nz - FM_RADIUS) >> 16, z1 = (nz + FM_RADIUS - 1) >> 16;
    int ox0 = (cx - FM_RADIUS) >> 16, ox1 = (cx + FM_RADIUS - 1) >> 16;
    int oz0 = (cz - FM_RADIUS) >> 16, oz1 = (cz + FM_RADIUS - 1) >> 16;
    int tx, tz;

    for (tz = z0; tz <= z1; tz++) {
        for (tx = x0; tx <= x1; tx++) {
            if (tx >= ox0 && tx <= ox1 && tz >= oz0 && tz <= oz1) {
                continue;
            }
            if (!fm_tile_free(mmdl, form, tx, tz, dir, y)) {
                return 0;
            }
        }
    }
    tx = nx >> 16;
    tz = nz >> 16;
    if (tx != (cx >> 16) || tz != (cz >> 16)) {
        u32 hit = FLDMMDL_MOVE_HitCheckMoveCurrent(mmdl, (s16)tx, FLDMMDL_GetGridNowY(mmdl), tz, (u16)dir);

        if (hit & FM_HIT_OBJECT) {
            return 0;
        }
    }
    return 1;
}

/* The direction to face for a stick vector, keeping the current facing
 * near a diagonal so the model does not flicker between two. */
static u16 fm_facing(int vx, int vz, u16 cur)
{
    int ax = fm_abs(vx), az = fm_abs(vz);
    u16 h = vx > 0 ? FM_DIR_RIGHT : FM_DIR_LEFT;
    u16 v = vz > 0 ? FM_DIR_DOWN : FM_DIR_UP;

    if (cur == h && ax * 5 >= az * 4) {
        return h;
    }
    if (cur == v && az * 5 >= ax * 4) {
        return v;
    }
    return ax > az ? h : v;
}

/*
 * One axis of a move: tries to move the centre by d along x (axis 0) or
 * z (axis 1).  Returns 1 when it moved the full way, 0 when a wall stopped
 * it (the centre is then pushed flush against the wall).
 */
static int fm_move_axis(struct Mmdl *mmdl, u32 form, FmVec *pos, int d, int axis)
{
    int cur = axis == 0 ? pos->x : pos->z;
    int next = cur + d;
    int dir = axis == 0 ? (d > 0 ? FM_DIR_RIGHT : FM_DIR_LEFT) : (d > 0 ? FM_DIR_DOWN : FM_DIR_UP);
    int nx = axis == 0 ? next : pos->x;
    int nz = axis == 0 ? pos->z : next;
    int flush;

    if (d == 0) {
        return 1;
    }
    if (fm_box_free(mmdl, form, pos->x, pos->z, nx, nz, dir, pos->y)) {
        if (axis == 0) {
            pos->x = next;
        } else {
            pos->z = next;
        }
        return 1;
    }
    /* blocked: slide up to the edge of the tiles the box already covers */
    if (d > 0) {
        flush = ((((cur + FM_RADIUS - 1) >> 16) + 1) << 16) - FM_RADIUS;
        if (flush > next) {
            flush = next;
        }
        if (flush < cur) {
            flush = cur;
        }
    } else {
        flush = (((cur - FM_RADIUS) >> 16) << 16) + FM_RADIUS;
        if (flush < next) {
            flush = next;
        }
        if (flush > cur) {
            flush = cur;
        }
    }
    if (axis == 0) {
        pos->x = flush;
    } else {
        pos->z = flush;
    }
    return 0;
}

/*
 * The wall-slide nudge: pushing along one axis into a wall, find the
 * nearest tile row (or column) next to the player where the way ahead is
 * open, and steer the other axis toward its centre line.
 */
static void fm_nudge(struct Mmdl *mmdl, u32 form, FmVec *pos, int d, int axis, int speed)
{
    int dir = axis == 0 ? (d > 0 ? FM_DIR_RIGHT : FM_DIR_LEFT) : (d > 0 ? FM_DIR_DOWN : FM_DIR_UP);
    int push = axis == 0 ? pos->x : pos->z;    /* the axis pushed along */
    int along = axis == 0 ? pos->z : pos->x;   /* the other axis */
    int lane = along >> 16;
    /* the tile just past the box's leading edge */
    int ahead = d > 0 ? (push + FM_RADIUS) >> 16 : (push - FM_RADIUS - 1) >> 16;
    int best = 0x7FFFFFFF, target = along, k;

    if (d == 0) {
        return;
    }
    for (k = lane - 1; k <= lane + 1; k++) {
        int centre = (k << 16) + 0x8000;
        int tx = axis == 0 ? ahead : k;
        int tz = axis == 0 ? k : ahead;
        int dist = fm_abs(centre - along);

        if (dist > FM_NUDGE_REACH || dist >= best) {
            continue;
        }
        if (fm_tile_free(mmdl, form, tx, tz, dir, pos->y)) {
            best = dist;
            target = centre;
        }
    }
    if (target != along) {
        int delta = target - along;
        int s = speed;

        if (delta > s) {
            delta = s;
        } else if (delta < -s) {
            delta = -s;
        }
        fm_move_axis(mmdl, form, pos, delta, axis == 0 ? 1 : 0);
    }
}

/* ------------------------------------------------------------------ */
/* The free walk                                                       */
/* ------------------------------------------------------------------ */

/* Returns 1 when it handled the frame, 0 to leave it to the grid walk. */
static int fm_free_move(FieldPlayerGrid *grid, u32 keyTrigger, u32 keyHeld, u32 dashAllowed)
{
    struct FieldPlayerCore *core = grid->core;
    struct Mmdl *mmdl = FIELD_PLAYER_CORE_GetMmdl(core);
    u32 form = FIELD_PLAYER_CORE_GetFormCode(core);
    int vx, vz, push, speed, running, gx, gz, ngx, ngz;
    int dx, dz, okx, okz;
    u16 facing;
    FmVec pos, start;
    u32 attr;

    if (fm.grid != grid) {
        fm.grid = grid;
        fm.moving = 0;
        fm.endDelay = 0;
    }

    push = eidos_free_move_stick(&vx, &vz);
#if !FM_DPAD_CLASSIC
    if (push == 0 && (keyHeld & FM_KEY_DPAD) != 0) {
        vx = ((keyHeld & FM_KEY_RIGHT) ? 4096 : 0) - ((keyHeld & FM_KEY_LEFT) ? 4096 : 0);
        vz = ((keyHeld & FM_KEY_DOWN) ? 4096 : 0) - ((keyHeld & FM_KEY_UP) ? 4096 : 0);
        if (vx != 0 && vz != 0) {
            vx = vx * 2896 / 4096;
            vz = vz * 2896 / 4096;
        }
        push = (vx != 0 || vz != 0) ? 4096 : 0;
    }
#endif

    /* Not ours: surfing, an animation command running, special tiles. */
    if (form != FM_FORM_NORMAL && form != FM_FORM_CYCLE) {
        goto grid_walk;
    }
    if (FLDMMDL_CheckPossibleAcmd(mmdl) != 1) {
        return 0;               /* a step, a jump or a script is running */
    }
    if (FIELD_PLAYER_GRID_IsOnForcedMoveTile(grid) || FIELD_PLAYER_GRID_IsForcedMoveFlagSet(grid)
        || FIELD_PLAYER_GRID_IsHopFlagSet(grid) || FIELD_PLAYER_GRID_IsOnHopStartTile(grid)
        || FIELD_PLAYER_GRID_IsHopping(grid) || FIELD_PLAYER_GRID_IsHoldFlagSet(grid)) {
        goto grid_walk;
    }
    if (push == 0) {
        /* no stick: the d-pad or standing still, the game's own way */
        fm_stop_anim(core, mmdl);
        if ((keyHeld & FM_KEY_DPAD) != 0) {
            fm_snap(mmdl);
        }
        return 0;
    }

    FIELD_PLAYER_CORE_StepFormChange(core);
    if (fm.endDelay != 0 && --fm.endDelay == 0) {
        FLDMMDL_MOVE_AttrProcMoveEnd(mmdl);
    }

    facing = fm_facing(vx, vz, FLDMMDL_GetDirDisp(mmdl));
    if (facing != FLDMMDL_GetDirDisp(mmdl)) {
        FLDMMDL_SetDirAll(mmdl, facing);
    }
    if (push < FM_TURN_ONLY_PUSH) {
        fm_stop_anim(core, mmdl);
        return 1;
    }

    FLDMMDL_GetPos(mmdl, &pos);
    start = pos;
    gx = FLDMMDL_GetGridNowX(mmdl);
    gz = FLDMMDL_GetGridNowZ(mmdl);

    /* speed */
    running = 0;
    if (form == FM_FORM_CYCLE) {
        speed = FM_SPEED_CYCLE;
    } else {
        if ((dashAllowed & 1) && ((keyHeld & FM_KEY_B) || (FM_AUTORUN && push >= 4096))) {
            running = 1;
            if (fm_tile_attr(mmdl, gx, gz, pos.y, &attr) != 0
                && MAP_ATTR_IsNoDash(MAP_ATTR_GetTerrainId(attr)) != 0) {
                running = 0;
            }
        }
        speed = running ? FM_SPEED_RUN : FM_SPEED_WALK;
    }
    if (!running && form == FM_FORM_NORMAL) {
        int share = FM_MIN_WALK_SHARE + ((4096 - FM_MIN_WALK_SHARE) * push) / 4096;

        speed = (speed * share) / 4096;
    } else {
        speed = (speed * push) / 4096;
    }
    dx = (vx * speed) / 4096;
    dz = (vz * speed) / 4096;

    /* ledge ahead along the main axis: let the game jump it */
    {
        int ax = fm_abs(vx), az = fm_abs(vz);
        int ldir = FM_DIR_NONE, lx = gx, lz = gz;

        if (ax * 10 >= az * 17) {
            ldir = vx > 0 ? FM_DIR_RIGHT : FM_DIR_LEFT;
            lx += vx > 0 ? 1 : -1;
        } else if (az * 10 >= ax * 17) {
            ldir = vz > 0 ? FM_DIR_DOWN : FM_DIR_UP;
            lz += vz > 0 ? 1 : -1;
        }
        if (ldir != FM_DIR_NONE && fm_is_ledge(mmdl, lx, lz, ldir, pos.y)) {
            /* only once the player is up against it */
            FmVec probe = pos;
            int horiz = ldir == FM_DIR_LEFT || ldir == FM_DIR_RIGHT;
            int step = (ldir == FM_DIR_RIGHT || ldir == FM_DIR_DOWN) ? speed : -speed;

            if (!fm_move_axis(mmdl, form, &probe, step, horiz ? 0 : 1)) {
                u32 bit = ldir == FM_DIR_UP ? FM_KEY_UP : ldir == FM_DIR_DOWN ? FM_KEY_DOWN
                        : ldir == FM_DIR_LEFT ? FM_KEY_LEFT : FM_KEY_RIGHT;

                fm_stop_anim(core, mmdl);
                fm_snap(mmdl);
                fm_grid_move(grid, keyTrigger, (keyHeld & ~FM_KEY_DPAD) | bit, dashAllowed);
                return 1;
            }
        }
    }

    /* move, x then z, sliding along walls */
    okx = fm_move_axis(mmdl, form, &pos, dx, 0);
    okz = fm_move_axis(mmdl, form, &pos, dz, 1);
    if (!okx && fm_abs(vx) > fm_abs(vz)) {
        fm_nudge(mmdl, form, &pos, dx, 0, speed);
    } else if (!okz && fm_abs(vz) > fm_abs(vx)) {
        fm_nudge(mmdl, form, &pos, dz, 1, speed);
    }

    if (pos.x == start.x && pos.z == start.z) {
        /* against a wall: face it (doors and pushes need the facing) */
        fm_stop_anim(core, mmdl);
        return 1;
    }

    FLDMMDL_SetPos(mmdl, &pos);
    FLDMMDL_MOVE_UpdateHeight(mmdl);

    /* the walk animation */
    {
        u16 sta;

        if (form == FM_FORM_CYCLE) {
            sta = FM_DRAWSTA_WALK_2F;
        } else if (running) {
            sta = FM_DRAWSTA_WALK_4F;
        } else if (push < 2600) {
            sta = FM_DRAWSTA_WALK_16F;
        } else {
            sta = FM_DRAWSTA_WALK_8F;
        }
        FLDMMDL_SetDrawStatus(mmdl, sta);
        fm.moving = 1;
    }

    /* a new tile: report a finished grid step */
    ngx = pos.x >> 16;
    ngz = pos.z >> 16;
    if (ngx != gx || ngz != gz) {
        fm_flush_step_end(mmdl);
        FLDMMDL_MOVE_UpdateOldGridPos(mmdl);
        FLDMMDL_SetGridNowX(mmdl, (short)ngx);
        FLDMMDL_SetGridNowZ(mmdl, ngz);
        FLDMMDL_MOVE_UpdateHeight(mmdl);
        FLDMMDL_MOVE_AttrProcMoveStartSecond(mmdl);
        fm.endDelay = FM_END_DELAY;
        /* FIELD_PLAYER_CORE_UpdateStepPhase turns phase 2 into 3 at the
         * next event check: the field sees the step end there. */
        FIELD_PLAYER_CORE_SetStepKind(core, FM_STEP_KIND_WALK);
        FIELD_PLAYER_CORE_SetStepPhase(core, 2);
        FIELD_PLAYER_GRID_PlayStepSound(grid, FM_RESULT_WALK, facing);
    }
    return 1;

grid_walk:
    fm_stop_anim(core, mmdl);
    if (FLDMMDL_CheckPossibleAcmd(mmdl) == 1 && !fm_is_centred(mmdl)) {
        fm_snap(mmdl);
    }
    if (push != 0 && (keyHeld & FM_KEY_DPAD) == 0) {
        /* the stick drives the grid walk on surf and special tiles */
        u16 d = fm_facing(vx, vz, FLDMMDL_GetDirDisp(mmdl));
        u32 bit = d == FM_DIR_UP ? FM_KEY_UP : d == FM_DIR_DOWN ? FM_KEY_DOWN
                : d == FM_DIR_LEFT ? FM_KEY_LEFT : FM_KEY_RIGHT;

        if (push >= FM_TURN_ONLY_PUSH) {
            keyHeld |= bit;
        }
    }
    fm_grid_move(grid, keyTrigger, keyHeld, dashAllowed);
    return 1;
}

/* ------------------------------------------------------------------ */
/* The patched functions                                               */
/* ------------------------------------------------------------------ */

void FIELD_PLAYER_GRID_Move(FieldPlayerGrid *grid, u32 keyTrigger, u32 keyHeld, u32 dashAllowed)
{
    if (fm_free_move(grid, keyTrigger, keyHeld, dashAllowed) == 0) {
        fm_grid_move(grid, keyTrigger, keyHeld, dashAllowed);
    }
}

/* The field's event check calls this, then FIELD_PLAYER_GRID_StopForcedMove,
 * whenever an event starts; keepFrame is 1 when that event is the menu. */
void FIELD_PLAYER_GRID_ResetHold(FieldPlayerGrid *grid, int keepFrame)
{
    u16 savedFrames;

    fm.menuRequest = keepFrame == 1;
    if (FIELD_PLAYER_GRID_IsHoldFlagSet(grid) == 1) {
        savedFrames = grid->holdFrames;
        FIELD_PLAYER_GRID_EndHold(grid);
        if (keepFrame == 1) {
            grid->holdFrames = savedFrames;
            grid->holdEffectPending = 1;
        }
    }
}

void FIELD_PLAYER_GRID_StopForcedMove(FieldPlayerGrid *grid)
{
    struct Mmdl *mmdl = FIELD_PLAYER_CORE_GetMmdl(grid->core);

    fm_stop_anim(grid->core, mmdl);
    if (!fm.menuRequest && FLDMMDL_CheckPossibleAcmd(mmdl) == 1) {
        fm_snap(mmdl);
    }
    fm.menuRequest = 0;
    FIELD_PLAYER_GRID_ReleaseForcedMove(grid);
}
