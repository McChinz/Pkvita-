/*
 * patches: src/game/ov021/event_trainer_eye.c EVENT_TRAINER_EYE_GetSightDistance EVENT_TRAINER_EYE_StepSelectApproach EVENT_TRAINER_EYE_StepWaitStep
 * keeps declarations
 *
 * Trainer sight cones (as in Sun and Moon), for the free walk
 * (stubs/ov/patch_ov021_free_move.c).
 *
 * The game's trainers look along one line: the player is seen only on the
 * trainer's own row or column, within the trainer's range.  Here a trainer
 * also sees the player inside a cone around its facing, out to the same
 * range, measured from the player's real position (not just its tile).
 * The way must be clear: every tile the line of sight crosses passes the
 * game's own sight check (no wall, no height step, no other person, no
 * rustling grass spot).  The straight line still works exactly as before.
 *
 * A trainer that sees the player off its line walks to the player along
 * an L-shaped path, one tile at a time, choosing at every step the axis
 * with the most distance left (the other when that tile is blocked), until
 * it stands next to the player; then it turns to face the player.
 *
 * Trainers that look in all four directions get four cones.
 */

typedef unsigned int u32;
typedef unsigned short u16;
typedef short s16;

typedef struct FmVec {
    int x;
    int y;
    int z;
} FmVec;

struct Mmdl;
struct FieldEncount;
struct FieldMap;
struct FieldPlayer;
struct FieldEffectObj;

/* event_trainer_eye.c's GridPos */
typedef struct TcGridPos {
    s16 x;
    s16 y;
    s16 z;
    s16 pad06;
} TcGridPos;

/* event_trainer_eye_types.h's TrainerEyeHit and TrainerEyeWork */
typedef struct TcHit {
    struct Mmdl *trainer;
    int distance;
    u32 direction;
    u32 eventId;
    u32 trainerId;
    u32 hitKind;
} TcHit;

typedef struct TrainerEyeWork {
    int state;
    int finished;
    TcHit hit;
    int reserved20;
    int recordIndex;
    int delayCount;
    struct FieldEffectObj *markEffect;
    struct FieldMap *fieldMap;
    struct FieldPlayer *player;
} TrainerEyeWork;

/* ------------------------------------------------------------------ */
/* Tuning                                                              */
/* ------------------------------------------------------------------ */

/* Half the cone's angle, as its cosine in 1/4096 (3547 is 30 degrees,
 * 3355 is 35, 3138 is 40). */
#define TC_CONE_COS        3355
/* Extra reach past the trainer's range, in position units (a tile 0x10000). */
#define TC_RANGE_SLACK     0x8000
/* Line of sight: one sample every this many position units. */
#define TC_SIGHT_STEP      0x4000
/* Most steps a trainer takes toward the player before it stops trying. */
#define TC_MAX_STEPS       24

/* ------------------------------------------------------------------ */

#define TC_SIGHT_FACING          1
#define TC_SIGHT_ALL_DIRECTIONS  2

#define TC_DIR_UP     0
#define TC_DIR_DOWN   1
#define TC_DIR_LEFT   2
#define TC_DIR_RIGHT  3

#define TC_STATE_SELECT_APPROACH 10
#define TC_STATE_APPROACH        11
#define TC_STATE_ADJACENT        13

#define TC_HIT_OBJECT 0x04

extern int EVENT_TRAINER_EYE_GetSightType(struct Mmdl *mmdl);
extern int EVENT_TRAINER_EYE_CheckSight(int dir, int range, const TcGridPos *trainerPos, const TcGridPos *targetPos);
extern int EVENT_TRAINER_EYE_IsPathBlocked(struct Mmdl *mmdl, u16 dir, int distance, struct FieldEncount *encount);

extern int FLDMMDL_GetParam(struct Mmdl *mmdl, int no);
extern u16 FLDMMDL_GetDirDisp(struct Mmdl *mmdl);
extern void FLDMMDL_SetDirAll(struct Mmdl *mmdl, u16 dir);
extern short FLDMMDL_GetGridNowX(struct Mmdl *mmdl);
extern short FLDMMDL_GetGridNowY(struct Mmdl *mmdl);
extern short FLDMMDL_GetGridNowZ(struct Mmdl *mmdl);
extern void FLDMMDL_GetPos(const struct Mmdl *mmdl, FmVec *out);
extern int FLDMMDL_CheckEndAcmd(struct Mmdl *mmdl);
extern u32 FLDMMDL_MOVE_HitCheckMoveCurrent(struct Mmdl *mmdl, s16 gridX, s16 height, int gridZ, u16 kind);
extern int EFFECT_ENCOUNT_IsSpotAt(struct FieldEncount *encount, short *pos);
extern struct Mmdl *FIELD_PLAYER_GetMmdl(struct FieldPlayer *player);

/* Per-step approach state: a trainer eye event lives one at a time per
 * trainer (two in a pair battle). */
static struct {
    TrainerEyeWork *work[2];
    int steps[2];
} tc;

static int tc_abs(int v)
{
    return v < 0 ? -v : v;
}

static int tc_isqrt64(unsigned long long v)
{
    unsigned long long r = 0, bit = 1ull << 62;

    while (bit > v) {
        bit >>= 2;
    }
    while (bit != 0) {
        if (v >= r + bit) {
            v -= r + bit;
            r = (r >> 1) + bit;
        } else {
            r >>= 1;
        }
        bit >>= 2;
    }
    return (int)r;
}

/* Unit vector of a facing, in 1/4096. */
static void tc_dir_vec(int dir, int *fx, int *fz)
{
    *fx = dir == TC_DIR_RIGHT ? 4096 : dir == TC_DIR_LEFT ? -4096 : 0;
    *fz = dir == TC_DIR_DOWN ? 4096 : dir == TC_DIR_UP ? -4096 : 0;
}

/*
 * Whether the line from the trainer's tile centre to the player's position
 * is clear: every tile on it other than the two ends passes the sight
 * check the game uses for its straight line.
 */
static int tc_line_clear(struct Mmdl *trainer, struct FieldEncount *encount, int dir,
                         int ax, int az, int bx, int bz, int playerTx, int playerTz)
{
    int dx = bx - ax, dz = bz - az;
    int len = tc_isqrt64((unsigned long long)((long long)dx * dx + (long long)dz * dz));
    int n = len / TC_SIGHT_STEP + 1;
    int i;
    int startTx = ax >> 16, startTz = az >> 16;
    int lastTx = startTx, lastTz = startTz;
    s16 y = FLDMMDL_GetGridNowY(trainer);

    for (i = 1; i < n; i++) {
        int px = ax + (int)(((long long)dx * i) / n);
        int pz = az + (int)(((long long)dz * i) / n);
        int tx = px >> 16, tz = pz >> 16;

        if ((tx == lastTx && tz == lastTz) || (tx == startTx && tz == startTz)) {
            continue;
        }
        lastTx = tx;
        lastTz = tz;
        if (tx == playerTx && tz == playerTz) {
            continue;
        }
        /* move limits (1) are the trainer's own wander box: not a wall */
        if ((FLDMMDL_MOVE_HitCheckMoveCurrent(trainer, (s16)tx, y, tz, (u16)dir) & ~1u) != 0) {
            return 0;
        }
        if (encount != 0) {
            short spot[4];

            spot[0] = (short)tx;
            spot[1] = y;
            spot[2] = (short)tz;
            spot[3] = 0;
            if (EFFECT_ENCOUNT_IsSpotAt(encount, spot) != 0) {
                return 0;
            }
        }
    }
    return 1;
}

/* The cone check for one facing: tiles to the player, or -1. */
static int tc_cone(struct FieldEncount *encount, struct Mmdl *trainer, struct Mmdl *player,
                   int dir, int range)
{
    FmVec pp;
    int tgx = FLDMMDL_GetGridNowX(trainer), tgz = FLDMMDL_GetGridNowZ(trainer);
    int pgx = FLDMMDL_GetGridNowX(player), pgz = FLDMMDL_GetGridNowZ(player);
    int ax = (tgx << 16) + 0x8000, az = (tgz << 16) + 0x8000;
    int dx, dz, fx, fz, len;
    long long dot, reach;

    if (range <= 0 || FLDMMDL_GetGridNowY(trainer) != FLDMMDL_GetGridNowY(player)) {
        return -1;
    }
    if (pgx == tgx && pgz == tgz) {
        return -1;
    }
    FLDMMDL_GetPos(player, &pp);
    dx = pp.x - ax;
    dz = pp.z - az;
    len = tc_isqrt64((unsigned long long)((long long)dx * dx + (long long)dz * dz));
    reach = ((long long)range << 16) + TC_RANGE_SLACK;
    if (len == 0 || len > reach) {
        return -1;
    }
    tc_dir_vec(dir, &fx, &fz);
    dot = (long long)dx * fx + (long long)dz * fz;      /* len * cos * 4096 */
    if (dot <= 0 || dot < (long long)len * TC_CONE_COS) {
        return -1;
    }
    if (!tc_line_clear(trainer, encount, dir, ax, az, pp.x, pp.z, pgx, pgz)) {
        return -1;
    }
    return tc_abs(pgx - tgx) + tc_abs(pgz - tgz);
}

/*
 * Distance in tiles from the trainer to the player, or -1; sets the
 * direction the trainer looked along.  The game's straight line first,
 * then the cone.
 */
int EVENT_TRAINER_EYE_GetSightDistance(struct FieldEncount *encount, struct Mmdl *trainer,
                                       struct Mmdl *player, u16 *outDir)
{
    TcGridPos trainerPos;
    TcGridPos playerPos;
    int sightType;
    int range;
    int dist;
    int dir;

    sightType = EVENT_TRAINER_EYE_GetSightType(trainer);
    if (sightType != TC_SIGHT_FACING && sightType != TC_SIGHT_ALL_DIRECTIONS) {
        return -1;
    }
    range = (s16)FLDMMDL_GetParam(trainer, 0);
    trainerPos.x = FLDMMDL_GetGridNowX(trainer);
    trainerPos.y = FLDMMDL_GetGridNowY(trainer);
    trainerPos.z = FLDMMDL_GetGridNowZ(trainer);
    trainerPos.pad06 = 0;
    playerPos.x = FLDMMDL_GetGridNowX(player);
    playerPos.y = FLDMMDL_GetGridNowY(player);
    playerPos.z = FLDMMDL_GetGridNowZ(player);
    playerPos.pad06 = 0;

    for (dir = 0; dir < 4; dir++) {
        int d = sightType == TC_SIGHT_FACING ? (int)FLDMMDL_GetDirDisp(trainer) : dir;

        /* the game's own straight line */
        dist = EVENT_TRAINER_EYE_CheckSight(d, range, &trainerPos, &playerPos);
        if (dist != -1 && EVENT_TRAINER_EYE_IsPathBlocked(trainer, (u16)d, dist, encount) == 0) {
            *outDir = (u16)d;
            return dist;
        }
        /* the cone */
        dist = tc_cone(encount, trainer, player, d, range);
        if (dist != -1) {
            *outDir = (u16)d;
            return dist;
        }
        if (sightType == TC_SIGHT_FACING) {
            break;
        }
    }
    return -1;
}

/* ------------------------------------------------------------------ */
/* The walk to the player                                              */
/* ------------------------------------------------------------------ */

static int *tc_steps_of(TrainerEyeWork *work)
{
    int i;

    for (i = 0; i < 2; i++) {
        if (tc.work[i] == work) {
            return &tc.steps[i];
        }
    }
    for (i = 0; i < 2; i++) {
        if (tc.work[i] == 0 || tc.steps[i] < 0) {
            tc.work[i] = work;
            tc.steps[i] = 0;
            return &tc.steps[i];
        }
    }
    tc.work[0] = work;
    tc.steps[0] = 0;
    return &tc.steps[0];
}

static int tc_step_free(struct Mmdl *trainer, int tx, int tz, int dir, int playerTx, int playerTz)
{
    if (tx == playerTx && tz == playerTz) {
        return 0;
    }
    return FLDMMDL_MOVE_HitCheckMoveCurrent(trainer, (s16)tx, FLDMMDL_GetGridNowY(trainer), tz, (u16)dir) == 0;
}

/* Step 10: walk one more tile toward the player, or stop next to it. */
int EVENT_TRAINER_EYE_StepSelectApproach(TrainerEyeWork *work)
{
    struct Mmdl *trainer = work->hit.trainer;
    struct Mmdl *player = FIELD_PLAYER_GetMmdl(work->player);
    int tx = FLDMMDL_GetGridNowX(trainer), tz = FLDMMDL_GetGridNowZ(trainer);
    int px = FLDMMDL_GetGridNowX(player), pz = FLDMMDL_GetGridNowZ(player);
    int dx = px - tx, dz = pz - tz;
    int *steps = tc_steps_of(work);
    int hdir = dx > 0 ? TC_DIR_RIGHT : TC_DIR_LEFT;
    int vdir = dz > 0 ? TC_DIR_DOWN : TC_DIR_UP;
    int first, second, dir = -1;

    if (tc_abs(dx) + tc_abs(dz) <= 1 || *steps >= TC_MAX_STEPS) {
        /* next to the player (or no way through): face it */
        if (dx != 0 || dz != 0) {
            FLDMMDL_SetDirAll(trainer, (u16)(tc_abs(dx) >= tc_abs(dz) ? hdir : vdir));
        }
        work->hit.distance = 1;
        *steps = -1;                    /* this slot is free again */
        work->state = TC_STATE_ADJACENT;
        return 1;
    }
    /* the axis with more distance first; the other when that is blocked */
    if (tc_abs(dx) >= tc_abs(dz)) {
        first = dx != 0 ? hdir : -1;
        second = dz != 0 ? vdir : -1;
    } else {
        first = dz != 0 ? vdir : -1;
        second = dx != 0 ? hdir : -1;
    }
    if (first >= 0) {
        int nx = tx + (first == TC_DIR_RIGHT) - (first == TC_DIR_LEFT);
        int nz = tz + (first == TC_DIR_DOWN) - (first == TC_DIR_UP);

        if (tc_step_free(trainer, nx, nz, first, px, pz)) {
            dir = first;
        }
    }
    if (dir < 0 && second >= 0) {
        int nx = tx + (second == TC_DIR_RIGHT) - (second == TC_DIR_LEFT);
        int nz = tz + (second == TC_DIR_DOWN) - (second == TC_DIR_UP);

        if (tc_step_free(trainer, nx, nz, second, px, pz)) {
            dir = second;
        }
    }
    if (dir < 0) {
        *steps = TC_MAX_STEPS;          /* stuck: battle from here */
        work->state = TC_STATE_SELECT_APPROACH;
        return 1;
    }
    (*steps)++;
    work->hit.direction = (u32)dir;
    work->hit.distance = tc_abs(dx) + tc_abs(dz);
    work->state = TC_STATE_APPROACH;
    return 1;
}

/* Step 12: waits for the step to end, then picks the next one. */
int EVENT_TRAINER_EYE_StepWaitStep(TrainerEyeWork *work)
{
    if (FLDMMDL_CheckEndAcmd(work->hit.trainer) == 0) {
        return 0;
    }
    work->state = TC_STATE_SELECT_APPROACH;
    return 1;
}
