/*
 * engine/platform/plat_gl3d.c -- the DS 3D engine on the GPU.
 *
 * Draws a G3dSnapshot (engine/g3d/hw3d.h) into a framebuffer at any size,
 * following engine/g3d/raster.c rule for rule: clip-space vertices (the GPU
 * clips and divides), perspective-correct vertex colour and texture
 * coordinates, nearest texel fetch with the repeat, flip and clamp modes,
 * modulate / decal / toon / highlight shading on 6-bit colour and 5-bit alpha,
 * the alpha test, the z or w depth buffer, front / back culling on the
 * projected winding.  The result is premultiplied RGBA (a translucent pixel
 * over the clear plane keeps its own alpha, as the 2D engine expects).
 *
 * Edge marking is a second pass: the draw writes each opaque pixel's
 * polygon ID beside its colour, and the pass outlines every opaque pixel
 * that is nearer than a neighbour of another ID, in the EDGE_COLOR entry of
 * its ID, as engine/g3d/raster.c g3d_target_edge_mark does, at any
 * resolution:
 *
 *   - where: a pixel is in the outline when the first pixel of another ID
 *     in one of the four directions is at most one DS pixel away (the
 *     scale, in framebuffer pixels), so the outline is one DS pixel wide
 *     and follows the polygon's own edge at the higher resolution.  The
 *     nearest such boundary decides alone: asked in all four directions, a
 *     pixel beside a stair step of the boundary got different answers and
 *     dashed a one-pixel black line along the edge.  A shape narrower than
 *     one DS pixel across (other IDs on both sides within the scale) is
 *     left unmarked: the DS hits such a sliver with a pixel here and there,
 *     and filled whole it became a long thin black spike;
 *   - whether: that boundary is an edge when the hardware's test passes
 *     for two points one DS pixel apart across it, half a DS pixel inside
 *     and half a DS pixel outside, as the DS compares the centres of two
 *     neighbouring pixels.
 *
 * The two points are placed from the boundary, not from a fixed grid, so
 * the answer moves with the object.  Tested per framebuffer pixel, one DS
 * pixel away, the outline left a gap under an object standing on the floor
 * and drew a thin line below it; tested at the nearest framebuffer
 * boundary, it drew a comb of thin lines where two surfaces meet at nearly
 * the same depth; tested at the centres of a screen-fixed grid of DS
 * pixels, its dashes flickered as the scene moved under that grid.
 *
 * Not done on the GPU (the snapshot says so in `unsupported` and the caller
 * shows the CPU frame instead): fog, the rear-plane bitmap, shadow polygons.
 * Anti-aliasing is the resolution itself.
 */

#include <math.h>
#include <stddef.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include "plat_gl_int.h"
#ifdef far
#undef far /* the windows headers define it; BmapDraw has a member of that name */
#endif
#include "bmap.h"
#include "plat_thread.h"
#include "bmap_leaf.h"
#include "bmap_place.h"
#include "g3d.h"
#include "hw3d.h"
#include "prof.h"

#define FLOATS_PER_VERTEX 9u

static const char *k_vs3 =
    "#version 330 core\n"
    "layout(location = 0) in vec4 a_pos;\n"
    "layout(location = 1) in vec2 a_st;\n"
    "layout(location = 2) in vec3 a_rgb;\n"
    "out vec2 v_st;\n"
    "out vec3 v_rgb;\n"
    "void main() {\n"
    "    v_st = a_st;\n"
    "    v_rgb = a_rgb;\n"
    "    gl_Position = a_pos;\n"
    "}\n";

static const char *k_fs3 =
    "#version 330 core\n"
    "in vec2 v_st;\n"
    "in vec3 v_rgb;\n"
    "layout(location = 0) out vec4 o;\n"
    "layout(location = 1) out uint o_id;\n"
    "uniform int u_id;\n"
    "uniform int u_mode;\n"          /* 0 modulate, 1 decal, 2 toon/highlight */
    "uniform int u_alpha5;\n"
    "uniform int u_tex;\n"
    "uniform sampler2D u_texture;\n"
    "uniform ivec2 u_texsize;\n"
    "uniform ivec4 u_wrap;\n"        /* repeat s, repeat t, flip s, flip t */
    "uniform int u_alpharef;\n"
    "uniform int u_toon;\n"
    "uniform int u_highlight;\n"
    "uniform vec3 u_toontab[32];\n"
    "uniform int u_front;\n"
    "uniform int u_back;\n"
    "uniform int u_wbuf;\n"
    "uniform int u_pass;\n"
    "uniform float u_zover;\n"
    "uniform float u_zref;\n"
    "uniform vec4 u_sfog;\n"
    "int wrapc(int v, int size, int rep, int flip) {\n"
    "    if (size <= 0) { return 0; }\n"
    "    if (rep == 0) { return clamp(v, 0, size - 1); }\n"
    "    if (flip != 0) {\n"
    "        int k = v & (size * 2 - 1);\n"
    "        if (k >= size) { k = size * 2 - 1 - k; }\n"
    "        return k;\n"
    "    }\n"
    "    return v & (size - 1);\n"
    "}\n"
    "int mod6(int a8, int b8) {\n"
    "    int a6 = a8 >> 2;\n"
    "    int b6 = b8 >> 2;\n"
    "    int r = ((a6 + 1) * (b6 + 1) - 1) >> 6;\n"
    "    r = min(r, 63);\n"
    "    return r * 255 / 63;\n"
    "}\n"
    "int mod5(int a, int b) {\n"
    "    int r = ((a + 1) * (b + 1) - 1) >> 5;\n"
    "    return min(r, 31);\n"
    "}\n"
    "void main() {\n"
    "    if (gl_FrontFacing) { if (u_front == 0) { discard; } }\n"
    "    else { if (u_back == 0) { discard; } }\n"
    "    ivec3 c = clamp(ivec3(floor(v_rgb + 0.001)), ivec3(0), ivec3(255));\n"
    "    ivec3 hl = ivec3(0);\n"
    "    if (u_toon == 1) {\n"
    "        ivec3 e = ivec3(u_toontab[c.r >> 3] + 0.5);\n"
    "        if (u_highlight == 1) { hl = e; c.g = c.r; c.b = c.r; }\n"
    "        else { c = e; }\n"
    "    }\n"
    "    int a5 = u_alpha5;\n"
    "    ivec3 col = c;\n"
    "    if (u_tex == 1) {\n"
    "        int x = wrapc(int(floor(v_st.x / 16.0)), u_texsize.x, u_wrap.x, u_wrap.z);\n"
    "        int y = wrapc(int(floor(v_st.y / 16.0)), u_texsize.y, u_wrap.y, u_wrap.w);\n"
    "        ivec4 tc = ivec4(texelFetch(u_texture, ivec2(x, y), 0) * 255.0 + 0.5);\n"
    "        if (u_mode == 1) {\n"
    "            int ta = tc.a >> 3;\n"
    "            col = (tc.rgb * ta + c * (31 - ta)) / 31;\n"
    "        } else {\n"
    "            col = ivec3(mod6(tc.r, c.r), mod6(tc.g, c.g), mod6(tc.b, c.b));\n"
    "            a5 = mod5(tc.a >> 3, u_alpha5);\n"
    "        }\n"
    "    }\n"
    "    col = min(col + hl, ivec3(255));\n"
    "    if (u_pass == 1 && a5 < 31) { discard; }\n"
    "    if (u_pass == 2 && a5 >= 31) { discard; }\n"
    "    if (a5 == 0 || a5 <= u_alpharef) { discard; }\n"
    "    float a = float(a5) / 31.0;\n"
    "    /* (a battle sprite under the map's fog: the fog's colour, and how much of it) */\n"
    "    o = vec4(mix(vec3(col) / 255.0, u_sfog.rgb, u_sfog.a) * a, a);\n"
    "    o_id = uint(u_id);\n"
    "    /* (a sprite at the depth of its place: its cells keep their own order, each\n"
    "       cell's depth against the sprite's first cell's carried on at a twentieth) */\n"
    "    gl_FragDepth = (u_zover > 0.0) ? clamp(u_zover + (gl_FragCoord.z - u_zref) * 0.05, 0.0, 1.0)\n"
    "                 : (u_wbuf == 1) ? clamp((1.0 / gl_FragCoord.w) / 16777216.0, 0.0, 1.0)\n"
    "                                 : gl_FragCoord.z;\n"
    "}\n";

/* Edge marking, over the frame just drawn (see the file comment).  A pixel
 * off the frame counts as the clear plane: its ID and depth. */
static const char *k_vse =
    "#version 330 core\n"
    "void main() {\n"
    "    vec2 p = vec2((gl_VertexID << 1) & 2, gl_VertexID & 2);\n"
    "    gl_Position = vec4(p * 2.0 - 1.0, 0.0, 1.0);\n"
    "}\n";

/*
 * The outline variants (EIDOS_EDGE=n at start, for comparing them; the
 * setting picks 0 or 1, eidos_gl_set_edges 2 picks 3):
 *   0  none
 *   1  thin: a pixel touching a farther pixel of another ID, one window
 *      pixel wide (melonDS's rule at its scale 1)
 *   2  thin behind: the farther pixel of the pair, in the nearer one's
 *      colour (DeSmuME's rule)
 *   3  one DS pixel: variant 1's pixels widened by a disc inside their own
 *      polygon, as thick at every angle
 *   4  the first rule: four rays of one DS pixel (the spikes and combs)
 *   5  half a DS pixel: variant 3 at half the width
 *   6  one DS pixel behind: variant 2 widened outward by a disc
 *   7  thin, half strength (melonDS with anti-aliasing on)
 * EIDOS_EDGE_WIDTH=n sets the disc's radius in window pixels instead.
 */
static const char *k_fse =
    "#version 330 core\n"
    "uniform sampler2D u_col;\n"
    "uniform usampler2D u_id;\n"
    "uniform sampler2D u_dep;\n"
    "uniform int u_step;\n"
    "uniform int u_variant;\n"
    "uniform uint u_cid;\n"
    "uniform float u_cdep;\n"
    "uniform vec3 u_edge[8];\n"
    "out vec4 o;\n"
    "ivec2 sz;\n"
    "uint idat(ivec2 q) {\n"
    "    if (q.x >= 0 && q.y >= 0 && q.x < sz.x && q.y < sz.y) {\n"
    "        return texelFetch(u_id, q, 0).r & 0x3Fu;\n"
    "    }\n"
    "    return u_cid;\n"
    "}\n"
    "float ddat(ivec2 q) {\n"
    "    if (q.x >= 0 && q.y >= 0 && q.x < sz.x && q.y < sz.y) {\n"
    "        return texelFetch(u_dep, q, 0).r;\n"
    "    }\n"
    "    return u_cdep;\n"
    "}\n"
    "bool opaque(ivec2 q) {\n"
    "    return q.x >= 0 && q.y >= 0 && q.x < sz.x && q.y < sz.y\n"
    "           && (texelFetch(u_id, q, 0).r & 0x80u) != 0u;\n"
    "}\n"
    "const ivec2 N4[4] = ivec2[4](ivec2(1, 0), ivec2(-1, 0), ivec2(0, 1), ivec2(0, -1));\n"
    /* q (ID qid) touches a farther pixel of another ID */
    "bool front(ivec2 q, uint qid) {\n"
    "    float qd = ddat(q);\n"
    "    for (int k = 0; k < 4; k++) {\n"
    "        if (idat(q + N4[k]) != qid && qd < ddat(q + N4[k])) { return true; }\n"
    "    }\n"
    "    return false;\n"
    "}\n"
    /* q touches a nearer opaque pixel of another ID: that ID, else 64 */
    "uint behind(ivec2 q) {\n"
    "    uint qid = idat(q);\n"
    "    float qd = ddat(q);\n"
    "    for (int k = 0; k < 4; k++) {\n"
    "        ivec2 n = q + N4[k];\n"
    "        if (opaque(n) && idat(n) != qid && ddat(n) < qd) { return idat(n); }\n"
    "    }\n"
    "    return 64u;\n"
    "}\n"
    "bool near_other(ivec2 p, uint id, int r) {\n"
    "    for (int i = 0; i < 16; i++) {\n"
    "        vec2 d = vec2(cos(0.39269908 * float(i)), sin(0.39269908 * float(i)));\n"
    "        if (idat(p + ivec2(round(d * float(r + 1)))) != id\n"
    "            || idat(p + ivec2(round(d * 0.5 * float(r + 1)))) != id) { return true; }\n"
    "    }\n"
    "    return false;\n"
    "}\n"
    "void mark(uint id, float a) {\n"
    "    o = vec4(mix(o.rgb, u_edge[id >> 3], a), max(o.a, a));\n"
    "}\n"
    "void main() {\n"
    "    ivec2 p = ivec2(gl_FragCoord.xy);\n"
    "    sz = textureSize(u_col, 0);\n"
    "    o = texelFetch(u_col, p, 0);\n"
    "    uint raw = texelFetch(u_id, p, 0).r;\n"
    "    uint id = raw & 0x3Fu;\n"
    "    int r = u_step - 1;\n"
    "    if (u_variant == 2 || u_variant == 6) {\n"
    "        uint f = behind(p);\n"
    "        if (f < 64u) { mark(f, 1.0); return; }\n"
    "        if (u_variant == 2 || r <= 0 || !near_other(p, id, r)) { return; }\n"
    "        for (int dy = -r; dy <= r; dy++) {\n"
    "            for (int dx = -r; dx <= r; dx++) {\n"
    "                ivec2 q = p + ivec2(dx, dy);\n"
    "                if (dx * dx + dy * dy > r * r || idat(q) != id) { continue; }\n"
    "                f = behind(q);\n"
    "                if (f < 64u) { mark(f, 1.0); return; }\n"
    "            }\n"
    "        }\n"
    "        return;\n"
    "    }\n"
    "    if ((raw & 0x80u) == 0u) { return; }\n"
    "    if (u_variant == 4) {\n"
    "        int half_ = u_step / 2;\n"
    "        for (int i = 0; i < 4; i++) {\n"
    "            int j = 1;\n"
    "            bool found = false;\n"
    "            for (; j <= u_step; j++) {\n"
    "                if (idat(p + N4[i] * j) != id) { found = true; break; }\n"
    "            }\n"
    "            if (!found) { continue; }\n"
    "            ivec2 bi = p + N4[i] * (j - 1);\n"
    "            ivec2 a = clamp(bi - N4[i] * half_, ivec2(0), sz - 1);\n"
    "            if (idat(a) != id) { a = bi; }\n"
    "            ivec2 b = bi + N4[i] * (u_step - half_);\n"
    "            if (idat(b) != id && ddat(a) < ddat(b)) { mark(id, 1.0); return; }\n"
    "        }\n"
    "        return;\n"
    "    }\n"
    "    if (front(p, id)) { mark(id, u_variant == 7 ? 0.5 : 1.0); return; }\n"
    "    if (u_variant == 1 || u_variant == 7 || r <= 0 || !near_other(p, id, r)) { return; }\n"
    "    for (int dy = -r; dy <= r; dy++) {\n"
    "        for (int dx = -r; dx <= r; dx++) {\n"
    "            ivec2 q = p + ivec2(dx, dy);\n"
    "            if (dx * dx + dy * dy > r * r || idat(q) != id) { continue; }\n"
    "            if (front(q, id)) { mark(id, 1.0); return; }\n"
    "        }\n"
    "    }\n"
    "}\n";

/* Fog, over the frame after the edge marking (raster.c, g3d_target_fog, is
 * the reference).  The ID buffer's bit 6 is the pixel's fog flag; the depth
 * texture holds the depth in the DS's 15-bit units times 1/32768 (z/w as
 * gl_FragCoord.z, or w / 2^24 for a w-buffered frame).  The colour target is
 * premultiplied, so the straight colour is taken back out, blended, and
 * multiplied again; a clear-plane pixel of alpha 0 blends from the clear
 * colour. */
static const char *k_fsf =
    "#version 330 core\n"
    "uniform sampler2D u_col;\n"
    "uniform usampler2D u_id;\n"
    "uniform sampler2D u_dep;\n"
    "uniform vec4 u_fog;\n"
    "uniform float u_table[32];\n"
    "uniform float u_offset;\n"
    "uniform float u_step;\n"
    "uniform int u_aonly;\n"
    "uniform vec3 u_clear;\n"
    "out vec4 o;\n"
    "void main() {\n"
    "    ivec2 p = ivec2(gl_FragCoord.xy);\n"
    "    vec4 c = texelFetch(u_col, p, 0);\n"
    "    uint id = texelFetch(u_id, p, 0).r;\n"
    "    o = c;\n"
    "    if ((id & 0x40u) == 0u) { return; }\n"
    "    float d = min(floor(texelFetch(u_dep, p, 0).r * 32768.0), 32767.0);\n"
    "    float den;\n"
    "    if (u_step <= 0.0) { den = d > u_offset ? u_table[31] : u_table[0]; }\n"
    "    else if (d <= u_offset + u_step) { den = u_table[0]; }\n"
    "    else if (d >= u_offset + u_step * 32.0) { den = u_table[31]; }\n"
    "    else {\n"
    "        float rel = d - u_offset - u_step;\n"
    "        int k = int(floor(rel / u_step));\n"
    "        float f = rel - float(k) * u_step;\n"
    "        den = floor((u_table[k] * (u_step - f) + u_table[k + 1] * f) / u_step);\n"
    "    }\n"
    "    if (den >= 127.0) { den = 128.0; }\n"
    "    vec3 sc = c.a > 0.0 ? c.rgb / c.a : ((id & 0x80u) == 0u ? u_clear : vec3(0.0));\n"
    "    float a5 = floor(c.a * 31.0 + 0.5);\n"
    "    float na = floor((u_fog.a * 31.0 * den + a5 * (128.0 - den)) / 128.0) / 31.0;\n"
    "    vec3 nc = u_aonly == 1 ? sc : (u_fog.rgb * den + sc * (128.0 - den)) / 128.0;\n"
    "    o = vec4(nc * na, na);\n"
    "}\n";

/* ------------------------------------------------------------------ */
/* The battle backdrop (sdk/battle_view.c, docs/battle-backdrop.md)     */
/* ------------------------------------------------------------------ */

/* A placed scene (engine/world/bmap.h) drawn before the game's polygons with
 * the battle's camera: the same projection, the same view scale and the same
 * depth buffer, so the game's sprites, shadows and particles depth test
 * against the map.  The scene's textures and vertices go to the GPU once per
 * scene, when the snapshot names a new one. */
#ifndef GL_TEXTURE_MAX_LEVEL
#define GL_TEXTURE_MAX_LEVEL 0x813D
#endif
#ifndef GL_MIRRORED_REPEAT
#define GL_MIRRORED_REPEAT 0x8370
#endif

static const char *k_vsb =
    "#version 330 core\n"
    "layout(location = 0) in vec3 a_pos;\n"
    "layout(location = 1) in vec2 a_st;\n"
    "layout(location = 2) in vec4 a_rgb;\n"
    "uniform vec4 u_r0;\n"
    "uniform vec4 u_r1;\n"
    "uniform vec4 u_r2;\n"
    "uniform vec4 u_r3;\n"
    "uniform vec3 u_eye;\n"
    "uniform vec3 u_pivot;\n"
    "uniform float u_lift;\n"
    "uniform int u_bb;\n"
    "uniform vec3 u_uv0;\n"
    "uniform vec3 u_uv1;\n"
    "out vec2 v_st;\n"
    "out vec3 v_rgb;\n"
    "out float v_tag;\n"
    "out vec3 v_pos;\n"
    "out float v_bbc;\n"
    "void main() {\n"
    "    vec3 q = a_pos;\n"
    "    v_bbc = 1.0;\n"
    "    if (u_bb > 0) {\n"
    "        /* built facing +z around the pivot: turn it toward the camera */\n"
    "        vec3 z = u_eye - u_pivot;\n"
    "        if (u_bb == 2) { z.y = 0.0; }\n"
    "        z = normalize(z);\n"
    "        vec3 x = normalize(cross(vec3(0.0, 1.0, 0.0), z));\n"
    "        vec3 y = cross(z, x);\n"
    "        vec3 o = a_pos - u_pivot;\n"
    "        q = u_pivot + x * o.x + y * o.y + z * o.z;\n"
    "    }\n"
    "    q.y += u_lift;      /* a moving object's rise this frame */\n"
    "    vec4 p = vec4(q, 1.0);\n"
    "    v_pos = q;\n"
    "    /* the draw's texture animation this frame (identity: none) */\n"
    "    v_st = vec2(dot(u_uv0, vec3(a_st, 1.0)), dot(u_uv1, vec3(a_st, 1.0)));\n"
    "    v_rgb = a_rgb.rgb;\n"
    "    v_tag = a_rgb.a * 255.0;    /* (a tree's tag, bmap_place.c find_trees; 0: none) */\n"
    "    gl_Position = vec4(dot(u_r0, p), dot(u_r1, p), dot(u_r2, p), dot(u_r3, p));\n"
    "}\n";

static const char *k_fsb =
    "#version 330 core\n"
    "in vec2 v_st;\n"
    "in vec3 v_rgb;\n"
    "in float v_tag;\n"
    "in vec3 v_pos;\n"
    "in float v_bbc;\n"
    "layout(location = 0) out vec4 o;\n"
    "uniform vec3 u_eye;\n"
    "uniform vec3 u_foc;\n"
    "uniform vec4 u_fog;\n"
    "uniform vec4 u_fogc;\n"
    "uniform vec4 u_fog2;\n"
    "uniform int u_tex;\n"
    "uniform sampler2D u_texture;\n"
    "uniform float u_alpha;\n"
    "uniform float u_cut;\n"
    "uniform float u_cut_hi;\n"
    "uniform int u_front;\n"
    "uniform vec4 u_poke[32];\n"
    "uniform int u_npoke;\n"
    "uniform int u_grass;\n"
    "uniform int u_leaf;\n"
    "uniform float u_tint;\n"
    "uniform int u_only;\n"
    "uniform vec4 u_clr[32];\n"
    "uniform int u_nclr;\n"
    "uniform vec4 u_sky;\n"
    "uniform vec3 u_skyu;\n"
    "uniform vec3 u_skyv;\n"
    "void main() {\n"
    "    if (u_sky.x > 0.0) {\n"
    "        /* the cloud dome: where this pixel's line of sight meets the layer u_sky.y\n"
    "           over the camera (its horizon u_sky.w under the level), the picture at\n"
    "           that point's place on the map (u_skyu, u_skyv) in blocks, fading out\n"
    "           toward that horizon */\n"
    "        vec3 d = normalize(v_pos - u_eye);\n"
    "        float e = d.y + u_sky.w;\n"
    "        if (e < 0.01) { discard; }\n"
    "        vec2 sz = vec2(textureSize(u_texture, 0));\n"
    "        vec3 q = vec3(u_eye.xz + d.xz / e * u_sky.y, 1.0);\n"
    "        vec2 st = fract(vec2(dot(u_skyu, q), dot(u_skyv, q)));\n"
    "        vec4 t = textureLod(u_texture, (floor(st * sz) + 0.5) / sz, 0.0);\n"
    "        float a = t.a * u_alpha * smoothstep(0.01, 0.12, e);\n"
    "        if (a < 0.004) { discard; }\n"
    "        o = vec4(v_rgb * t.rgb * a, a);\n"
    "        return;\n"
    "    }\n"
    "    if (u_nclr > 0 && v_tag > 0.5) {\n"
    "        /* a tree the camera's clearance reaches goes whole: an entry with a\n"
    "           negative radius names the tree's tag (its y) at its place within\n"
    "           its width; the triangles that carry that tag are not drawn.  Its\n"
    "           level faces (the flat leaf layers) go whole whatever the width (a\n"
    "           wide tree loses only a stretch of its upright cards: the layers cut\n"
    "           at that stretch's edge were left floating as bands) */\n"
    "        vec3 px = dFdx(v_pos), py = dFdy(v_pos);\n"
    "        vec3 tn = cross(px, py);\n"
    "        bool level = abs(tn.y) > 0.7 * length(tn);\n"
    "        /* an upright card is cut by whole pictures: what is tested is the\n"
    "           whole span of the fragment's own repeat of the picture along the\n"
    "           card (its middle cp, half its length sh along sd), so each painted\n"
    "           tree goes or stays whole (a forest's wall has a tree a repeat) */\n"
    "        vec2 sx = dFdx(v_st), sy = dFdy(v_st);\n"
    "        float det = sx.x * sy.y - sy.x * sx.y;\n"
    "        vec3 cp = v_pos;\n"
    "        vec2 sd = vec2(0.0);\n"
    "        float sh = 0.0;\n"
    "        if (!level && abs(det) > 1e-12) {\n"
    "            vec3 dpdu = (px * sy.y - py * sx.y) / det;\n"
    "            if (length(dpdu) < 200.0) {\n"
    "                cp = v_pos + dpdu * (floor(v_st.x) + 0.5 - v_st.x);\n"
    "                sh = 0.5 * length(dpdu.xz);\n"
    "                if (sh > 1e-6) { sd = dpdu.xz / (2.0 * sh); }\n"
    "            }\n"
    "        }\n"
    "        /* (the canopy, tag 255: a wide level sheet of leaves over a forest;\n"
    "           it goes round each tree that is out, a little wider than the tree) */\n"
    "        for (int i = 0; i < u_nclr; i++) {\n"
    "            if (v_tag > 254.5 && u_clr[i].w < 0.0\n"
    "                && length(v_pos.xz - u_clr[i].xz) < -u_clr[i].w + 1.5) { discard; }\n"
    "        }\n"
    "        for (int i = 0; i < u_nclr; i++) {\n"
    "            if (u_clr[i].w < 0.0 && abs(v_tag - u_clr[i].y) < 0.5) {\n"
    "                vec2 rel = cp.xz - u_clr[i].xz;\n"
    "                float al = dot(rel, sd);\n"
    "                float d = length(vec2(max(abs(al) - sh, 0.0), length(rel - al * sd)));\n"
    "                if (d < (level ? 40.0 : -u_clr[i].w)) { discard; }\n"
    "            }\n"
    "        }\n"
    "    }\n"
    "    /* (not tall grass, the camera passes through it; not a tree, which goes\n"
    "       whole above or is drawn whole: a ball cut out of it left a hole) */\n"
    "    if (u_nclr > 0 && u_grass == 0 && v_tag < 0.5) {\n"
    "        /* the camera's clearance: an upright surface inside one of the\n"
    "           places the camera passed this shot is not drawn; a floor is kept.\n"
    "           The level top of a body the camera stands in or beside goes with\n"
    "           its sides (a pedestal's top was left floating as a sheet): a level\n"
    "           face seen nearly edge-on, well over the battle's ground (1.5 units\n"
    "           over the Pokemon's middle: no floor a battle stands on) */\n"
    "        vec3 nf = cross(dFdx(v_pos), dFdy(v_pos));\n"
    "        float ln = length(nf);\n"
    "        vec3 mid = vec3(0.0);\n"
    "        float nm = 0.0;\n"
    "        for (int i = 0; i < u_npoke; i++) {\n"
    "            if (u_poke[i].w > 0.0) { mid += u_poke[i].xyz; nm += 1.0; }\n"
    "        }\n"
    "        mid = nm > 0.0 ? mid / nm : u_foc;\n"
    "        /* (between the camera and the battle: the two on either side of its plane) */\n"
    "        bool between = dot(nf, u_eye - v_pos) * dot(nf, mid - v_pos) < 0.0;\n"
    "        /* (or seen nearly edge-on: a post's narrow side, a sliver) */\n"
    "        between = between || abs(dot(nf, normalize(u_eye - v_pos))) < 0.35 * ln;\n"
    "        bool top = ln > 1e-9 && abs(nf.y) / ln >= 0.7 && v_pos.y > mid.y + 1.5\n"
    "                   && abs(dot(nf, normalize(u_eye - v_pos))) < 0.35 * ln;\n"
    "        if ((between && ln > 1e-9 && abs(nf.y) / ln < 0.7) || top) {\n"
    "            for (int i = 0; i < u_nclr; i++) {\n"
    "                if (u_clr[i].w > 0.0 && length(v_pos - u_clr[i].xyz) < u_clr[i].w) { discard; }\n"
    "            }\n"
    "        }\n"
    "    }\n"
    "    if (u_front == 1) {\n"
    "        /* the second pass: what of the map stands between the camera and\n"
    "           a Pokemon, over the sprite's box (seen at the Pokemon's\n"
    "           distance: 2.8 units either side, from just under its feet to\n"
    "           6 above), is drawn again over it */\n"
    "        bool keep = false, behind = false;\n"
    "        vec3 f = v_pos - u_eye;\n"
    "        for (int i = 0; i < u_npoke; i++) {\n"
    "            vec3 d = u_poke[i].xyz - u_eye;\n"
    "            float L = length(d);\n"
    "            if (L < 1e-3) { continue; }\n"
    "            vec3 n = d / L;\n"
    "            float along = dot(f, n);\n"
    "            if (along < 0.05) { continue; }\n"
    "            vec3 side = normalize(cross(n, vec3(0.0, 1.0, 0.0)));\n"
    "            vec3 up = cross(side, n);\n"
    "            vec3 o = (f - n * along) * (L / along);\n"
    "            float sx = dot(o, side), uy = dot(o, up);\n"
    "            float hgt = abs(u_poke[i].w);\n"
    "            if (abs(sx) < 0.47 * hgt && uy > -1.0 && uy < hgt) {\n"
    "                if (u_poke[i].w < 0.0) { behind = true; }   /* a shield: never covered */\n"
    "                /* in front of this Pokemon: drawn again; behind it\n"
    "                   (a nearer Pokemon covers it): never over that one,\n"
    "                   tested against the sprite's own size, not the loose\n"
    "                   box (a near Pokemon's loose box reaches the far one\n"
    "                   on screen, and the map in front of the far one went) */\n"
    "                if (u_leaf == 1) {\n"
    "                    /* a grass leaf sent whole for the Pokemon u_only (chosen leaf by\n"
    "                       leaf): over that one, wherever its pixels lie; never over\n"
    "                       another Pokemon it is behind */\n"
    "                    if (i == u_only) { keep = true; }\n"
    "                    else if (along > L - 0.3 && abs(sx) < 0.25 * hgt && uy < 0.6 * hgt) { behind = true; }\n"
    "                }\n"
    "                else if (along <= L - 0.3) { keep = true; }\n"
    "                else if (abs(sx) < 0.25 * hgt && uy < 0.6 * hgt) { behind = true; }\n"
    "            }\n"
    "        }\n"
    "        if (!keep || behind) { discard; }\n"
    "    }\n"
    "    vec4 c = vec4(v_rgb, 1.0);\n"
    "    if (u_tex == 1) { c *= texture(u_texture, v_st); }\n"
    "    if (u_front == 1 && u_tint > 0.0) { c.rgb = mix(c.rgb, vec3(1.0, 0.0, 0.0), u_tint); }\n"
    "    float a = c.a * u_alpha;\n"
    "    if (a < u_cut || a >= u_cut_hi) { discard; }\n"
    "    if (u_cut > 0.4) { a = 1.0; }\n"
    "    if (u_fogc.a > 0.0) {\n"
    "        float t = dot(v_pos, u_fog.xyz) - u_fog.w;\n"
    "        float f = clamp(t, 0.0, 1.0);\n"
    "        if (u_fogc.a > 1.0) {\n"
    "            t = max(t, 0.0);\n"
    "            f = clamp((u_fogc.a - 1.0) * t / (1.0 + t), 0.0, 1.0);\n"
    "            if (u_fog2.xyz != vec3(0.0)) {\n"
    "                float g = max(dot(v_pos, u_fog2.xyz) - u_fog2.w, 0.0);\n"
    "                f = max(f, clamp((u_fogc.a - 1.0) * g / (1.0 + g), 0.0, 1.0));\n"
    "            }\n"
    "        }\n"
    "        c.rgb = mix(c.rgb, u_fogc.rgb, f);\n"
    "    }\n"
    "    o = vec4(c.rgb * a, a);\n"
    "}\n";

/* A see-through triangle of the map, with its draw and its middle: these
 * are drawn far to near, each blended over what lies behind it (one object,
 * a gym's stage with the glow behind it, can lie both before and behind
 * another part of itself). */
/* The stencil while the game's polygons draw: the low bits hold 0x40 | the
 * polygon ID of the last see-through pixel (the hardware's rule), the top
 * bit marks every pixel the game drew, for the backdrop's front pass. */
#define STENCIL_GAME 0x80u
#define STENCIL_IDS  0x7Fu

typedef struct BdPiece {
    unsigned draw, first, count;
    float mid[3];
} BdPiece;

/* A see-through draw whose material is opaque (alpha 31: the texture alone
 * has soft or cut-out texels): its solid texels draw in the depth pass with
 * the opaque map, so only its soft edges are blended, and they need no
 * triangle order of their own. */
#define BD_CORE_CUT 0.99f
#define BD_SOFT_ONLY(d) ((d)->alpha >= 31u)

/* A sphere around one draw's triangles (for a billboard, around its pivot,
 * so it holds the triangles whichever way they turn) */
typedef struct BdBound {
    float c[3], r;
} BdBound;

typedef struct Gl3dBackdrop {
    GLuint prog, vao, vbo, ibo;
    GLint u_lift;
    GLint u_fog2;
    GLint u_r[4], u_pivot, u_bb, u_eye, u_foc, u_fog, u_fogc, u_tex, u_texture, u_alpha, u_cut, u_cut_hi;
    GLint u_leaf, u_only, u_tint;
    GLint u_front, u_poke, u_npoke, u_grass, u_uv0, u_uv1, u_clr, u_nclr, u_sky, u_skyu, u_skyv;
    const void *scene;          /* the scene on the GPU                    */
    unsigned gen;
    GLuint *tex;
    unsigned n_tex;
    unsigned tex_gen;           /* the scene textures' BmapScene.tex_gen */
    BdPiece *piece;             /* the see-through parts, and their order  */
    unsigned n_piece;
    unsigned *order;
    float *dist;
    GLuint *idx;                /* their vertices far to near (the ibo's)  */
    unsigned n_idx;
    unsigned *at;               /* where each piece in the order starts    */
    float idx_eye[3];           /* the camera the ibo was sorted for       */
    int idx_ok;
    BdBound *bound;             /* one sphere per draw (sc->nd), or NULL   */
    const void *up_scene;       /* a scene on its way up (backdrop_upload), or NULL */
    unsigned up_gen, up_tex;    /* ... its generation; its pictures done   */
    int up_verts;               /* ... its vertices are up                 */
} Gl3dBackdrop;

static Gl3dBackdrop g_bd;

static void backdrop_free_tex(void)
{
    if (g_bd.n_tex > 0) {
        glDeleteTextures((GLsizei)g_bd.n_tex, g_bd.tex);
    }
    free(g_bd.tex);
    g_bd.tex = NULL;
    g_bd.n_tex = 0;
    g_bd.tex_gen = 0;
}

/* keep_tex: the textures stay (the next scene has the same ones) */
static void backdrop_free_scene(int keep_tex)
{
    if (!keep_tex) {
        backdrop_free_tex();
    }
    free(g_bd.piece);
    free(g_bd.order);
    free(g_bd.dist);
    free(g_bd.idx);
    free(g_bd.at);
    free(g_bd.bound);
    g_bd.bound = NULL;
    g_bd.at = NULL;
    g_bd.piece = NULL;
    g_bd.order = NULL;
    g_bd.dist = NULL;
    g_bd.idx = NULL;
    g_bd.idx_ok = 0;
    g_bd.n_piece = 0;
    g_bd.scene = NULL;
    g_bd.up_scene = NULL;
}

/* The see-through parts of a scene (see BdPiece). */
static void backdrop_pieces(const BmapScene *sc)
{
    unsigned i, n = 0, cap = 0;

    for (i = 0; i < sc->nd; i++) {
        const BmapDraw *d = &sc->d[i];
        unsigned a, e;

        if (!d->translucent || d->count == 0 || d->first + d->count > sc->nv) {
            continue;
        }
        for (a = d->first; a < d->first + d->count; a = e) {
            BdPiece *pc;
            unsigned j;

            /* one triangle (an object can be both near and far), or the
             * whole draw when only its soft edges blend */
            e = BD_SOFT_ONLY(d) ? d->first + d->count / 3u * 3u : a + 3;
            if (e > d->first + d->count || e == a) {
                break;              /* a draw whose count is not whole triangles */
            }
            if (n == cap) {
                unsigned ncap = cap ? cap * 2 : 64;
                BdPiece *np = (BdPiece *)realloc(g_bd.piece, ncap * sizeof *np);

                if (np == NULL) {
                    break;
                }
                g_bd.piece = np;
                cap = ncap;
            }
            pc = &g_bd.piece[n++];
            pc->draw = i;
            pc->first = a;
            pc->count = e - a;
            pc->mid[0] = pc->mid[1] = pc->mid[2] = 0.0f;
            for (j = a; j < e; j++) {
                pc->mid[0] += sc->v[j].x / (float)(e - a);
                pc->mid[1] += sc->v[j].y / (float)(e - a);
                pc->mid[2] += sc->v[j].z / (float)(e - a);
            }
        }
    }
    g_bd.n_piece = n;
    g_bd.order = (unsigned *)malloc((n > 0 ? n : 1) * sizeof *g_bd.order);
    g_bd.dist = (float *)malloc((n > 0 ? n : 1) * sizeof *g_bd.dist);
    {
        unsigned k, verts = 0;

        for (k = 0; k < n; k++) {
            verts += g_bd.piece[k].count;
        }
        g_bd.idx = (GLuint *)malloc((verts > 0 ? verts : 1) * sizeof *g_bd.idx);
    }
    g_bd.at = (unsigned *)malloc((n > 0 ? n : 1) * sizeof *g_bd.at);
    g_bd.idx_ok = 0;
    if (g_bd.order == NULL || g_bd.dist == NULL || g_bd.idx == NULL || g_bd.at == NULL) {
        g_bd.n_piece = 0;
    }
}

static int piece_far_first(const void *a, const void *b)
{
    float da = g_bd.dist[*(const unsigned *)a], db = g_bd.dist[*(const unsigned *)b];

    return da < db ? 1 : da > db ? -1 : 0;
}

static void backdrop_destroy(EidosGl *g)
{
    backdrop_free_scene(0);
    if (g_bd.vbo != 0) {
        g->glDeleteBuffers(1, &g_bd.vbo);
    }
    if (g_bd.ibo != 0) {
        g->glDeleteBuffers(1, &g_bd.ibo);
    }
    if (g_bd.vao != 0) {
        g->glDeleteVertexArrays(1, &g_bd.vao);
    }
    if (g_bd.prog != 0) {
        g->glDeleteProgram(g_bd.prog);
    }
    memset(&g_bd, 0, sizeof(g_bd));
}

static int backdrop_init(EidosGl *g)
{
    int i;

    g_bd.prog = eidos_gl_compile_program(g, k_vsb, k_fsb);
    if (g_bd.prog == 0) {
        return -1;
    }
    for (i = 0; i < 4; i++) {
        char nm[8];

        snprintf(nm, sizeof(nm), "u_r%d", i);
        g_bd.u_r[i] = g->glGetUniformLocation(g_bd.prog, nm);
    }
    g_bd.u_eye = g->glGetUniformLocation(g_bd.prog, "u_eye");
    g_bd.u_foc = g->glGetUniformLocation(g_bd.prog, "u_foc");
    g_bd.u_pivot = g->glGetUniformLocation(g_bd.prog, "u_pivot");
    g_bd.u_lift = g->glGetUniformLocation(g_bd.prog, "u_lift");
    g_bd.u_bb = g->glGetUniformLocation(g_bd.prog, "u_bb");
    g_bd.u_fog = g->glGetUniformLocation(g_bd.prog, "u_fog");
    g_bd.u_fogc = g->glGetUniformLocation(g_bd.prog, "u_fogc");
    g_bd.u_fog2 = g->glGetUniformLocation(g_bd.prog, "u_fog2");
    g_bd.u_tex = g->glGetUniformLocation(g_bd.prog, "u_tex");
    g_bd.u_texture = g->glGetUniformLocation(g_bd.prog, "u_texture");
    g_bd.u_alpha = g->glGetUniformLocation(g_bd.prog, "u_alpha");
    g_bd.u_cut = g->glGetUniformLocation(g_bd.prog, "u_cut");
    g_bd.u_cut_hi = g->glGetUniformLocation(g_bd.prog, "u_cut_hi");
    g_bd.u_front = g->glGetUniformLocation(g_bd.prog, "u_front");
    g_bd.u_poke = g->glGetUniformLocation(g_bd.prog, "u_poke");
    g_bd.u_npoke = g->glGetUniformLocation(g_bd.prog, "u_npoke");
    g_bd.u_clr = g->glGetUniformLocation(g_bd.prog, "u_clr");
    g_bd.u_nclr = g->glGetUniformLocation(g_bd.prog, "u_nclr");
    g_bd.u_grass = g->glGetUniformLocation(g_bd.prog, "u_grass");
    g_bd.u_leaf = g->glGetUniformLocation(g_bd.prog, "u_leaf");
    g_bd.u_only = g->glGetUniformLocation(g_bd.prog, "u_only");
    g_bd.u_tint = g->glGetUniformLocation(g_bd.prog, "u_tint");
    g_bd.u_uv0 = g->glGetUniformLocation(g_bd.prog, "u_uv0");
    g_bd.u_uv1 = g->glGetUniformLocation(g_bd.prog, "u_uv1");
    g_bd.u_sky = g->glGetUniformLocation(g_bd.prog, "u_sky");
    g_bd.u_skyu = g->glGetUniformLocation(g_bd.prog, "u_skyu");
    g_bd.u_skyv = g->glGetUniformLocation(g_bd.prog, "u_skyv");
    g->glGenVertexArrays(1, &g_bd.vao);
    g->glGenBuffers(1, &g_bd.vbo);
    g->glGenBuffers(1, &g_bd.ibo);
    return 0;
}

/* Upload a texture with a box-filtered mip chain (alpha-weighted colour, so
 * cut-out edges do not darken): the far map does not shimmer, the near map
 * keeps its crisp texels (nearest magnification). */
static void backdrop_mips(const BmapTexture *t)
{
    int w = t->w, h = t->h, lvl = 0, cut = 0;
    float cov = 0.0f;
    unsigned char *cur = (unsigned char *)malloc((size_t)w * h * 4);

    if (cur == NULL) {
        glTexImage2D(GL_TEXTURE_2D, 0, GL_RGBA8, t->w, t->h, 0, GL_RGBA,
                     GL_UNSIGNED_BYTE, t->rgba);
        glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAX_LEVEL, 0);
        return;
    }
    memcpy(cur, t->rgba, (size_t)w * h * 4);
    {
        int q, n = w * h, hard = 0, on = 0;

        for (q = 0; q < n; q++) {
            unsigned a = t->rgba[(size_t)q * 4 + 3];

            hard += a == 0u || a >= 248u;
            on += a >= 128u;
        }
        cut = hard * 10 >= n * 9 && on > 0 && on < n;
        cov = (float)on / (float)(n > 0 ? n : 1);
    }
    for (;;) {
        int nw, nh, x, y;
        unsigned char *nx;

        glTexImage2D(GL_TEXTURE_2D, lvl, GL_RGBA8, w, h, 0, GL_RGBA,
                     GL_UNSIGNED_BYTE, cur);
        if (w == 1 && h == 1) {
            break;
        }
        nw = w > 1 ? w / 2 : 1;
        nh = h > 1 ? h / 2 : 1;
        nx = (unsigned char *)malloc((size_t)nw * nh * 4);
        if (nx == NULL) {
            break;
        }
        for (y = 0; y < nh; y++) {
            for (x = 0; x < nw; x++) {
                unsigned sum[4] = { 0, 0, 0, 0 }, wa = 0, n = 0;
                int dx, dy, k;

                for (dy = 0; dy < 2; dy++) {
                    for (dx = 0; dx < 2; dx++) {
                        int sx = x * 2 + dx, sy = y * 2 + dy;
                        const unsigned char *p;

                        if (sx >= w) { sx = w - 1; }
                        if (sy >= h) { sy = h - 1; }
                        p = cur + ((size_t)sy * w + sx) * 4;
                        for (k = 0; k < 3; k++) {
                            sum[k] += (unsigned)p[k] * p[3];
                        }
                        sum[3] += p[3];
                        wa += p[3];
                        n++;
                    }
                }
                for (k = 0; k < 3; k++) {
                    nx[((size_t)y * nw + x) * 4 + k] =
                        wa > 0 ? (unsigned char)(sum[k] / wa) : 0;
                }
                nx[((size_t)y * nw + x) * 4 + 3] = (unsigned char)(sum[3] / n);
            }
        }
        if (cut) {
            /* keep the covered share of a cut-out texture: the alpha test
             * would otherwise eat the leaves at a distance */
            float lo = 1.0f, hi = 16.0f;
            int it, k2;

            for (it = 0; it < 12; it++) {
                float mid = 0.5f * (lo + hi);
                unsigned cnt = 0;

                for (k2 = 0; k2 < nw * nh; k2++) {
                    cnt += (float)nx[(size_t)k2 * 4 + 3] * mid >= 128.0f;
                }
                if ((float)cnt / (float)(nw * nh) < cov) {
                    lo = mid;
                } else {
                    hi = mid;
                }
            }
            for (k2 = 0; k2 < nw * nh; k2++) {
                float a2 = (float)nx[(size_t)k2 * 4 + 3] * hi;

                nx[(size_t)k2 * 4 + 3] = (unsigned char)(a2 > 255.0f ? 255.0f : a2);
            }
        }
        free(cur);
        cur = nx;
        w = nw;
        h = nh;
        lvl++;
    }
    free(cur);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAX_LEVEL, lvl);
}

/*
 * A new scene to the GPU: its textures (unless the same build's), its bounds, its see-through pieces, its vertices.
 * `gen` is the scene's generation.  Returns 1 when the scene is all there (g_bd.scene is it), 0 when more is to
 * come.  budget_ns 0: all of it now (the scene is on show).  Else a part a call: first the vertices with the bounds
 * and the pieces, then textures, as many a call as the time allows: a scene that is not shown yet goes up this way
 * over the blank frames before it shows (G3dBackdrop.warm), as in the native renderer (plat_sdlgpu3d.c, bd_upload:
 * the whole of it in the frame it first showed stood 0.1 s, more than the sound's queue holds).
 */
#define BD_WARM_NS 14000000u            /* a frame's share of an upload ahead: 14 ms */

static int backdrop_upload(EidosGl *g, const BmapScene *sc, unsigned gen, unsigned long long budget_ns)
{
    const unsigned long long t0 = bw_clock_ns();

    if (g_bd.up_scene != sc || g_bd.up_gen != gen) {
        /* it begins.  (Another placing of the same build, the spot editor's drags: its textures are already up,
         * mipmaps and all.) */
        const int keep = sc->tex_gen != 0 && sc->tex_gen == g_bd.tex_gen && sc->nt == g_bd.n_tex && g_bd.tex != NULL;

        backdrop_free_scene(keep);
        if (!keep && sc->nt > 0) {
            g_bd.tex = (GLuint *)calloc(sc->nt, sizeof(GLuint));
            if (g_bd.tex == NULL) {
                return 0;
            }
            g_bd.n_tex = sc->nt;
            g_bd.tex_gen = sc->tex_gen;
            glGenTextures((GLsizei)sc->nt, g_bd.tex);
        }
        g_bd.up_scene = sc;
        g_bd.up_gen = gen;
        g_bd.up_tex = keep ? sc->nt : 0u;
        g_bd.up_verts = 0;
    }
    if (!g_bd.up_verts) {
        free(g_bd.bound);
        g_bd.bound = sc->nd > 0 ? (BdBound *)malloc(sc->nd * sizeof *g_bd.bound) : NULL;
        if (g_bd.bound != NULL) {
            /* (BdBound is four floats: the scene's own when its placing made them, bmap.h) */
            if (sc->bound != NULL && sc->n_bound == sc->nd) {
                memcpy(g_bd.bound, sc->bound, sc->nd * sizeof *g_bd.bound);
            } else {
                bmap_draw_bounds(sc, (float (*)[4])g_bd.bound);
            }
        }
        backdrop_pieces(sc);
        g->glBindVertexArray(g_bd.vao);
        g->glBindBuffer(GL_ARRAY_BUFFER, g_bd.vbo);
        g->glBufferData(GL_ARRAY_BUFFER,
                        (GLsizeiptr)((size_t)sc->nv * sizeof(BmapVertex)), sc->v,
                        GL_STATIC_DRAW);
        g->glEnableVertexAttribArray(0);
        g->glVertexAttribPointer(0, 3, GL_FLOAT, GL_FALSE, sizeof(BmapVertex),
                                 (void *)offsetof(BmapVertex, x));
        g->glEnableVertexAttribArray(1);
        g->glVertexAttribPointer(1, 2, GL_FLOAT, GL_FALSE, sizeof(BmapVertex),
                                 (void *)offsetof(BmapVertex, u));
        g->glEnableVertexAttribArray(2);
        g->glVertexAttribPointer(2, 4, GL_UNSIGNED_BYTE, GL_TRUE,
                                 sizeof(BmapVertex),
                                 (void *)offsetof(BmapVertex, r));
        g_bd.up_verts = 1;
        if (budget_ns != 0 && g_bd.up_tex < sc->nt) {
            return 0;                   /* (the textures in the calls after this one) */
        }
    }
    if (g_bd.up_tex < sc->nt) {
        const unsigned first = g_bd.up_tex;

        glPixelStorei(GL_UNPACK_ALIGNMENT, 4);
        while (g_bd.up_tex < sc->nt && (budget_ns == 0 || g_bd.up_tex == first || bw_clock_ns() - t0 < budget_ns)) {
            const BmapTexture *t = &sc->t[g_bd.up_tex];

            glBindTexture(GL_TEXTURE_2D, g_bd.tex[g_bd.up_tex]);
            backdrop_mips(t);
            glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER,
                            GL_NEAREST_MIPMAP_LINEAR);
            glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_NEAREST);
            glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S,
                            !t->repeat_s ? GL_CLAMP_TO_EDGE
                            : t->flip_s ? GL_MIRRORED_REPEAT : GL_REPEAT);
            glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T,
                            !t->repeat_t ? GL_CLAMP_TO_EDGE
                            : t->flip_t ? GL_MIRRORED_REPEAT : GL_REPEAT);
            g_bd.up_tex++;
        }
        if (g_bd.up_tex < sc->nt) {
            return 0;                   /* (more textures in the next call) */
        }
    }
    g_bd.scene = sc;
    g_bd.gen = gen;
    g_bd.up_scene = NULL;
    return 1;
}

static void vcross(const float *a, const float *b, float *o)
{
    o[0] = a[1] * b[2] - a[2] * b[1];
    o[1] = a[2] * b[0] - a[0] * b[2];
    o[2] = a[0] * b[1] - a[1] * b[0];
}

static float vdot(const float *a, const float *b)
{
    return a[0] * b[0] + a[1] * b[1] + a[2] * b[2];
}

static void vnorm(float *v)
{
    float l = sqrtf(vdot(v, v));

    if (l > 1e-6f) {
        v[0] /= l; v[1] /= l; v[2] /= l;
    }
}

/* clip = the game's perspective (NNS_G3dGlbPerspectiveW) times its look-at,
 * x and y scaled by the view scale as the geometry engine does.  Row i gives
 * clip component i from (x, y, z, 1). */
static void backdrop_matrix(const G3dBackdrop *b, float r[4][4])
{
    float f[3], rt[3], u[3], t, m0, m5, a, c, ex, ey, ef, kx, ky;
    fx32 kxf, kyf;
    int i;

    g3d_mtx_view_scale(&kxf, &kyf);
    kx = (float)kxf / 4096.0f;
    ky = (float)kyf / 4096.0f;
    for (i = 0; i < 3; i++) {
        f[i] = b->target[i] - b->eye[i];
    }
    vnorm(f);
    vcross(f, b->up, rt);
    vnorm(rt);
    vcross(rt, f, u);
    t = b->fovy_sin / b->fovy_cos;
    m5 = 1.0f / t;
    m0 = m5 / b->aspect;
    a = -(b->zfar + b->znear) / (b->zfar - b->znear);
    c = -2.0f * b->zfar * b->znear / (b->zfar - b->znear);
    ex = vdot(rt, b->eye);
    ey = vdot(u, b->eye);
    ef = vdot(f, b->eye);
    for (i = 0; i < 3; i++) {
        r[0][i] = m0 * kx * rt[i];
        r[1][i] = m5 * ky * u[i];
        r[2][i] = -a * f[i];
        r[3][i] = f[i];
    }
    r[0][3] = -m0 * kx * ex;
    r[1][3] = -m5 * ky * ey;
    r[2][3] = a * ef + c;
    r[3][3] = -ef;
}

/* The battle backdrop's sprites (G3dBackdrop.key): the depth each one's
 * polygons write, the depth of its place along the camera's line of sight
 * (0.3 units nearer, so the ground at its feet stays behind it), the near
 * plane for one with a negative height (the player's own trainer: nothing of
 * the map in front of it).  `r` is the backdrop's matrix; the depth is the
 * depth buffer's (0..1 from GL's -1..1). */
static void sprite_depths(const G3dBackdrop *b, const float r[4][4], float out[G3D_BACKDROP_SPRITES])
{
    float fwd[3], l;
    unsigned i, k;

    for (k = 0; k < 3; k++) {
        fwd[k] = b->target[k] - b->eye[k];
    }
    l = sqrtf(fwd[0] * fwd[0] + fwd[1] * fwd[1] + fwd[2] * fwd[2]);
    for (i = 0; i < G3D_BACKDROP_SPRITES; i++) {
        float d, p[3], c[4];

        out[i] = 0.0f;
        if (i >= b->n_poke || l < 1e-6f || b->key[i][0] == 0xFFFFFFFFu) {
            continue;
        }
        if (b->poke[i][3] < 0.0f) {
            out[i] = 1e-6f;
            continue;
        }
        d = ((b->poke[i][0] - b->eye[0]) * fwd[0] + (b->poke[i][1] - b->eye[1]) * fwd[1] +
             (b->poke[i][2] - b->eye[2]) * fwd[2]) / l - 0.3f;
        if (d < b->znear * 1.01f) {
            out[i] = 1e-6f;
            continue;
        }
        for (k = 0; k < 3; k++) {
            p[k] = b->eye[k] + fwd[k] / l * d;
        }
        for (k = 0; k < 4; k++) {
            c[k] = r[k][0] * p[0] + r[k][1] * p[1] + r[k][2] * p[2] + r[k][3];
        }
        out[i] = c[3] > 1e-6f ? 0.5f * (c[2] / c[3]) + 0.5f : 1e-6f;
        out[i] = out[i] < 1e-6f ? 1e-6f : out[i] > 1.0f ? 1.0f : out[i];
    }
}

/* The sprite a game polygon is (its texture and palette, as the battle lists
 * them: bw_battle_view's snapshot_hook), or -1. */
static int sprite_of(const G3dBackdrop *b, const G3dPoly *p)
{
    unsigned i;

    for (i = 0; i < b->n_poke && i < G3D_BACKDROP_SPRITES; i++) {
        const u32 tex = b->key[i][0], pl = b->key[i][1];

        if (tex != 0xFFFFFFFFu && (p->teximage & 0xFFFFu) == ((tex >> 3) & 0xFFFFu) &&
            (p->pltt_base == (pl >> 4) || p->pltt_base == (pl >> 3))) {
            return (int)i;
        }
    }
    return -1;
}

/* Draw the scene.  The frame's framebuffer is bound and cleared. */
/* front: the second pass, after the game's polygons.  The game draws its
 * sprites without the map's depth, so the map would never hide a Pokemon;
 * this pass draws the map again where it stands between the camera and a
 * Pokemon (the shader keeps those parts only).  The depth is cleared over
 * the Pokemon's boxes first, so the parts drawn again hide one another in
 * the right order (a hedge before the ground behind it). */
static void front_depth_clear(const G3dBackdrop *b, const float r[4][4], float *box)
{
    GLint vp[4];
    float x0 = 1e9f, y0 = 1e9f, x1 = -1e9f, y1 = -1e9f;
    unsigned i, c;

    if (box != NULL) {              /* (`box`: the rectangle cleared, a little wider, for bmap_view_misses; empty: none) */
        box[0] = box[1] = 2.0f;
        box[2] = box[3] = -2.0f;
    }
    glGetIntegerv(GL_VIEWPORT, vp);
    for (i = 0; i < b->n_poke && i < G3D_BACKDROP_SPRITES; i++) {
        float d[3], L, n[3], side[3];

        for (c = 0; c < 3; c++) {
            d[c] = b->poke[i][c] - b->eye[c];
        }
        L = sqrtf(d[0] * d[0] + d[1] * d[1] + d[2] * d[2]);
        if (L < 1e-3f) {
            continue;
        }
        for (c = 0; c < 3; c++) {
            n[c] = d[c] / L;
        }
        side[0] = -n[2];
        side[1] = 0.0f;
        side[2] = n[0];
        {
            float sl = sqrtf(side[0] * side[0] + side[2] * side[2]);

            if (sl < 1e-3f) {
                continue;
            }
            side[0] /= sl;
            side[2] /= sl;
        }
        for (c = 0; c < 4; c++) {
            float p[3], cl[4];
            int k;
            float hgt = fabsf(b->poke[i][3]);
            float sx = (c & 1) ? 0.47f * hgt : -0.47f * hgt, uy = (c & 2) ? hgt : -1.0f;

            p[0] = b->poke[i][0] + side[0] * sx;
            p[1] = b->poke[i][1] + uy;
            p[2] = b->poke[i][2] + side[2] * sx;
            for (k = 0; k < 4; k++) {
                cl[k] = r[k][0] * p[0] + r[k][1] * p[1] + r[k][2] * p[2] + r[k][3];
            }
            if (cl[3] < 0.05f) {
                x0 = y0 = -1e9f;            /* behind the camera: the whole frame */
                x1 = y1 = 1e9f;
                continue;
            }
            x0 = fminf(x0, cl[0] / cl[3]);
            x1 = fmaxf(x1, cl[0] / cl[3]);
            y0 = fminf(y0, cl[1] / cl[3]);
            y1 = fmaxf(y1, cl[1] / cl[3]);
        }
    }
    if (x1 < x0) {
        return;
    }
    x0 = fmaxf(x0, -1.0f);
    y0 = fmaxf(y0, -1.0f);
    x1 = fminf(x1, 1.0f);
    y1 = fminf(y1, 1.0f);
    if (x1 <= x0 || y1 <= y0) {
        return;
    }
    if (box != NULL && vp[2] > 0 && vp[3] > 0) {
        box[0] = x0 - 8.0f / (float)vp[2];
        box[1] = y0 - 8.0f / (float)vp[3];
        box[2] = x1 + 8.0f / (float)vp[2];
        box[3] = y1 + 8.0f / (float)vp[3];
    }
    glEnable(GL_SCISSOR_TEST);
    glScissor(vp[0] + (GLint)floorf((x0 * 0.5f + 0.5f) * (float)vp[2]),
              vp[1] + (GLint)floorf((y0 * 0.5f + 0.5f) * (float)vp[3]),
              (GLsizei)ceilf((x1 - x0) * 0.5f * (float)vp[2]) + 2,
              (GLsizei)ceilf((y1 - y0) * 0.5f * (float)vp[3]) + 2);
    glDepthMask(GL_TRUE);
    glClear(GL_DEPTH_BUFFER_BIT);
    glDisable(GL_SCISSOR_TEST);
}

/* (research, BMAP_GRASS_LEAFRULE) the hand-made grass is laid over a Pokemon leaf by leaf and ring by ring (a
 * leaf always whole), not by the flat cut in front of the Pokemon (bmap_leaf.h). */
static int leaf_rule(void)
{
    return bmap_leaf_rule();
}

/* ... whether this frame's backdrop takes the rule in the game's own pass (the spot editor's views, front_only,
 * take it in their pass below) */
static int gl_leaf_on(const G3dBackdrop *b)
{
    const BmapScene *sc = (const BmapScene *)b->scene;

    return bmap_leaf_rule() && !b->front_only && b->n_poke > 0 && sc != NULL && sc->n_leaf > 0u && sc->leaf != NULL;
}

/* The leaves the rule moves in depth for this frame's camera and sprites (bmap_leaf_plan). */
static const BmapLeafItem *gl_leaf_items(const G3dBackdrop *b, const float r[4][4], unsigned *n)
{
    BmapLeafView v;
    unsigned i;

    memset(&v, 0, sizeof v);
    memcpy(v.eye, b->eye, sizeof v.eye);
    memcpy(v.target, b->target, sizeof v.target);
    v.znear = b->znear;
    v.np = b->n_poke < G3D_BACKDROP_SPRITES ? b->n_poke : G3D_BACKDROP_SPRITES;
    v.np = v.np < BMAP_LEAF_SPRITES ? v.np : BMAP_LEAF_SPRITES;
    for (i = 0; i < v.np; i++) {
        memcpy(v.poke[i], b->poke[i], sizeof v.poke[i]);
        v.covered[i] = b->key[i][0] != 0xFFFFFFFFu;
    }
    return bmap_leaf_plan((const BmapScene *)b->scene, b->scene_gen, &v, r, n);
}

/* One draw of hand-made grass in the depth passes round the game's sprites (backdrop_draw, front 4 and 5): its
 * vertices `first`..`first + count`, its state set.  Front 4: the draw at its own depth, but a leaf the rule lays
 * under a sprite whole at that depth alone, and a leaf it lays over a sprite a second time whole at that depth.
 * `back` (front 5, after the sprites): only the leaves laid under a sprite, at their own depth again: what the game
 * draws after its sprites (their shadows) is hidden under them as under any leaf. */
static void gl_leaf_draws(const BmapScene *sc, const BmapDraw *d, unsigned first, unsigned count, const BmapLeafItem *it,
                          unsigned n_it, int back)
{
    const unsigned l1 = d->leaf0 + d->nleaf;
    unsigned k = it != NULL ? bmap_leaf_seek(it, n_it, d->leaf0) : 0u, run0 = first;

    for (; it != NULL && k < n_it && it[k].leaf < l1; k++) {
        const BmapLeaf *lf = &sc->leaf[it[k].leaf];

        if (lf->count == 0u || lf->first < run0 || lf->first + lf->count > first + count) {
            continue;
        }
        if (it[k].under) {
            if (back) {
                glDrawArrays(GL_TRIANGLES, (GLint)lf->first, (GLsizei)lf->count);
                continue;
            }
            if (lf->first > run0) {
                glDrawArrays(GL_TRIANGLES, (GLint)run0, (GLsizei)(lf->first - run0));
            }
            run0 = lf->first + lf->count;
        } else if (back) {
            continue;
        }
        glDepthRange((double)it[k].at, (double)it[k].at);
        glDrawArrays(GL_TRIANGLES, (GLint)lf->first, (GLsizei)lf->count);
        glDepthRange(0.0, 1.0);
    }
    if (!back && first + count > run0) {
        glDrawArrays(GL_TRIANGLES, (GLint)run0, (GLsizei)(first + count - run0));
    }
}

static void backdrop_draw(EidosGl *g, const G3dBackdrop *b, int front)
{
    const BmapScene *sc = (const BmapScene *)b->scene;
    float r[4][4], fwd[3];
    unsigned pass, i;
    int leaf_pass = 0;
    /* (research, BMAP_GRASS_LEAFRULE) front 4: the depth over the sprites' boxes laid again before the game's
     * sprites, the hand-made grass leaf by leaf (gl_leaf_draws); front 5: the leaves laid under a sprite back at
     * their own depth.  No colour, the first pass's draws and state. */
    const int leaf_back = front == 5, leaf_fix = front == 4 || leaf_back;
    const BmapLeafItem *leaf_it = NULL;
    unsigned n_leaf_it = 0;
    /* (the part of the screen a draw must reach to be sent: all of it; in front 4 the rectangle cleared) */
    float view_box[4] = { -1.0f, -1.0f, 1.0f, 1.0f };
    /* (test switch EIDOS_ANIM_HOLD: the map's animations stand still, for captures that must be equal) */
    const Uint64 ticks = getenv("EIDOS_ANIM_HOLD") != NULL ? 0u : SDL_GetTicks();
    /* the field plays its animations a frame a field frame (60 a second) */
    unsigned uv_frame = (unsigned)(ticks * 60u / 1000u);
    int uv_set = 1;

    if (g_bd.prog == 0 || sc == NULL || sc->nv == 0) {
        return;
    }
    if (leaf_fix) {
        front = 0;
    }
    if (g_bd.scene != sc || g_bd.gen != b->scene_gen) {
        if (!backdrop_upload(g, sc, b->scene_gen, 0)) {
            return;
        }
    }
    backdrop_matrix(b, r);
    for (i = 0; i < 3; i++) {
        fwd[i] = b->target[i] - b->eye[i];
    }
    vnorm(fwd);
    g->glUseProgram(g_bd.prog);
    g->glBindVertexArray(g_bd.vao);
    g->glBindBuffer(GL_ARRAY_BUFFER, g_bd.vbo);
    for (i = 0; i < 4; i++) {
        g->glUniform4f(g_bd.u_r[i], r[i][0], r[i][1], r[i][2], r[i][3]);
    }
    g->glUniform3fv(g_bd.u_eye, 1, b->eye);
    g->glUniform1i(g_bd.u_front, front);
    g->glUniform1i(g_bd.u_npoke, (GLint)(b->n_poke > G3D_BACKDROP_SPRITES ? G3D_BACKDROP_SPRITES : b->n_poke));
    g->glUniform4fv(g_bd.u_poke, G3D_BACKDROP_SPRITES, &b->poke[0][0]);
    g->glUniform1i(g_bd.u_nclr, (GLint)(b->n_clear > G3D_BACKDROP_CLEAR ? G3D_BACKDROP_CLEAR : b->n_clear));
    g->glUniform4fv(g_bd.u_clr, G3D_BACKDROP_CLEAR, &b->clear[0][0]);
    g->glUniform3fv(g_bd.u_foc, 1, b->target);
    g->glUniform1i(g_bd.u_leaf, 0);
    g->glUniform1f(g_bd.u_tint, getenv("BMAP_FRONT_TINT") != NULL ? 0.75f : 0.0f);   /* (research) */
    g->glUniform1i(g_bd.u_only, -1);
    {
        /* the zone's fog, or the weather's: by the depth along the field
         * camera's line of sight past the battle's place (BmapScene.fog_k,
         * bmap_place); the colour's fourth: 0 off, 1 even, else 1 + the
         * fog's curve (BmapScene.fog_curve) */
        float fc[4] = { 0.0f, 0.0f, 0.0f, 0.0f }, fk[4];

        if (sc->fog_on && sc->fog_end > sc->fog_start
            && (sc->fog_k[0] != 0.0f || sc->fog_k[1] != 0.0f || sc->fog_k[2] != 0.0f)) {
            fc[0] = (float)sc->fog[0] / 255.0f;
            fc[1] = (float)sc->fog[1] / 255.0f;
            fc[2] = (float)sc->fog[2] / 255.0f;
            fc[3] = sc->fog_curve > 0.0f ? 1.0f + sc->fog_curve : 1.0f;
        }
        bmap_fog_k(sc, b->eye, fwd, fk);
        g->glUniform4fv(g_bd.u_fog, 1, fk);
        bmap_fog_k2(sc, b->eye, fwd, fk);
        g->glUniform4fv(g_bd.u_fog2, 1, fk);
        g->glUniform4fv(g_bd.u_fogc, 1, fc);
    }
    g->glActiveTexture(GL_TEXTURE0);
    g->glUniform1i(g_bd.u_texture, 0);
    glDisable(GL_STENCIL_TEST);
    if (front && !b->front_only) {
        /* the game's sprites wrote the depth of their places (sprite_depths): the map nearer than a sprite
         * hid it in the ordinary test; this pass lays the see-through map again where it is nearer than what
         * the game drew, over the game's pixels only */
        front = 3;
        g->glUniform1i(g_bd.u_front, front);
        glEnable(GL_STENCIL_TEST);
        glStencilFunc(GL_EQUAL, STENCIL_GAME, STENCIL_GAME);
        glStencilOp(GL_KEEP, GL_KEEP, GL_KEEP);
    } else if (front) {
        front_depth_clear(b, (const float (*)[4])r, NULL);
        if (!b->front_only) {
            /* only where the game drew (its sprites, their shadows and
             * effects): the map in front of a sprite covers the sprite and
             * nothing else, whatever the sprite's size */
            glEnable(GL_STENCIL_TEST);
            glStencilFunc(GL_EQUAL, STENCIL_GAME, STENCIL_GAME);
            glStencilOp(GL_KEEP, GL_KEEP, GL_KEEP);
        }
    }
    if (leaf_fix) {
        if (!leaf_back) {
            front_depth_clear(b, (const float (*)[4])r, view_box);
        }
        glColorMask(GL_FALSE, GL_FALSE, GL_FALSE, GL_FALSE);
        leaf_it = gl_leaf_items(b, (const float (*)[4])r, &n_leaf_it);
    }
    glEnable(GL_DEPTH_TEST);
    glDepthFunc(GL_LESS);
    glEnable(GL_POLYGON_OFFSET_FILL);
    glPolygonOffset(0.0f, 1.0f); /* no slope term: it pushed far, grazing triangles over the near map */
    g->glColorMaski(1, GL_FALSE, GL_FALSE, GL_FALSE, GL_FALSE);
    if (!front && !leaf_fix && sc->sky_count > 0u && sc->sky_first + sc->sky_count <= sc->nv && sc->sky_tex >= 0
        && (unsigned)sc->sky_tex < g_bd.n_tex) {
        /* the sky pass: the cloud dome first, blended over the clear colour, writing no depth (all the map
         * draws over it) */
        const float k = sc->place_k > 0.0f ? sc->place_k : BMAP_PLACE_K;
        static const float m[6] = { 1.0f, 0.0f, 0.0f, 0.0f, 1.0f, 0.0f };
        float su[3], sv[3];

        bmap_sky_uv(sc, su, sv);
        glDisable(GL_CULL_FACE);
        glEnable(GL_BLEND);
        g->glBlendFuncSeparate(GL_ONE, GL_ONE_MINUS_SRC_ALPHA, GL_ONE, GL_ONE_MINUS_SRC_ALPHA);
        glDepthMask(GL_FALSE);
        glBindTexture(GL_TEXTURE_2D, g_bd.tex[sc->sky_tex]);
        g->glUniform1i(g_bd.u_tex, 1);
        g->glUniform3fv(g_bd.u_uv0, 1, m);
        g->glUniform3fv(g_bd.u_uv1, 1, m + 3);
        g->glUniform1i(g_bd.u_bb, 0);
        g->glUniform1i(g_bd.u_grass, 0);
        g->glUniform1f(g_bd.u_lift, 0.0f);
        g->glUniform1f(g_bd.u_alpha, 26.0f / 31.0f);
        g->glUniform4f(g_bd.u_sky, 1.0f, sc->sky_h * k, 0.0f, sc->sky_tilt);
        g->glUniform3fv(g_bd.u_skyu, 1, su);
        g->glUniform3fv(g_bd.u_skyv, 1, sv);
        glDrawArrays(GL_TRIANGLES, (GLint)sc->sky_first, (GLsizei)sc->sky_count);
        g->glUniform4f(g_bd.u_sky, 0.0f, 0.0f, 0.0f, 0.0f);
    }
    leaf_pass = front == 1 && b->front_only && sc->n_leaf > 0u && sc->leaf != NULL && leaf_rule();
    for (pass = front == 3 ? 1 : 0; pass < (leaf_fix ? 1u : 2u); pass++) {
        if (pass == 1) {
            glEnable(GL_BLEND);
            g->glBlendFuncSeparate(GL_ONE, GL_ONE_MINUS_SRC_ALPHA, GL_ONE,
                                   GL_ONE_MINUS_SRC_ALPHA);
            glDepthMask(GL_FALSE);
        } else {
            glDisable(GL_BLEND);
            glDepthMask(GL_TRUE);
        }
        unsigned n = pass == 1 && g_bd.n_piece > 0 ? g_bd.n_piece : sc->nd;
        int sorted = pass == 1 && g_bd.n_piece > 0;

        if (sorted && !(g_bd.idx_ok && g_bd.idx_eye[0] == b->eye[0] &&
                        g_bd.idx_eye[1] == b->eye[1] && g_bd.idx_eye[2] == b->eye[2])) {
            /* the see-through parts far to near from this camera, as one
             * index buffer (the back and the front pass share it) */
            for (i = 0; i < g_bd.n_piece; i++) {
                const float *m = g_bd.piece[i].mid;
                float dx = m[0] - b->eye[0], dy = m[1] - b->eye[1], dz = m[2] - b->eye[2];

                g_bd.order[i] = i;
                g_bd.dist[i] = dx * dx + dy * dy + dz * dz;
            }
            qsort(g_bd.order, g_bd.n_piece, sizeof *g_bd.order, piece_far_first);
            g_bd.n_idx = 0;
            for (i = 0; i < g_bd.n_piece; i++) {
                const BdPiece *pc = &g_bd.piece[g_bd.order[i]];
                unsigned k;

                g_bd.at[i] = g_bd.n_idx;
                for (k = 0; k < pc->count; k++) {
                    g_bd.idx[g_bd.n_idx++] = pc->first + k;
                }
            }
            g->glBindBuffer(GL_ELEMENT_ARRAY_BUFFER, g_bd.ibo);
            g->glBufferData(GL_ELEMENT_ARRAY_BUFFER,
                            (GLsizeiptr)((size_t)g_bd.n_idx * sizeof *g_bd.idx),
                            g_bd.idx, GL_STREAM_DRAW);
            memcpy(g_bd.idx_eye, b->eye, sizeof g_bd.idx_eye);
            g_bd.idx_ok = 1;
        }
        for (i = 0; i < n; i++) {
            const BmapDraw *d;
            unsigned first, count, run = 1, di;

            if (sorted) {
                const BdPiece *pc = &g_bd.piece[g_bd.order[i]];

                di = pc->draw;
                d = &sc->d[di];
                first = pc->first;
                count = pc->count;
                /* the next triangles in the order that come from the same
                 * draw (the same texture and state): one call for all */
                while (i + run < n && g_bd.piece[g_bd.order[i + run]].draw == pc->draw) {
                    run++;
                }
            } else {
                di = i;
                d = &sc->d[i];
                first = d->first;
                count = d->count;
            }
            /* the surf mount while the Pokemon surfed on is out itself */
            if (d->mount && bmap_mount_hidden()) {
                i += run - 1;
                continue;
            }
            /* (research) the hand-made grass leaves are laid over the sprites leaf by leaf, below */
            if ((leaf_pass && d->leafy) || (leaf_back && !d->leafy)) {
                i += run - 1;
                continue;
            }
            /* a draw wholly behind the camera is not sent */
            if (g_bd.bound != NULL && di < sc->nd) {
                const BdBound *bb = &g_bd.bound[di];
                float depth = fwd[0] * (bb->c[0] - b->eye[0]) + fwd[1] * (bb->c[1] - b->eye[1])
                              + fwd[2] * (bb->c[2] - b->eye[2]);

                if (depth < -bb->r || (!d->bob && bmap_view_misses((const float (*)[4])r, view_box, bb->c, bb->r))) {
                    i += run - 1;
                    continue;
                }
            }
            /* the depth pass also takes the solid texels of a draw whose
             * soft edges blend later */
            if (((d->translucent != 0) != (pass == 1)
                 && !(pass == 0 && d->translucent && BD_SOFT_ONLY(d)))
                || count == 0 || d->alpha == 0 || first + count > sc->nv) {
                i += run - 1;
                continue;
            }
            if (d->cull == 0) {
                glDisable(GL_CULL_FACE);
            } else {
                glEnable(GL_CULL_FACE);
                glCullFace(d->cull == 1 ? GL_BACK : GL_FRONT);
            }
            if (d->tex >= 0 && (unsigned)d->tex < g_bd.n_tex) {
                glBindTexture(GL_TEXTURE_2D, g_bd.tex[d->tex]);
                g->glUniform1i(g_bd.u_tex, 1);
            } else {
                g->glUniform1i(g_bd.u_tex, 0);
            }
            if (d->uvanim != 0 && d->uvanim <= sc->nuva && sc->uva[d->uvanim - 1].frames > 0) {
                const BmapUvAnim *ua = &sc->uva[d->uvanim - 1];
                const float *m = ua->m + (size_t)(uv_frame % ua->frames) * 6u;

                g->glUniform3fv(g_bd.u_uv0, 1, m);
                g->glUniform3fv(g_bd.u_uv1, 1, m + 3);
                uv_set = 1;
            } else if (uv_set) {
                static const float id[6] = { 1.0f, 0.0f, 0.0f, 0.0f, 1.0f, 0.0f };

                g->glUniform3fv(g_bd.u_uv0, 1, id);
                g->glUniform3fv(g_bd.u_uv1, 1, id + 3);
                uv_set = 0;
            }
            g->glUniform1i(g_bd.u_bb, d->billboard == 3 ? 0 : d->billboard);   /* (3: placed as one, never turned) */
            g->glUniform1i(g_bd.u_grass, d->grass);
            g->glUniform3fv(g_bd.u_pivot, 1, d->pivot);
            /* a moving object rises and falls as its animation does in the field (30 frames a second) */
            g->glUniform1f(g_bd.u_lift, d->bob && sc->bob_n > 0u
                           ? sc->place_k * sc->bob_y[(ticks * 30u / 1000u) % sc->bob_n] : 0.0f);
            g->glUniform1f(g_bd.u_alpha, (float)d->alpha / 31.0f);
            if (pass == 0) {
                g->glUniform1f(g_bd.u_cut, d->translucent ? BD_CORE_CUT : 0.5f);
                g->glUniform1f(g_bd.u_cut_hi, 2.0f);
            } else {
                g->glUniform1f(g_bd.u_cut, 0.02f);
                g->glUniform1f(g_bd.u_cut_hi, BD_SOFT_ONLY(d) ? BD_CORE_CUT : 2.0f);
            }
            if (sorted) {
                unsigned end = i + run < g_bd.n_piece ? g_bd.at[i + run] : g_bd.n_idx;

                glDrawElements(GL_TRIANGLES, (GLsizei)(end - g_bd.at[i]), GL_UNSIGNED_INT,
                               (const void *)((size_t)g_bd.at[i] * sizeof(GLuint)));
                i += run - 1;
            } else if (leaf_fix && d->leafy) {
                gl_leaf_draws(sc, d, first, count, leaf_it, n_leaf_it, leaf_back);
            } else {
                glDrawArrays(GL_TRIANGLES, (GLint)first, (GLsizei)count);
            }
        }
    }
    if (leaf_fix) {
        glColorMask(GL_TRUE, GL_TRUE, GL_TRUE, GL_TRUE);
    }
    if (leaf_pass) {
        /* (research, BMAP_GRASS_LEAFRULE) the hand-made grass over each Pokemon, leaf by leaf and ring by ring:
         * a leaf is laid whole over a Pokemon or not at all.  While the Pokemon stands outside a ring's reach,
         * the whole ring goes by its bush's heart (nearer the eye than the Pokemon: over it).  While it stands
         * inside the reach, a leaf of that ring is over it when the leaf reaches past it toward the eye (its tip
         * nearer the eye than the Pokemon's feet). */
        static const float id[6] = { 1.0f, 0.0f, 0.0f, 0.0f, 1.0f, 0.0f };
        static GLuint *lidx;
        static unsigned lcap;
        static GLuint lbo;
        unsigned pi, li;

        if (lbo == 0) {
            g->glGenBuffers(1, &lbo);
        }
        glDisable(GL_BLEND);
        glDepthMask(GL_TRUE);
        glDisable(GL_CULL_FACE);
        g->glUniform1i(g_bd.u_leaf, 1);
        g->glUniform1i(g_bd.u_bb, 0);
        g->glUniform1f(g_bd.u_lift, 0.0f);
        g->glUniform1f(g_bd.u_cut, 0.5f);
        g->glUniform1f(g_bd.u_cut_hi, 2.0f);
        g->glUniform3fv(g_bd.u_uv0, 1, id);
        g->glUniform3fv(g_bd.u_uv1, 1, id + 3);
        g->glBindBuffer(GL_ELEMENT_ARRAY_BUFFER, lbo);
        for (pi = 0; pi < b->n_poke && pi < G3D_BACKDROP_SPRITES; pi++) {
            const float *pp = b->poke[pi];
            float cx = b->eye[0] - pp[0], cz = b->eye[2] - pp[2];
            const float cl = sqrtf(cx * cx + cz * cz);

            if (pp[3] <= 0.0f || cl < 1e-3f) {      /* (a shield is never covered) */
                continue;
            }
            cx /= cl;
            cz /= cl;
            g->glUniform1i(g_bd.u_only, (GLint)pi);
            for (li = 0; li < sc->n_leaf;) {
                const unsigned di = sc->leaf[li].draw;
                const BmapDraw *d = di < sc->nd ? &sc->d[di] : NULL;
                unsigned n = 0;

                for (; li < sc->n_leaf && sc->leaf[li].draw == di; li++) {
                    const BmapLeaf *lf = &sc->leaf[li];
                    const float hx = lf->heart[0] - pp[0], hz = lf->heart[1] - pp[2];
                    const float val = sqrtf(hx * hx + hz * hz) > lf->reach
                                          ? hx * cx + hz * cz
                                          : (lf->tip[0] - pp[0]) * cx + (lf->tip[2] - pp[2]) * cz;
                    unsigned k;

                    /* (not over it; or too far to the side of the line from the eye to stand over its picture) */
                    if (val <= 0.0f || lf->count == 0u || lf->first + lf->count > sc->nv
                        || fabsf(hz * cx - hx * cz) > pp[3] + lf->reach + 1.0f) {
                        continue;
                    }
                    if (n + lf->count > lcap) {
                        const unsigned nc = (n + lf->count) * 2u + 4096u;
                        GLuint *ni = (GLuint *)realloc(lidx, nc * sizeof *ni);

                        if (ni == NULL) {
                            continue;
                        }
                        lidx = ni;
                        lcap = nc;
                    }
                    for (k = 0; k < lf->count; k++) {
                        lidx[n++] = lf->first + k;
                    }
                }
                if (n == 0u || d == NULL) {
                    continue;
                }
                if (d->tex >= 0 && (unsigned)d->tex < g_bd.n_tex) {
                    glBindTexture(GL_TEXTURE_2D, g_bd.tex[d->tex]);
                    g->glUniform1i(g_bd.u_tex, 1);
                } else {
                    g->glUniform1i(g_bd.u_tex, 0);
                }
                g->glUniform1i(g_bd.u_grass, d->grass);
                g->glUniform1f(g_bd.u_alpha, (float)d->alpha / 31.0f);
                g->glBufferData(GL_ELEMENT_ARRAY_BUFFER, (GLsizeiptr)((size_t)n * sizeof *lidx), lidx, GL_STREAM_DRAW);
                glDrawElements(GL_TRIANGLES, (GLsizei)n, GL_UNSIGNED_INT, (const void *)0);
            }
        }
        g->glUniform1i(g_bd.u_leaf, 0);
        g->glUniform1i(g_bd.u_only, -1);
        g->glBindBuffer(GL_ELEMENT_ARRAY_BUFFER, g_bd.ibo);
    }
    glDepthMask(GL_TRUE);
    glDisable(GL_BLEND);
    glDisable(GL_CULL_FACE);
    glDisable(GL_POLYGON_OFFSET_FILL);
    g->glColorMaski(1, GL_TRUE, GL_TRUE, GL_TRUE, GL_TRUE);
}

static u8 c5to8(u32 v)
{
    v &= 31u;
    return (u8)((v << 3) | (v >> 2));
}

int eidos_gl3d_init(EidosGl *g)
{
    g->p3d = eidos_gl_compile_program(g, k_vs3, k_fs3);
    if (g->p3d == 0) {
        return -1;
    }
#define LOC(field, name) g->field = g->glGetUniformLocation(g->p3d, name)
    LOC(u_mode, "u_mode");
    LOC(u_alpha5, "u_alpha5");
    LOC(u_tex3, "u_tex");
    LOC(u_texture, "u_texture");
    LOC(u_texsize3, "u_texsize");
    LOC(u_wrap, "u_wrap");
    LOC(u_alpharef, "u_alpharef");
    LOC(u_toon, "u_toon");
    LOC(u_highlight, "u_highlight");
    LOC(u_toontab, "u_toontab");
    LOC(u_front, "u_front");
    LOC(u_back, "u_back");
    LOC(u_wbuf, "u_wbuf");
    LOC(u_zover, "u_zover");
    LOC(u_zref, "u_zref");
    LOC(u_sfog, "u_sfog");
    LOC(u_pass, "u_pass");
    LOC(u_id, "u_id");
#undef LOC
    /* Edge marking is optional: without it, frames that use it stay on the
     * CPU rasteriser (g3d_hw_gpu_features). */
    g->pedge = eidos_gl_compile_program(g, k_vse, k_fse);
    if (g->pedge != 0) {
        g->ue_col = g->glGetUniformLocation(g->pedge, "u_col");
        g->ue_id = g->glGetUniformLocation(g->pedge, "u_id");
        g->ue_dep = g->glGetUniformLocation(g->pedge, "u_dep");
        g->ue_step = g->glGetUniformLocation(g->pedge, "u_step");
        g->ue_variant = g->glGetUniformLocation(g->pedge, "u_variant");
        g->ue_cid = g->glGetUniformLocation(g->pedge, "u_cid");
        g->ue_cdep = g->glGetUniformLocation(g->pedge, "u_cdep");
        g->ue_edge = g->glGetUniformLocation(g->pedge, "u_edge");
    }
    /* Fog likewise (the fog pass reads the same three targets). */
    g->pfog = eidos_gl_compile_program(g, k_vse, k_fsf);
    if (g->pfog != 0) {
        g->uf_col = g->glGetUniformLocation(g->pfog, "u_col");
        g->uf_id = g->glGetUniformLocation(g->pfog, "u_id");
        g->uf_dep = g->glGetUniformLocation(g->pfog, "u_dep");
        g->uf_fog = g->glGetUniformLocation(g->pfog, "u_fog");
        g->uf_table = g->glGetUniformLocation(g->pfog, "u_table");
        g->uf_offset = g->glGetUniformLocation(g->pfog, "u_offset");
        g->uf_step = g->glGetUniformLocation(g->pfog, "u_step");
        g->uf_aonly = g->glGetUniformLocation(g->pfog, "u_aonly");
        g->uf_clear = g->glGetUniformLocation(g->pfog, "u_clear");
    }
    /* The battle backdrop is optional too: without its program the game's
     * own scenery is not drawn either and the frame has only the sky
     * colour. */
    (void)backdrop_init(g);
    g->glGenFramebuffers(1, &g->fb[0].fbo);
    g->glGenFramebuffers(1, &g->fb[1].fbo);
    g->glGenFramebuffers(1, &g->fb[2].fbo);
    /* OpenGL ES 3.0 has no GL_MAX_INTEGER_SAMPLES (3.1 does): an error
     * there means none, and must not fail the whole 3D renderer */
    g->integer_samples = 0;
    glGetIntegerv(GL_MAX_INTEGER_SAMPLES, &g->integer_samples);
    if (glGetError() != GL_NO_ERROR) {
        g->integer_samples = 0;
    }
    /* the phone hosts draw with OpenGL ES and say so (host/main.c); the
     * Switch's host makes desktop OpenGL or OpenGL ES, so the context says:
     * OpenGL ES has no profile mask (an error), desktop OpenGL 3.2 and up
     * has one.  The query's error is read every time: left pending (the
     * phones name ES first and skipped the read), the check below took it
     * for a failure and the 3D renderer went off, so the one-screen world
     * never drew and the DS screens showed under its menus */
    {
        GLint mask = 0;
        int mask_err;

        while (glGetError() != GL_NO_ERROR) {
        }
        glGetIntegerv(0x9126 /* GL_CONTEXT_PROFILE_MASK */, &mask);
        mask_err = glGetError() != GL_NO_ERROR;
        g->es = getenv("EIDOS_GL_ES") != NULL || mask_err || mask == 0;
    }
    g->glGenVertexArrays(1, &g->vao3);
    g->glGenBuffers(1, &g->vbo3);
    g->have3d = 1;
    if (glGetError() != GL_NO_ERROR) {
        return -1;
    }
    g3d_hw_gpu_features((g->pedge != 0 ? G3D_SNAP_EDGE : 0u)
                        | (g->pfog != 0 ? G3D_SNAP_FOG : 0u));
    return 0;
}

void eidos_gl3d_destroy(EidosGl *g)
{
    unsigned i;

    for (i = 0; i < 3; i++) {
        GlFb *f = &g->fb[i];

        if (f->fbo != 0) {
            g->glDeleteFramebuffers(1, &f->fbo);
        }
        if (f->depth != 0) {
            glDeleteTextures(1, &f->depth);
        }
        if (f->color != 0) {
            glDeleteTextures(1, &f->color);
            glDeleteTextures(1, &f->pid);
            glDeleteTextures(1, &f->color2);
        }
        if (f->post_fbo != 0) {
            g->glDeleteFramebuffers(1, &f->post_fbo);
        }
        if (f->ms_fbo != 0) {
            g->glDeleteFramebuffers(1, &f->ms_fbo);
            g->glDeleteRenderbuffers(1, &f->ms_color);
            g->glDeleteRenderbuffers(1, &f->ms_depth);
            g->glDeleteRenderbuffers(1, &f->ms_id);
        }
    }
    if (g->vbo3 != 0) {
        g->glDeleteBuffers(1, &g->vbo3);
    }
    if (g->vao3 != 0) {
        g->glDeleteVertexArrays(1, &g->vao3);
    }
    if (g->p3d != 0) {
        g->glDeleteProgram(g->p3d);
    }
    if (g->pedge != 0) {
        g->glDeleteProgram(g->pedge);
    }
    if (g->pfog != 0) {
        g->glDeleteProgram(g->pfog);
    }
    backdrop_destroy(g);
    g3d_hw_gpu_features(0u);
    for (i = 0; i < g->n_gtex; i++) {
        glDeleteTextures(1, &g->gtex[i]);
    }
    free(g->gtex);
    free(g->gtex_key);
    free(g->vtx);
}

static void tex_params(GLint filter)
{
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, filter);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, filter);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_CLAMP_TO_EDGE);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_CLAMP_TO_EDGE);
}

/* Attach `color`, the ID buffer and the depth to the frame's FBO, and
 * `color2` to the edge pass's.  The two colour textures swap after an
 * edge pass, so this runs again then. */
static int fbo_attach(EidosGl *g, GlFb *f)
{
    static const GLenum bufs[2] = { GL_COLOR_ATTACHMENT0, GL_COLOR_ATTACHMENT1 };

    g->glBindFramebuffer(GL_FRAMEBUFFER, f->fbo);
    g->glFramebufferTexture2D(GL_FRAMEBUFFER, GL_COLOR_ATTACHMENT0,
                              GL_TEXTURE_2D, f->color, 0);
    g->glFramebufferTexture2D(GL_FRAMEBUFFER, GL_COLOR_ATTACHMENT1,
                              GL_TEXTURE_2D, f->pid, 0);
    g->glFramebufferTexture2D(GL_FRAMEBUFFER, GL_DEPTH_STENCIL_ATTACHMENT,
                              GL_TEXTURE_2D, f->depth, 0);
    g->glDrawBuffers(2, bufs);
    if (g->glCheckFramebufferStatus(GL_FRAMEBUFFER) != GL_FRAMEBUFFER_COMPLETE) {
        g->glBindFramebuffer(GL_FRAMEBUFFER, 0);
        return -1;
    }
    g->glBindFramebuffer(GL_FRAMEBUFFER, f->post_fbo);
    g->glFramebufferTexture2D(GL_FRAMEBUFFER, GL_COLOR_ATTACHMENT0,
                              GL_TEXTURE_2D, f->color2, 0);
    if (g->glCheckFramebufferStatus(GL_FRAMEBUFFER) != GL_FRAMEBUFFER_COMPLETE) {
        g->glBindFramebuffer(GL_FRAMEBUFFER, 0);
        return -1;
    }
    return 0;
}

static int fbo_resize(EidosGl *g, GlFb *f, int w, int h)
{
    if (f->w == w && f->h == h && f->color != 0) {
        return 0;
    }
    if (f->color == 0) {
        glGenTextures(1, &f->color);
        glGenTextures(1, &f->color2);
        glGenTextures(1, &f->pid);
        glGenTextures(1, &f->depth);
        g->glGenFramebuffers(1, &f->post_fbo);
    }
    glBindTexture(GL_TEXTURE_2D, f->color);
    glTexImage2D(GL_TEXTURE_2D, 0, GL_RGBA8, w, h, 0, GL_RGBA,
                 GL_UNSIGNED_BYTE, NULL);
    tex_params(GL_LINEAR);
    glBindTexture(GL_TEXTURE_2D, f->color2);
    glTexImage2D(GL_TEXTURE_2D, 0, GL_RGBA8, w, h, 0, GL_RGBA,
                 GL_UNSIGNED_BYTE, NULL);
    tex_params(GL_LINEAR);
    glBindTexture(GL_TEXTURE_2D, f->pid);
    glTexImage2D(GL_TEXTURE_2D, 0, GL_R8UI, w, h, 0, GL_RED_INTEGER,
                 GL_UNSIGNED_BYTE, NULL);
    tex_params(GL_NEAREST);
    glBindTexture(GL_TEXTURE_2D, f->depth);
    glTexImage2D(GL_TEXTURE_2D, 0, GL_DEPTH24_STENCIL8, w, h, 0,
                 GL_DEPTH_STENCIL, GL_UNSIGNED_INT_24_8, NULL);
    tex_params(GL_NEAREST);
    if (fbo_attach(g, f) != 0) {
        return -1;
    }
    f->w = w;
    f->h = h;
    return 0;
}

/* The edge-marking pass: the frame's colour, ID and depth in, the marked
 * frame out into color2, which then becomes the frame's colour. */
static void edge_pass(EidosGl *g, GlFb *f, const G3dSnapshot *s, int w,
                      double clear_depth)
{
    GLfloat edge[24];
    GLuint t;
    int k, step = w / 256, variant = g->edge_mode == 1 ? 1 : 3;

    {
        /* EIDOS_EDGE / EIDOS_EDGE_WIDTH: the variants side by side (above) */
        const char *e = getenv("EIDOS_EDGE"), *ew = getenv("EIDOS_EDGE_WIDTH");

        if (e != NULL && e[0] >= '0' && e[0] <= '7') {
            variant = e[0] - '0';
        }
        if (variant == 5) {
            step = (step + 1) / 2;
        }
        if (ew != NULL && atoi(ew) > 0) {
            step = atoi(ew) + 1;
        }
    }

    for (k = 0; k < 8; k++) {
        u32 c = s->edge[k];

        edge[k * 3 + 0] = (float)c5to8(c) / 255.f;
        edge[k * 3 + 1] = (float)c5to8(c >> 5) / 255.f;
        edge[k * 3 + 2] = (float)c5to8(c >> 10) / 255.f;
    }
    g->glBindFramebuffer(GL_FRAMEBUFFER, f->post_fbo);
    glViewport(0, 0, f->w, f->h);
    g->glUseProgram(g->pedge);
    g->glActiveTexture(GL_TEXTURE0);
    glBindTexture(GL_TEXTURE_2D, f->color);
    g->glActiveTexture(GL_TEXTURE1);
    glBindTexture(GL_TEXTURE_2D, f->pid);
    g->glActiveTexture(GL_TEXTURE2);
    glBindTexture(GL_TEXTURE_2D, f->depth);
    g->glUniform1i(g->ue_col, 0);
    g->glUniform1i(g->ue_id, 1);
    g->glUniform1i(g->ue_dep, 2);
    g->glUniform1i(g->ue_step, step < 1 ? 1 : step);
    g->glUniform1i(g->ue_variant, variant);
    g->glUniform1ui(g->ue_cid, (GLuint)((s->clear_color >> 24) & 0x3Fu));
    g->glUniform1f(g->ue_cdep, (GLfloat)clear_depth);
    g->glUniform3fv(g->ue_edge, 8, edge);
    g->glBindVertexArray(g->vao3);
    glDrawArrays(GL_TRIANGLES, 0, 3);
    glBindTexture(GL_TEXTURE_2D, 0);
    g->glActiveTexture(GL_TEXTURE1);
    glBindTexture(GL_TEXTURE_2D, 0);
    g->glActiveTexture(GL_TEXTURE0);
    t = f->color;
    f->color = f->color2;
    f->color2 = t;
    (void)fbo_attach(g, f);
}

/* The fog pass: the frame's colour, ID and depth in, the fogged frame out
 * into color2, which then becomes the frame's colour (k_fsf). */
static void fog_pass(EidosGl *g, GlFb *f, const G3dSnapshot *s)
{
    GLfloat table[32];
    GLuint t;
    u32 fc = s->fog_color, cc = s->clear_color;
    u32 shift = (s->disp3dcnt >> 8) & 0xFu;
    int k;

    for (k = 0; k < 32; k++) {
        table[k] = (GLfloat)s->fog_table[k];
    }
    g->glBindFramebuffer(GL_FRAMEBUFFER, f->post_fbo);
    glViewport(0, 0, f->w, f->h);
    g->glUseProgram(g->pfog);
    g->glActiveTexture(GL_TEXTURE0);
    glBindTexture(GL_TEXTURE_2D, f->color);
    g->glActiveTexture(GL_TEXTURE1);
    glBindTexture(GL_TEXTURE_2D, f->pid);
    g->glActiveTexture(GL_TEXTURE2);
    glBindTexture(GL_TEXTURE_2D, f->depth);
    g->glUniform1i(g->uf_col, 0);
    g->glUniform1i(g->uf_id, 1);
    g->glUniform1i(g->uf_dep, 2);
    g->glUniform4f(g->uf_fog, (float)c5to8(fc) / 255.f,
                   (float)c5to8(fc >> 5) / 255.f, (float)c5to8(fc >> 10) / 255.f,
                   (float)((fc >> 16) & 0x1Fu) / 31.f);
    g->glUniform1fv(g->uf_table, 32, table);
    g->glUniform1f(g->uf_offset, (GLfloat)(s->fog_offset & 0x7FFFu));
    g->glUniform1f(g->uf_step, shift > 10u ? 0.f : (GLfloat)(0x400u >> shift));
    g->glUniform1i(g->uf_aonly, (s->disp3dcnt & 0x40u) != 0);
    {
        GLfloat clear[3];

        clear[0] = (float)c5to8(cc) / 255.f;
        clear[1] = (float)c5to8(cc >> 5) / 255.f;
        clear[2] = (float)c5to8(cc >> 10) / 255.f;
        g->glUniform3fv(g->uf_clear, 1, clear);
    }
    g->glBindVertexArray(g->vao3);
    glDrawArrays(GL_TRIANGLES, 0, 3);
    glBindTexture(GL_TEXTURE_2D, 0);
    g->glActiveTexture(GL_TEXTURE1);
    glBindTexture(GL_TEXTURE_2D, 0);
    g->glActiveTexture(GL_TEXTURE0);
    t = f->color;
    f->color = f->color2;
    f->color2 = t;
    (void)fbo_attach(g, f);
}

/*
 * DISP3DCNT bit 4 turns on the hardware's edge anti-aliasing.  The GPU's
 * equivalent is multisampling: render into a 4-sample target and resolve it
 * into the frame's texture.  Not worth its memory at a large size, where the
 * resolution does the same job.
 */
#define MSAA_SAMPLES 4
#define MSAA_MAX_PIXELS (2048 * 1536)

static int msaa_target(EidosGl *g, GlFb *f, int w, int h)
{
    /* the ID buffer is an integer target: a driver whose integer formats
     * take fewer samples (macOS: GL_MAX_INTEGER_SAMPLES is 1) rejects its
     * storage with GL_INVALID_OPERATION, and that error failed the frame */
    static GLint samples = -1;
    int fresh;

    if (samples < 0) {
        GLint any = 0, integer = 0;

        glGetIntegerv(GL_MAX_SAMPLES, &any);
        glGetIntegerv(GL_MAX_INTEGER_SAMPLES, &integer);
        if (glGetError() != GL_NO_ERROR) {
            integer = 0;            /* OpenGL ES 3.0: no multisampled IDs */
        }
        samples = any < integer ? any : integer;
    }
    if (samples < MSAA_SAMPLES || (long)w * (long)h > MSAA_MAX_PIXELS) {
        return 0;
    }
    if (f->ms_fbo == 0) {
        g->glGenFramebuffers(1, &f->ms_fbo);
        g->glGenRenderbuffers(1, &f->ms_color);
        g->glGenRenderbuffers(1, &f->ms_depth);
        g->glGenRenderbuffers(1, &f->ms_id);
    }
    fresh = f->ms_w != w || f->ms_h != h;
    if (fresh) {
        g->glBindRenderbuffer(GL_RENDERBUFFER, f->ms_color);
        g->glRenderbufferStorageMultisample(GL_RENDERBUFFER, MSAA_SAMPLES, GL_RGBA8, w, h);
        g->glBindRenderbuffer(GL_RENDERBUFFER, f->ms_depth);
        g->glRenderbufferStorageMultisample(GL_RENDERBUFFER, MSAA_SAMPLES, GL_DEPTH24_STENCIL8, w, h);
        /* the ID buffer too, so that edge marking and fog, which read it,
         * can run on an anti-aliased frame (resolved from sample 0) */
        g->glBindRenderbuffer(GL_RENDERBUFFER, f->ms_id);
        g->glRenderbufferStorageMultisample(GL_RENDERBUFFER, MSAA_SAMPLES, GL_R8UI, w, h);
        g->glBindFramebuffer(GL_FRAMEBUFFER, f->ms_fbo);
        g->glFramebufferRenderbuffer(GL_FRAMEBUFFER, GL_COLOR_ATTACHMENT0, GL_RENDERBUFFER, f->ms_color);
        g->glFramebufferRenderbuffer(GL_FRAMEBUFFER, GL_COLOR_ATTACHMENT1, GL_RENDERBUFFER, f->ms_id);
        g->glFramebufferRenderbuffer(GL_FRAMEBUFFER, GL_DEPTH_STENCIL_ATTACHMENT, GL_RENDERBUFFER, f->ms_depth);
        {
            static const GLenum both[2] = { GL_COLOR_ATTACHMENT0, GL_COLOR_ATTACHMENT1 };

            g->glDrawBuffers(2, both);
        }
        f->ms_w = w;
        f->ms_h = h;
    }
    g->glBindFramebuffer(GL_FRAMEBUFFER, f->ms_fbo);
    /* asked when the storage is made, not every frame: the answer does not
     * change while the storage stands, and the question waits for the
     * driver's own thread (a target that fails is made again next frame) */
    if (fresh && g->glCheckFramebufferStatus(GL_FRAMEBUFFER) != GL_FRAMEBUFFER_COMPLETE) {
        f->ms_w = 0;
        return 0;
    }
    return 1;
}

#define ATTR_DEFAULT (((u32)1 << 6) | ((u32)1 << 7) | ((u32)31 << 16))

/* What a snapshot texture holds, for the upload cache: FNV-1a over its size
 * and texels (0 is kept for "nothing uploaded"). */
static unsigned tex_key(const G3dSnapTex *t)
{
    unsigned h = 2166136261u;
    size_t i, n = (size_t)t->w * t->h * 4u;
    const u32 *w = (const u32 *)t->rgba;

    h = (h ^ t->w) * 16777619u;
    h = (h ^ t->h) * 16777619u;
    if (t->content != 0) {
        /* the snapshot knows what the texels came from: no need to read them */
        h = (h ^ (unsigned)t->content) * 16777619u;
        h = (h ^ (unsigned)(t->content >> 32)) * 16777619u;
        return h != 0 ? h : 1u;
    }
    for (i = 0; t->rgba != NULL && i < n / 4u; i++) {
        h = (h ^ w[i]) * 16777619u;
    }
    return h != 0 ? h : 1u;
}

/* Render the snapshot at w x h into the framebuffer; the colour texture is
 * then eidos_gl_3d_texture(g).  Returns 0, or -1 if the GPU path cannot
 * draw this frame. */
/* One run of polygons that share their state (render_into). */
typedef struct Gl3dRun {
    int deq, mask, xlu_depth, mode, toon, a5, front, back;
    int textured, slot, wrap, id, two_pass;
    int fog;           /* POLYGON_ATTR bit 15: ID buffer bit 6           */
    float zo;          /* a backdrop sprite's depth (sprite_depths), 0: the polygon's own */
    float zref;        /* ... and the own depth of that sprite's first cell */
    float sfog;        /* the map's fog at a backdrop sprite's place (BmapScene.fog_sprites), 0: none */
} Gl3dRun;

/* What the runs of one pass last sent (draw_run): a value that stays is not
 * sent again.  -1: not sent yet in this pass. */
typedef struct RunSent {
    GLint mode, toon, a5, front, back, tex3, tw, th, wrap, id;
    GLint stencil;      /* the stencil function: 0 always, else the reference of "not equal" */
    float zo;           /* u_zover (-1: not sent) */
    float zref;
    float sfog;         /* u_sfog's fourth (-1: not sent) */
    GLint cmask;        /* colour mask of target 1 */
} RunSent;

static void run_sent_reset(RunSent *st)
{
    st->mode = st->toon = st->a5 = st->front = st->back = st->tex3 = st->tw = st->th = st->wrap = st->id = -1;
    st->stencil = -1;
    st->cmask = -1;
    st->zo = -1.0f;
    st->zref = -2.0f;
    st->sfog = -1.0f;
}

static void run_stencil(RunSent *st, GLint ref)
{
    if (st->stencil != ref) {
        if (ref == 0) {
            glStencilFunc(GL_ALWAYS, STENCIL_GAME, 0xFFu);
        } else {
            glStencilFunc(GL_NOTEQUAL, ref, STENCIL_IDS);
        }
        st->stencil = ref;
    }
}

static void run_cmask(EidosGl *g, RunSent *st, GLint on)
{
    if (st->cmask != on) {
        g->glColorMaski(1, on ? GL_TRUE : GL_FALSE, on ? GL_TRUE : GL_FALSE, on ? GL_TRUE : GL_FALSE,
                        on ? GL_TRUE : GL_FALSE);
        st->cmask = on;
    }
}

#define RUN_UNIFORM(field, loc, value) \
    do { \
        GLint v_ = (GLint)(value); \
        if (st->field != v_) { \
            g->glUniform1i(loc, v_); \
            st->field = v_; \
        } \
    } while (0)

static void draw_run(EidosGl *g, const G3dSnapshot *s, const Gl3dRun *d,
                     unsigned first, unsigned verts, int *prev_depth_eq,
                     int *prev_mask, s32 *bound_tex, RunSent *st)
{
    GLint xid = (GLint)(0x40 | d->id);
    GLint uid = (GLint)(0x80 | (d->fog ? 0x40 : 0) | d->id);

    if (d->deq != *prev_depth_eq) {
        glDepthFunc(d->deq ? GL_LEQUAL : GL_LESS);
        *prev_depth_eq = d->deq;
    }
    if (d->mask != *prev_mask) {
        glDepthMask(d->mask ? GL_TRUE : GL_FALSE);
        *prev_mask = d->mask;
    }
    RUN_UNIFORM(mode, g->u_mode, d->mode);
    RUN_UNIFORM(toon, g->u_toon, d->toon);
    RUN_UNIFORM(a5, g->u_alpha5, d->a5);
    RUN_UNIFORM(front, g->u_front, d->front);
    RUN_UNIFORM(back, g->u_back, d->back);
    if (st->zo != d->zo) {
        g->glUniform1f(g->u_zover, d->zo);
        st->zo = d->zo;
    }
    if (st->zref != d->zref) {
        g->glUniform1f(g->u_zref, d->zref);
        st->zref = d->zref;
    }
    if (st->sfog != d->sfog) {
        const BmapScene *bsc = (const BmapScene *)s->backdrop.scene;
        float f4[4] = { 0.0f, 0.0f, 0.0f, d->sfog };

        if (bsc != NULL) {
            f4[0] = (float)bsc->fog[0] / 255.0f;
            f4[1] = (float)bsc->fog[1] / 255.0f;
            f4[2] = (float)bsc->fog[2] / 255.0f;
        }
        g->glUniform4fv(g->u_sfog, 1, f4);
        st->sfog = d->sfog;
    }
    if (d->textured) {
        GLint tw = (GLint)s->tex[d->slot].w, th = (GLint)s->tex[d->slot].h;

        if (*bound_tex != d->slot) {
            glBindTexture(GL_TEXTURE_2D, g->gtex[d->slot]);
            *bound_tex = d->slot;
        }
        RUN_UNIFORM(tex3, g->u_tex3, 1);
        if (st->tw != tw || st->th != th) {
            g->glUniform2i(g->u_texsize3, tw, th);
            st->tw = tw;
            st->th = th;
        }
        if (st->wrap != (GLint)d->wrap) {
            g->glUniform4i(g->u_wrap, (GLint)(d->wrap & 1), (GLint)((d->wrap >> 1) & 1),
                           (GLint)((d->wrap >> 2) & 1), (GLint)((d->wrap >> 3) & 1));
            st->wrap = (GLint)d->wrap;
        }
    } else {
        RUN_UNIFORM(tex3, g->u_tex3, 0);
    }
    RUN_UNIFORM(id, g->u_id, uid);
    if (d->two_pass) {
        /* An opaque polygon whose texture has partly transparent
         * texels: the hardware decides per pixel from the final alpha,
         * so the opaque texels write depth and the translucent ones
         * do not (unless bit 11 says so).  One draw cannot do both:
         * two passes can. */
        glDepthMask(GL_TRUE);
        run_stencil(st, 0);
        g->glUniform1i(g->u_pass, 1);
        run_cmask(g, st, 1);
        glDrawArrays(GL_TRIANGLES, (GLint)first, (GLsizei)verts);
        glDepthMask(d->xlu_depth ? GL_TRUE : GL_FALSE);
        run_stencil(st, xid | STENCIL_GAME);
        g->glUniform1i(g->u_pass, 2);
        /* a translucent pixel keeps the ID beneath it */
        run_cmask(g, st, 0);
        glDrawArrays(GL_TRIANGLES, (GLint)first, (GLsizei)verts);
        g->glUniform1i(g->u_pass, 0);
        *prev_mask = d->xlu_depth;
    } else {
        run_stencil(st, d->a5 >= 31 ? 0 : (xid | STENCIL_GAME));
        run_cmask(g, st, d->a5 >= 31);
        glDrawArrays(GL_TRIANGLES, (GLint)first, (GLsizei)verts);
    }
}

static int render_into(EidosGl *g, GlFb *fb, const G3dSnapshot *s, int w, int h)
{
    unsigned i, nv = 0;
    size_t need;
    u32 cc, alpha;
    u8 cr, cg, cb;
    s32 bound_tex = -2;
    int prev_depth_eq = -1, prev_mask = -1;
    GLfloat toon[96];
    unsigned long long t_up, t_dr;
    int use_ms, edges, fog, backdrop;
    double cdepth;

    if (g == NULL || !g->have3d || s == NULL || w < 1 || h < 1) {
        return -1;
    }
    backdrop = s->backdrop.valid && g_bd.prog != 0 && !s->wbuffer;
    if (fbo_resize(g, fb, w, h) != 0) {
        return -1;
    }

    /* textures: one GL texture per snapshot texture */
    while (g->n_gtex < s->n_tex) {
        if (g->n_gtex == g->cap_gtex) {
            unsigned c = g->cap_gtex ? g->cap_gtex * 2u : 16u;
            GLuint *n = (GLuint *)realloc(g->gtex, (size_t)c * sizeof(*n));
            unsigned *k;

            if (n == NULL) {
                return -1;
            }
            g->gtex = n;
            k = (unsigned *)realloc(g->gtex_key, (size_t)c * sizeof(*k));
            if (k == NULL) {
                return -1;
            }
            g->gtex_key = k;
            g->cap_gtex = c;
        }
        g->gtex_key[g->n_gtex] = 0;
        glGenTextures(1, &g->gtex[g->n_gtex]);
        glBindTexture(GL_TEXTURE_2D, g->gtex[g->n_gtex]);
        glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_NEAREST);
        glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_NEAREST);
        glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_CLAMP_TO_EDGE);
        glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_CLAMP_TO_EDGE);
        g->n_gtex++;
    }
    glPixelStorei(GL_UNPACK_ALIGNMENT, 4);
    t_up = eidos_prof_begin();
    /* Upload only what changed: the same snapshot is drawn twice in a frame
     * (the window's size and the DS size), and most textures stay from one
     * frame to the next.  Re-specifying a texture the GPU is still drawing
     * from can make the driver wait for that draw. */
    if (!g->tex_serial_valid || g->tex_serial != s->serial) {
        for (i = 0; i < s->n_tex; i++) {
            unsigned key = tex_key(&s->tex[i]);

            if (g->gtex_key[i] == key && key != 0) {
                continue;
            }
            g->gtex_key[i] = key;
            glBindTexture(GL_TEXTURE_2D, g->gtex[i]);
            glTexImage2D(GL_TEXTURE_2D, 0, GL_RGBA8, (GLsizei)s->tex[i].w,
                         (GLsizei)s->tex[i].h, 0, GL_RGBA, GL_UNSIGNED_BYTE,
                         s->tex[i].rgba);
        }
        g->tex_serial = s->serial;
        g->tex_serial_valid = 1;
    }

    eidos_prof_end(EIDOS_PROF_GLUP, t_up);
    t_dr = eidos_prof_begin();
    /* vertices: each polygon as a fan of triangles */
    need = (size_t)s->n_polys * 6u * FLOATS_PER_VERTEX;
    if (need > g->cap_vtx) {
        float *n = (float *)realloc(g->vtx, need * sizeof(float));

        if (n == NULL) {
            return -1;
        }
        g->vtx = n;
        g->cap_vtx = need;
    }
    for (i = 0; i < s->n_polys; i++) {
        const G3dPoly *p = &s->polys[i];
        static const unsigned fan[6] = { 0, 1, 2, 0, 2, 3 };
        unsigned tri, k, ntri;

        if (p->count < 3u || p->count > 4u) {
            continue;
        }
        ntri = p->count - 2u;
        for (tri = 0; tri < ntri * 3u; tri++) {
            const G3dVertex *v = &s->verts[s->idx[p->first + fan[tri]]];
            float *o = g->vtx + (size_t)nv * FLOATS_PER_VERTEX;

            o[0] = (float)v->x; o[1] = (float)v->y;
            o[2] = (float)v->z; o[3] = (float)v->w;
            o[4] = (float)v->s; o[5] = (float)v->t;
            o[6] = (float)v->r; o[7] = (float)v->g; o[8] = (float)v->b;
            nv++;
            (void)k;
        }
    }

    /* Edge marking needs the ID buffer, which the multisampled target does
     * not carry; at a large size the resolution smooths the edges anyway. */
    edges = (s->disp3dcnt & 0x20u) != 0 && g->pedge != 0 && g->edge_mode != 0 &&
            !(getenv("EIDOS_EDGE") != NULL && getenv("EIDOS_EDGE")[0] == '0');
    fog = (s->disp3dcnt & 0x80u) != 0 && g->pfog != 0;
    use_ms = g->integer_samples >= MSAA_SAMPLES &&
             (s->disp3dcnt & 0x10u) != 0 && msaa_target(g, fb, w, h);
    if (!use_ms) {
        g->glBindFramebuffer(GL_FRAMEBUFFER, fb->fbo);
    }
    glViewport(0, 0, w, h);
    glDisable(GL_CULL_FACE);
    glDisable(GL_SCISSOR_TEST);
    glDepthMask(GL_TRUE);
    glColorMask(GL_TRUE, GL_TRUE, GL_TRUE, GL_TRUE);

    /* the clear plane: premultiplied colour, alpha as set */
    cc = s->clear_color;
    alpha = ((cc >> 16) & 0x1Fu) * 255u / 31u;
    cr = c5to8(cc);
    cg = c5to8(cc >> 5);
    cb = c5to8(cc >> 10);
    if (backdrop) {
        /* the sky beyond the map; opaque, the 2D layers are behind it */
        alpha = 255u;
        cr = s->backdrop.sky[0];
        cg = s->backdrop.sky[1];
        cb = s->backdrop.sky[2];
    }
    if (backdrop && s->backdrop.front_only) {
        alpha = 0u;                     /* only the front pass shows */
    }
    glClearColor((float)cr / 255.f * (float)alpha / 255.f,
                 (float)cg / 255.f * (float)alpha / 255.f,
                 (float)cb / 255.f * (float)alpha / 255.f,
                 (float)alpha / 255.f);
    cdepth = s->wbuffer ? (double)(s->clear_depth & 0x7FFFu) / 32768.0
                        : ((s->clear_depth & 0x7FFFu) == 0x7FFFu
                           ? 1.0
                           : (double)(s->clear_depth & 0x7FFFu) / 32767.0);
    glClearDepth(cdepth);
    glStencilMask(0xFFu);
    glClearStencil(0);
    {
        /* the ID buffer is an integer target: cleared on its own, to the
         * clear plane's polygon ID (multisampled or not) */
        GLfloat c4[4];
        GLuint id4[4] = { 0, 0, 0, 0 };

        c4[0] = (float)cr / 255.f * (float)alpha / 255.f;
        c4[1] = (float)cg / 255.f * (float)alpha / 255.f;
        c4[2] = (float)cb / 255.f * (float)alpha / 255.f;
        c4[3] = (float)alpha / 255.f;
        id4[0] = ((cc >> 24) & 0x3Fu) | ((cc & 0x8000u) ? 0x40u : 0u);
        g->glColorMaski(1, GL_TRUE, GL_TRUE, GL_TRUE, GL_TRUE);
        g->glClearBufferfv(GL_COLOR, 0, c4);
        g->glClearBufferuiv(GL_COLOR, 1, id4);
        glClear(GL_DEPTH_BUFFER_BIT | GL_STENCIL_BUFFER_BIT);
    }

    if (backdrop) {
        if (s->backdrop.front_only) {
            glColorMask(GL_FALSE, GL_FALSE, GL_FALSE, GL_FALSE);
        }
        backdrop_draw(g, &s->backdrop, 0);
        glColorMask(GL_TRUE, GL_TRUE, GL_TRUE, GL_TRUE);
        if (s->backdrop.scene == NULL && s->backdrop.warm != NULL) {
            /* the battle's scene is not shown yet (the blank frames before the intro's first view): a part of
             * it sent now, so the frame it first shows only draws it */
            const BmapScene *wsc = (const BmapScene *)s->backdrop.warm;

            if (wsc->nv != 0 && (g_bd.scene != wsc || g_bd.gen != s->backdrop.warm_gen)) {
                (void)backdrop_upload(g, wsc, s->backdrop.warm_gen, BD_WARM_NS);
            }
        }
    }
    if (nv > 0) {
        unsigned drawn = 0, first = 0;

        g->glBindVertexArray(g->vao3);
        g->glBindBuffer(GL_ARRAY_BUFFER, g->vbo3);
        g->glBufferData(GL_ARRAY_BUFFER,
                        (GLsizeiptr)((size_t)nv * FLOATS_PER_VERTEX * sizeof(float)),
                        g->vtx, GL_STREAM_DRAW);
        g->glEnableVertexAttribArray(0);
        g->glVertexAttribPointer(0, 4, GL_FLOAT, GL_FALSE,
                                 FLOATS_PER_VERTEX * sizeof(float), (void *)0);
        g->glEnableVertexAttribArray(1);
        g->glVertexAttribPointer(1, 2, GL_FLOAT, GL_FALSE,
                                 FLOATS_PER_VERTEX * sizeof(float),
                                 (void *)(4 * sizeof(float)));
        g->glEnableVertexAttribArray(2);
        g->glVertexAttribPointer(2, 3, GL_FLOAT, GL_FALSE,
                                 FLOATS_PER_VERTEX * sizeof(float),
                                 (void *)(6 * sizeof(float)));

        g->glUseProgram(g->p3d);
        glEnable(GL_DEPTH_TEST);
        /* The stencil holds 0x40 | the polygon ID of the translucent pixel
         * last drawn (0: none, or an opaque pixel since): the hardware does
         * not draw a translucent pixel over one of the same ID. */
        glEnable(GL_STENCIL_TEST);
        glStencilOp(GL_KEEP, GL_KEEP, GL_REPLACE);
        glEnable(GL_BLEND);
        g->glBlendFuncSeparate(GL_ONE, GL_ONE_MINUS_SRC_ALPHA, GL_ONE,
                               GL_ONE_MINUS_SRC_ALPHA);
        for (i = 0; i < 96u; i++) {
            toon[i] = (float)s->toon[i];
        }
        g->glUniform3fv(g->u_toontab, 32, toon);
        g->glUniform1i(g->u_texture, 0);
        g->glActiveTexture(GL_TEXTURE0);
        g->glUniform1i(g->u_alpharef, (GLint)s->alpha_ref);
        g->glUniform1i(g->u_highlight, (GLint)s->highlight);
        g->glUniform1i(g->u_wbuf, (GLint)s->wbuffer);

        {
            /* Consecutive polygons with the same state are one draw: the
             * hardware's order is the order of the vertices inside a draw
             * as much as between draws (depth, blending and the stencil
             * test see the same sequence), so the result is the same with
             * a fraction of the calls.  A field frame has thousands of
             * polygons and a few dozen states. */
            Gl3dRun run, cur;
            unsigned run_first = 0, run_verts = 0;
            int have = 0;
            RunSent sent;
            float sz[G3D_BACKDROP_SPRITES], zr[G3D_BACKDROP_SPRITES];
            unsigned char zr_set[G3D_BACKDROP_SPRITES];
            /* (research, BMAP_GRASS_LEAFRULE) 0: the map's own depth; 1: the leaf depth pass is laid (from the
             * game's first sprite polygon on); 2: the leaves under a sprite are back at their own depth (from
             * the first polygon after the sprites on) */
            const int leaf_on = backdrop && gl_leaf_on(&s->backdrop);
            int leaf_state = 0;

            memset(sz, 0, sizeof sz);
            memset(zr, 0, sizeof zr);
            memset(zr_set, 0, sizeof zr_set);
            if (backdrop && s->backdrop.n_poke > 0) {
                float br[4][4];

                backdrop_matrix(&s->backdrop, br);
                sprite_depths(&s->backdrop, (const float (*)[4])br, sz);
            }

            run_sent_reset(&sent);
            memset(&run, 0, sizeof(run));
            memset(&cur, 0, sizeof(cur));
            for (i = 0; i < s->n_polys; i++) {
                const G3dPoly *p = &s->polys[i];
                u32 attr = p->attr, mode, a5, ti;
                u32 verts;
                s32 slot = s->poly_tex[i];

                if (p->count < 3u || p->count > 4u) {
                    continue;
                }
                verts = (p->count - 2u) * 3u;
                if (attr == 0) {
                    attr = ATTR_DEFAULT;
                }
                mode = G3D_ATTR_MODE(attr);
                a5 = G3D_ATTR_ALPHA(attr);
                if (a5 == 0 || mode == G3D_POLY_MODE_SHADOW) {
                    first += verts;
                    continue;
                }
                ti = p->teximage;
                cur.deq = G3D_ATTR_DEPTH_EQ(attr) != 0;
                cur.mask = (a5 >= 31u) || G3D_ATTR_XLU_DEPTH(attr);
                cur.xlu_depth = G3D_ATTR_XLU_DEPTH(attr) != 0;
                cur.mode = mode == G3D_POLY_MODE_DECAL ? 1
                         : mode == G3D_POLY_MODE_TOON ? 2 : 0;
                cur.toon = mode == G3D_POLY_MODE_TOON;
                cur.a5 = (int)a5;
                cur.front = G3D_ATTR_FRONT(attr) != 0;
                cur.back = G3D_ATTR_BACK(attr) != 0;
                cur.textured = slot >= 0 && (s->disp3dcnt & 1u);
                cur.slot = cur.textured ? slot : -1;
                cur.wrap = cur.textured ? (int)(G3D_TEX_REPEAT_S(ti) | (G3D_TEX_REPEAT_T(ti) << 1)
                                                | (G3D_TEX_FLIP_S(ti) << 2) | (G3D_TEX_FLIP_T(ti) << 3)) : 0;
                cur.id = (int)G3D_ATTR_ID(attr);
                cur.two_pass = a5 >= 31u && cur.textured && s->tex[slot].partial;
                cur.fog = G3D_ATTR_FOG(attr) != 0;
                {
                    const int k = backdrop && s->backdrop.n_poke > 0 ? sprite_of(&s->backdrop, p) : -1;

                    if (leaf_on && ((k >= 0 && leaf_state == 0) || (k < 0 && leaf_state == 1))) {
                        if (have) {
                            draw_run(g, s, &run, run_first, run_verts, &prev_depth_eq,
                                     &prev_mask, &bound_tex, &sent);
                            drawn++;
                            have = 0;
                        }
                        leaf_state++;
                        backdrop_draw(g, &s->backdrop, 3 + leaf_state);
                        /* (the game's polygons again: their buffer, program and state as before the loop,
                         * and nothing of a run taken as sent) */
                        g->glBindVertexArray(g->vao3);
                        g->glBindBuffer(GL_ARRAY_BUFFER, g->vbo3);
                        g->glUseProgram(g->p3d);
                        glEnable(GL_DEPTH_TEST);
                        glEnable(GL_STENCIL_TEST);
                        glStencilOp(GL_KEEP, GL_KEEP, GL_REPLACE);
                        glEnable(GL_BLEND);
                        g->glBlendFuncSeparate(GL_ONE, GL_ONE_MINUS_SRC_ALPHA, GL_ONE,
                                               GL_ONE_MINUS_SRC_ALPHA);
                        g->glActiveTexture(GL_TEXTURE0);
                        prev_depth_eq = -1;
                        prev_mask = -1;
                        bound_tex = -2;
                        run_sent_reset(&sent);
                    }
                    if (k >= 0 && getenv("EIDOS_HIDE_SPRITES") != NULL) {    /* (research: the map alone, to compare) */
                        first += verts;
                        continue;
                    }
                    cur.zo = k >= 0 ? sz[k] : 0.0f;
                    cur.zref = 0.0f;
                    cur.sfog = 0.0f;
                    if (k >= 0 && s->backdrop.scene != NULL && ((const BmapScene *)s->backdrop.scene)->fog_sprites) {
                        /* (the setting Extras > Weather haze: the sprite takes the fog of its place) */
                        float fw[3];

                        fw[0] = s->backdrop.target[0] - s->backdrop.eye[0];
                        fw[1] = s->backdrop.target[1] - s->backdrop.eye[1];
                        fw[2] = s->backdrop.target[2] - s->backdrop.eye[2];
                        vnorm(fw);
                        cur.sfog = bmap_fog_at((const BmapScene *)s->backdrop.scene, s->backdrop.eye, fw, s->backdrop.poke[k]);
                    }
                    if (k >= 0) {
                        if (!zr_set[k]) {       /* (the sprite's first cell this frame: its own depth) */
                            const G3dVertex *v0 = &s->verts[s->idx[p->first]];

                            zr[k] = v0->w != 0 ? 0.5f * ((float)v0->z / (float)v0->w) + 0.5f : 0.0f;
                            zr_set[k] = 1;
                        }
                        cur.zref = zr[k];
                    }
                }
                if (have && run_first + run_verts == first
                    && memcmp(&run, &cur, sizeof(run)) == 0) {
                    run_verts += verts;
                } else {
                    if (have) {
                        draw_run(g, s, &run, run_first, run_verts, &prev_depth_eq,
                                 &prev_mask, &bound_tex, &sent);
                        drawn++;
                    }
                    run = cur;
                    run_first = first;
                    run_verts = verts;
                    have = 1;
                }
                first += verts;
            }
            if (have) {
                draw_run(g, s, &run, run_first, run_verts, &prev_depth_eq,
                         &prev_mask, &bound_tex, &sent);
                drawn++;
            }
        }
        (void)drawn;
    }
    if (backdrop && s->backdrop.n_poke > 0) {
        backdrop_draw(g, &s->backdrop, 1);
    }
    glDepthMask(GL_TRUE);
    glDisable(GL_DEPTH_TEST);
    glDisable(GL_STENCIL_TEST);
    glDisable(GL_BLEND);
    g->glColorMaski(1, GL_TRUE, GL_TRUE, GL_TRUE, GL_TRUE);
    if (use_ms) {
        /* resolve the samples into the frame's targets: the colour averaged,
         * the ID buffer and the depth from one sample (integer and depth
         * targets do not average), which the passes below read */
        static const GLenum c0[1] = { GL_COLOR_ATTACHMENT0 };
        static const GLenum c1[1] = { GL_COLOR_ATTACHMENT1 };
        static const GLenum both[2] = { GL_COLOR_ATTACHMENT0, GL_COLOR_ATTACHMENT1 };

        g->glBindFramebuffer(GL_READ_FRAMEBUFFER, fb->ms_fbo);
        g->glBindFramebuffer(GL_DRAW_FRAMEBUFFER, fb->fbo);
        glReadBuffer(GL_COLOR_ATTACHMENT0);
        g->glDrawBuffers(1, c0);
        g->glBlitFramebuffer(0, 0, w, h, 0, 0, w, h, GL_COLOR_BUFFER_BIT, GL_NEAREST);
        if (edges || fog) {
            glReadBuffer(GL_COLOR_ATTACHMENT1);
            g->glDrawBuffers(1, c1);
            g->glBlitFramebuffer(0, 0, w, h, 0, 0, w, h, GL_COLOR_BUFFER_BIT, GL_NEAREST);
            g->glBlitFramebuffer(0, 0, w, h, 0, 0, w, h,
                                 GL_DEPTH_BUFFER_BIT | GL_STENCIL_BUFFER_BIT, GL_NEAREST);
        }
        glReadBuffer(GL_COLOR_ATTACHMENT0);
        g->glDrawBuffers(2, both);
    }
    if (edges) {
        edge_pass(g, fb, s, w, cdepth);
    }
    if (fog) {
        fog_pass(g, fb, s);
    }
    g->glBindFramebuffer(GL_FRAMEBUFFER, 0);
    eidos_prof_end(EIDOS_PROF_GLDRAW, t_dr);
    return glGetError() == GL_NO_ERROR ? 0 : -1;
}

static int render_with_aa(EidosGl *g, GlFb *fb, const G3dSnapshot *s, int w, int h)
{
    if (g != NULL && s != NULL && w > 0 && h > 0 &&
        g->integer_samples < MSAA_SAMPLES && (s->disp3dcnt & 0x10u) != 0 &&
        (long)w * h <= MSAA_MAX_PIXELS && !g->es) {
        /* (not on a phone: four times a phone screen's pixels every frame
         * cost more than a frame's time there, and at its density the
         * resolution already smooths the edges) */
        /* Some GL implementations (including Apple's) cannot multisample
         * integer attachments. Render the complete scene and postprocesses
         * at 2x instead, then average only the normalized colour target. */
        G3dSnapshot sample = *s;
        static const GLenum color[1] = { GL_COLOR_ATTACHMENT0 };
        static const GLenum both[2] = { GL_COLOR_ATTACHMENT0, GL_COLOR_ATTACHMENT1 };

        sample.disp3dcnt &= ~0x10u;
        if (render_into(g, &g->fb[2], &sample, w * 2, h * 2) != 0 ||
            fbo_resize(g, fb, w, h) != 0) {
            return -1;
        }
        g->glBindFramebuffer(GL_READ_FRAMEBUFFER, g->fb[2].fbo);
        g->glBindFramebuffer(GL_DRAW_FRAMEBUFFER, fb->fbo);
        glReadBuffer(GL_COLOR_ATTACHMENT0);
        g->glDrawBuffers(1, color);
        g->glBlitFramebuffer(0, 0, w * 2, h * 2, 0, 0, w, h,
                             GL_COLOR_BUFFER_BIT, GL_LINEAR);
        g->glDrawBuffers(2, both);
        g->glBindFramebuffer(GL_FRAMEBUFFER, 0);
        return glGetError() == GL_NO_ERROR ? 0 : -1;
    }
    return render_into(g, fb, s, w, h);
}

void eidos_gl_set_edges(EidosGl *g, int mode)
{
    if (g != NULL) {
        g->edge_mode = mode < 0 ? 0 : mode > 2 ? 2 : mode;
    }
}

int eidos_gl_render3d(EidosGl *g, const G3dSnapshot *s, int w, int h)
{
    if (g == NULL) return -1;
    return render_with_aa(g, &g->fb[0], s, w, h);
}

/* c * 255 / a, rounded, for every alpha and colour (unpremultiply) */
static unsigned char g_unpremul[256][256];
static int g_unpremul_ready;

static void unpremul_table(void)
{
    unsigned a, c;

    if (g_unpremul_ready) {
        return;
    }
    for (a = 1; a < 256u; a++) {
        for (c = 0; c < 256u; c++) {
            unsigned v = (c * 255u + a / 2u) / a;

            g_unpremul[a][c] = (unsigned char)(v > 255u ? 255u : v);
        }
    }
    g_unpremul_ready = 1;
}

static void unpremultiply(const unsigned char *raw, unsigned char *out,
                          int w, int h)
{
    int x, y;

    unpremul_table();

    for (y = 0; y < h; y++) {
        const unsigned char *s = raw + (size_t)(h - 1 - y) * (size_t)w * 4u;
        unsigned char *d = out + (size_t)y * (size_t)w * 4u;

        for (x = 0; x < w; x++) {
            unsigned a = s[x * 4 + 3];

            if (a == 255u) {
                d[x * 4 + 0] = s[x * 4 + 0];
                d[x * 4 + 1] = s[x * 4 + 1];
                d[x * 4 + 2] = s[x * 4 + 2];
                d[x * 4 + 3] = 255;
            } else if (a == 0) {
                d[x * 4 + 0] = d[x * 4 + 1] = d[x * 4 + 2] = d[x * 4 + 3] = 0;
            } else {
                d[x * 4 + 0] = g_unpremul[a][s[x * 4 + 0]];
                d[x * 4 + 1] = g_unpremul[a][s[x * 4 + 1]];
                d[x * 4 + 2] = g_unpremul[a][s[x * 4 + 2]];
                d[x * 4 + 3] = (unsigned char)a;
            }
        }
    }
}

static int read_fb(EidosGl *g, const GlFb *fb, unsigned char *out, int w, int h)
{
    unsigned char *raw;
    unsigned long long t_rd;

    raw = (unsigned char *)malloc((size_t)w * (size_t)h * 4u);
    if (raw == NULL) {
        return -1;
    }
    t_rd = eidos_prof_begin();
    g->glBindFramebuffer(GL_FRAMEBUFFER, fb->fbo);
    glPixelStorei(GL_PACK_ALIGNMENT, 1);
    glReadPixels(0, 0, w, h, GL_RGBA, GL_UNSIGNED_BYTE, raw);
    g->glBindFramebuffer(GL_FRAMEBUFFER, 0);
    eidos_prof_end(EIDOS_PROF_GLREAD, t_rd);
    t_rd = eidos_prof_begin();
    unpremultiply(raw, out, w, h);
    eidos_prof_end(EIDOS_PROF_UNPREM, t_rd);
    free(raw);
    return 0;
}

/* Start reading `fb` into the pack buffer without waiting for the GPU. */
static int read_fb_start(EidosGl *g, const GlFb *fb, int w, int h)
{
    if (g->pbo == 0) {
        g->glGenBuffers(1, &g->pbo);
    }
    g->glBindBuffer(GL_PIXEL_PACK_BUFFER, g->pbo);
    g->glBufferData(GL_PIXEL_PACK_BUFFER, (GLsizeiptr)((size_t)w * (size_t)h * 4u),
                    NULL, GL_STREAM_READ);
    g->glBindFramebuffer(GL_FRAMEBUFFER, fb->fbo);
    glPixelStorei(GL_PACK_ALIGNMENT, 1);
    glReadPixels(0, 0, w, h, GL_RGBA, GL_UNSIGNED_BYTE, (void *)0);
    g->glBindFramebuffer(GL_FRAMEBUFFER, 0);
    g->glBindBuffer(GL_PIXEL_PACK_BUFFER, 0);
    g->pbo_pending = 1;
    return 0;
}

/* Collect the read started earlier (one frame ago). */
static int read_fb_finish(EidosGl *g, unsigned char *out, int w, int h)
{
    const unsigned char *raw;
    int rc = -1;

    if (!g->pbo_pending) {
        return 1;
    }
    g->glBindBuffer(GL_PIXEL_PACK_BUFFER, g->pbo);
    raw = (const unsigned char *)g->glMapBuffer(GL_PIXEL_PACK_BUFFER, GL_READ_ONLY);
    if (raw != NULL) {
        unsigned long long t0 = eidos_prof_begin();

        unpremultiply(raw, out, w, h);
        eidos_prof_end(EIDOS_PROF_UNPREM, t0);
        g->glUnmapBuffer(GL_PIXEL_PACK_BUFFER);
        rc = 0;
    }
    g->glBindBuffer(GL_PIXEL_PACK_BUFFER, 0);
    g->pbo_pending = 0;
    return rc;
}

int eidos_gl_read3d(EidosGl *g, unsigned char *out, int w, int h)
{
    if (g == NULL || out == NULL || g->fb[0].w != w || g->fb[0].h != h) {
        return -1;
    }
    return read_fb(g, &g->fb[0], out, w, h);
}

/* The frame at DS size, top-down non-premultiplied RGBA: what the software
 * rasteriser's frame is, for the 2D compositor and the display capture.
 * 1 = unchanged since the last call (out is not touched).  With `async` the
 * GPU is not waited for: the call returns the frame read one call ago (the
 * first call returns 1), so the picture lags a frame but the CPU never
 * stalls. */
int eidos_gl_read3d_1x(EidosGl *g, const G3dSnapshot *s, unsigned char *out,
                       int async)
{
    int got = 1;

    if (g == NULL || !g->have3d || s == NULL || out == NULL) {
        return -1;
    }
    if (g->read_valid && s->serial == g->read_serial) {
        return 1;
    }
    if (render_with_aa(g, &g->fb[1], s, 256, 192) != 0) {
        g->read_valid = 0;
        return -1;
    }
    if (async) {
        got = read_fb_finish(g, out, 256, 192);
        read_fb_start(g, &g->fb[1], 256, 192);
    } else {
        g->pbo_pending = 0;
        if (read_fb(g, &g->fb[1], out, 256, 192) != 0) {
            g->read_valid = 0;
            return -1;
        }
        got = 0;
    }
    g->read_serial = s->serial;
    g->read_valid = 1;
    return got;
}
