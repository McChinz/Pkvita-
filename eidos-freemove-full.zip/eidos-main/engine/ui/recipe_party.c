/*
 * engine/ui/recipe_party.c -- the one-screen recipes for the party list
 * (overlay 91) and the Pokemon summary (overlay 131)
 * (engine/ui/ui.h, docs/unified-view-recipes.md, sections 5 and 6).
 *
 * The game keeps the logic.  A recipe reads the game's own structs (the
 * proc on top of the in-game stack, its work area, the party and the
 * Pokemon) and draws them with the kit; a click becomes the touch the game
 * tests for that control (a tap at the centre of its bottom-screen
 * rectangle) or a button press.
 *
 * The game's structures are read by offset (the DS layout, which the
 * ILP32 host build keeps): the decomp's own headers name each field
 * (src/game/ov091/pokelist_types.h, ov091/plist_plate_types.h,
 * ov091/plist_menu_types.h, ov131/p_status_types.h, ov131/p_sta_skill.c,
 * ov131/p_sta_ribbon.c).  A host with wider pointers does not match.
 *
 * Text (names, descriptions) comes from the game's message archive
 * (a/0/0/2) through the port's file layer, so a mod that replaces a bank
 * shows in the interface too.
 */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include "ui.h"
#include "overlay.h"
#include "ui_lang.h"
#include "kit.h"
#include "theme.h"
#include "textbox.h"
#include "port.h"
#include "dsmem.h"
#include "input.h"

#define BW_WEAK __attribute__((weak))

/* ------------------------------------------------------------------ */
/* The game's own accessors (weak: a link without the game still links) */
/* ------------------------------------------------------------------ */

extern void *bw_dsref__GameSystemGlobal BW_WEAK;
extern u32   POKE_TOOL_GetPartyValue(void *mon, u32 paramId, u32 arg) BW_WEAK;
extern u32   POKE_TOOL_GetExpForLevel(u32 species, u32 form, u32 level) BW_WEAK;
extern void *POKEPARTY_GetMember(void *party, u32 pos) BW_WEAK;
extern u32   POKEPARTY_GetCount(const void *party) BW_WEAK;
extern u16  *STRBUF_GetChars(void *strbuf) BW_WEAK;
extern u16   STRBUF_GetLength(void *strbuf) BW_WEAK;
extern u8    APP_TASKMENU_GetCursorPos(const void *menu) BW_WEAK;
extern u32   WAZA_TOOL_GetParam(u32 move, u32 param) BW_WEAK;
extern u32   WAZA_TOOL_IsAlwaysHit(u16 move) BW_WEAK;
extern u8    MSGDATA_GetLanguage(void) BW_WEAK;

static int game_ready(void)
{
    return sizeof(void *) == 4 &&
           &bw_dsref__GameSystemGlobal != NULL && bw_dsref__GameSystemGlobal != NULL &&
           POKE_TOOL_GetPartyValue != NULL && POKEPARTY_GetMember != NULL &&
           POKEPARTY_GetCount != NULL;
}

/* ------------------------------------------------------------------ */
/* Reading structs by DS offset                                        */
/* ------------------------------------------------------------------ */

static void *rdp(const void *base, u32 off)
{
    return *(void *const *)((const u8 *)base + off);
}

static u32 rd32(const void *base, u32 off)
{
    return *(const u32 *)((const u8 *)base + off);
}

static int rds32(const void *base, u32 off)
{
    return *(const s32 *)((const u8 *)base + off);
}

static u32 rd16(const void *base, u32 off)
{
    return *(const u16 *)((const u8 *)base + off);
}

static u32 rd8(const void *base, u32 off)
{
    return *((const u8 *)base + off);
}

/*
 * The proc on top of the in-game stack (docs/unified-view-recipes.md, 0.2):
 * _GameSystemGlobal.gameSystem (+0), its procSys (+0x08), its current (+0x08).
 * Proc: overlayId 0x04, seq 0x08, procWork 0x10, work 0x14.
 */
static const void *top_proc(void)
{
    const void *gs, *ps;

    if (!game_ready()) {
        return NULL;
    }
    gs = *(void *const *)bw_dsref__GameSystemGlobal;
    if (gs == NULL) {
        return NULL;
    }
    ps = rdp(gs, 0x08);
    if (ps == NULL) {
        return NULL;
    }
    return rdp(ps, 0x08);
}

/* The evolution scene's work (ov195 Scene) while it is the app on top. */
#define EVO_OVERLAY     195
#define BTL_RETURN_OVERLAY 92
#define GURU2_OVERLAY   137
#define SC_STATE        0x028
#define SC_YESNO        0x09C
#define SC_TCB          0x0A0
#define SC_PLISTHOST    0x0B0
#define SC_PROCSYS      0x11C
#define SC_STRBUF_YES   0x094
#define SC_STRBUF_NO    0x098

static const void *evo_scene(void)
{
    const void *p = top_proc();

    /* after a battle the scene runs on the proc system of the battle's
     * return step (ov092 EventBattleReturnWork.procSys, +0x40) */
    if (p != NULL && rds32(p, 0x04) == BTL_RETURN_OVERLAY && rdp(p, 0x14) != NULL) {
        const void *ps = rdp(rdp(p, 0x14), 0x40);

        p = ps != NULL ? rdp(ps, 0x08) : NULL;
    }
    if (p == NULL || rds32(p, 0x04) != EVO_OVERLAY || rds32(p, 0x08) < 2) {
        return NULL;
    }
    return rdp(p, 0x14);
}

/* The work area of the proc when it runs the overlay, else NULL.  The
 * evolution scene runs the summary (to forget a move) on a proc system of
 * its own (Scene.proc), so a proc there counts as on top too. */
static const void *app_work(int overlay, const void **proc_out, const void **arg_out)
{
    const void *p = top_proc();
    const void *sc = evo_scene();
    int loaded = 0;

    if (sc != NULL && overlay != EVO_OVERLAY) {
        const void *ps = rdp(sc, SC_PROCSYS);

        p = ps != NULL ? rdp(ps, 0x08) : NULL;
        /* the scene loads the summary's overlay itself and pushes the
         * proc with no overlay (-1) */
        loaded = p != NULL && rds32(p, 0x04) == -1 && bw_overlay_is_loaded(overlay);
    }
    /* the Spin Trade (overlay 137) runs the party list and the summary on
     * a proc system of its own (Guru2Entry.procHandle, +0x20) */
    if (p != NULL && rds32(p, 0x04) == GURU2_OVERLAY && overlay != GURU2_OVERLAY && rdp(p, 0x14) != NULL) {
        const void *ps = rdp(rdp(p, 0x14), 0x20);

        p = ps != NULL ? rdp(ps, 0x08) : NULL;
    }
    if (p == NULL || (rds32(p, 0x04) != overlay && !loaded) || rds32(p, 0x08) < 2) {
        return NULL;
    }
    if (proc_out != NULL) {
        *proc_out = p;
    }
    if (arg_out != NULL) {
        *arg_out = rdp(p, 0x10);
    }
    return rdp(p, 0x14);
}

/* ------------------------------------------------------------------ */
/* Text: the game's strings in UTF-8                                   */
/* ------------------------------------------------------------------ */

/* Append one code unit of the game's text as UTF-8; returns the new length. */
static int put_utf8(char *out, int n, int cap, u32 code)
{
    if (code < 0x80) {
        if (n + 1 < cap) out[n++] = (char)code;
    } else if (code < 0x800) {
        if (n + 2 < cap) {
            out[n++] = (char)(0xC0 | (code >> 6));
            out[n++] = (char)(0x80 | (code & 0x3F));
        }
    } else {
        if (n + 3 < cap) {
            out[n++] = (char)(0xE0 | (code >> 12));
            out[n++] = (char)(0x80 | ((code >> 6) & 0x3F));
            out[n++] = (char)(0x80 | (code & 0x3F));
        }
    }
    return n;
}

/*
 * The game's code units to UTF-8.  0xFFFF ends; 0xFFFE is a line break
 * (kept as a space unless nl); the private ranges (control codes, the
 * unexpanded placeholders) are dropped, with the code's arguments.
 */
static void units_to_utf8(const u16 *u, int count, char *out, int cap, int nl)
{
    int i, n = 0;

    for (i = 0; i < count; i++) {
        u32 c = u[i];

        if (c == 0xFFFFu) {
            break;
        }
        if (c == 0xFFFEu) {
            n = put_utf8(out, n, cap, nl ? '\n' : ' ');
            continue;
        }
        if (c == 0xF000u && i + 2 < count) {
            i += 2 + (int)(u[i + 2] & 0xFF);       /* code, argument count, arguments */
            if (i >= count) break;
            continue;
        }
        if (c >= 0xD800u && c <= 0xF8FFu) {
            continue;
        }
        n = put_utf8(out, n, cap, c);
    }
    out[n < cap ? n : cap - 1] = '\0';
}

/* ---- the message archive ---- */

#define BANK_PARTY      157     /* 0x9D: the party list's messages          */
#define BANK_SUMMARY    158     /* 0x9E: the summary's labels               */
#define BANK_NATURE      24
#define BANK_ITEM        54
#define BANK_ITEM_DESC   53
#define BANK_PLACE       89
#define BANK_SPECIES     70
#define BANK_RIBBON     170     /* 0xAA                                     */
#define BANK_ABILITY    182     /* 0xB6                                     */
#define BANK_ABILITY_D  183
#define BANK_MOVE       203     /* 0xCB                                     */
#define BANK_MOVE_DESC  202     /* 0xCA                                     */

#define BANK_MAX 12

typedef struct MsgCache {
    int bank;
    u8 *data;
    u32 size;
} MsgCache;

static BwArcFile g_msg_arc;
static int g_msg_arc_state;                 /* 0 not tried, 1 open, -1 failed */
static MsgCache g_msg[BANK_MAX];
static int g_msg_n;

static const MsgCache *msg_bank(int bank)
{
    int i;
    long n;
    u8 *buf;

    for (i = 0; i < g_msg_n; i++) {
        if (g_msg[i].bank == bank) {
            return g_msg[i].data != NULL ? &g_msg[i] : NULL;
        }
    }
    if (g_msg_n >= BANK_MAX) {
        return NULL;
    }
    if (g_msg_arc_state == 0) {
        g_msg_arc_state = bw_arc_open(&g_msg_arc, "a/0/0/2") == 0 ? 1 : -1;
    }
    g_msg[g_msg_n].bank = bank;
    g_msg[g_msg_n].data = NULL;
    g_msg[g_msg_n].size = 0;
    if (g_msg_arc_state == 1 && (u32)bank < g_msg_arc.count) {
        n = bw_arc_member_size(&g_msg_arc, (u32)bank);
        buf = n > 16 ? (u8 *)malloc((size_t)n) : NULL;
        if (buf != NULL && bw_arc_read_member(&g_msg_arc, (u32)bank, buf, (u32)n) == n) {
            g_msg[g_msg_n].data = buf;
            g_msg[g_msg_n].size = (u32)n;
        } else {
            free(buf);
        }
    }
    return g_msg[g_msg_n++].data != NULL ? &g_msg[g_msg_n - 1] : NULL;
}

/* Message `index` of `bank` as UTF-8 into out (empty when unavailable).
 * The header is u16 languages, u16 count, u32 size, u32 reserved, then one
 * u32 section offset per language; a section is u32 size, then 8 byte
 * entries (u32 offset, u16 length, u16 reserved); strings are u16 units
 * decrypted per message (arm9/msgdata.c). */
static const char *msg_text(int bank, u32 index, char *out, int cap, int nl)
{
    const MsgCache *m = msg_bank(bank);
    u32 langs, count, lang, sec, off, len, i;
    u16 key, units[256];
    const u8 *d;

    out[0] = '\0';
    if (m == NULL) {
        return out;
    }
    d = m->data;
    langs = rd16(d, 0);
    count = rd16(d, 2);
    lang = (MSGDATA_GetLanguage != NULL) ? MSGDATA_GetLanguage() : 0;
    if (lang >= langs) {
        lang = 0;
    }
    if (index >= count || 12 + 4 * (lang + 1) > m->size) {
        return out;
    }
    sec = rd32(d, 12 + 4 * lang);
    if (sec + 4 + 8 * (count) > m->size) {
        return out;
    }
    off = rd32(d, sec + 4 + 8 * index);
    len = rd16(d, sec + 4 + 8 * index + 4);
    if (len > 255) {
        len = 255;
    }
    if (sec + off + len * 2 > m->size) {
        return out;
    }
    key = (u16)((index + 3) * 0x2983u);
    for (i = 0; i < len; i++) {
        units[i] = (u16)(rd16(d, sec + off + i * 2) ^ key);
        key = (u16)(((key & 0xE000u) >> 13) | (u16)(key << 3));
    }
    units_to_utf8(units, (int)len, out, cap, nl);
    return out;
}

/* A string from a game Strbuf (the menu's labels, a message's text). */
static const char *strbuf_text(void *sb, char *out, int cap, int nl)
{
    out[0] = '\0';
    if (sb == NULL || STRBUF_GetChars == NULL || STRBUF_GetLength == NULL) {
        return out;
    }
    {
        u32 len = STRBUF_GetLength(sb);
        const u16 *u = STRBUF_GetChars(sb);

        if (u == NULL || len > 400) {
            return out;
        }
        units_to_utf8(u, (int)len, out, cap, nl);
    }
    return out;
}

/* ------------------------------------------------------------------ */
/* Pokemon values                                                      */
/* ------------------------------------------------------------------ */

enum {
    P_SPECIES = 0x05, P_ITEM = 0x06, P_OT_ID = 0x07, P_EXP = 0x08, P_FRIEND = 0x09,
    P_ABILITY = 0x0A, P_MOVE1 = 0x36, P_PP1 = 0x3A, P_MAXPP1 = 0x42, P_IS_EGG = 0x4C,
    P_GENDER = 0x6E, P_FORM = 0x6F, P_NATURE = 0x70, P_NICK = 0x74, P_OT_NAME = 0x8E,
    P_MET_LOC = 0x96, P_MET_LEVEL = 0x99, P_STATUS = 0x9D, P_LEVEL = 0x9E, P_HP = 0xA0,
    P_MAXHP = 0xA1, P_ATK = 0xA2, P_DEF = 0xA3, P_SPE = 0xA4, P_SPA = 0xA5, P_SPD = 0xA6,
    P_TYPE1 = 0xAE, P_TYPE2 = 0xAF, P_HAS_RIBBON_FIRST = 0x19
};

static u32 pv(void *mon, u32 id)
{
    return POKE_TOOL_GetPartyValue(mon, id, 0);
}

static void mon_nick(void *mon, char *out, int cap)
{
    u16 buf[32];

    memset(buf, 0xFF, sizeof buf);
    (void)POKE_TOOL_GetPartyValue(mon, P_NICK, (u32)(uintptr_t)buf);
    units_to_utf8(buf, 12, out, cap, 0);
}

static void mon_ot(void *mon, char *out, int cap)
{
    u16 buf[32];

    memset(buf, 0xFF, sizeof buf);
    (void)POKE_TOOL_GetPartyValue(mon, P_OT_NAME, (u32)(uintptr_t)buf);
    units_to_utf8(buf, 8, out, cap, 0);
}

/* The kit's status number (0 PSN, 1 PAR, 2 BRN, 3 SLP, 4 FRZ, 5 FNT), or
 * -1.  The party's status is the game's condition number: 1 paralysis,
 * 2 sleep, 3 freeze, 4 burn, 5 poison, 6 bad poison. */
static int mon_status(void *mon, u32 hp)
{
    static const signed char k_kit[7] = { -1, 1, 3, 4, 2, 0, 0 };
    u32 s = pv(mon, P_STATUS);

    if (hp == 0) return 5;
    return s < 7u ? k_kit[s] : -1;
}

static int gender_of(void *mon)
{
    u32 g = pv(mon, P_GENDER);

    return g > 2 ? 2 : (int)g;
}

/* The game's type numbers have no "???" at 9 (the kit's table does): fire is 9. */
static int kit_type(int t)
{
    return t;      /* the kit takes the game's own type numbers */
}

/* The scale that fits an image of `w` into `room` (a whole number >= 1). */
static int fit_scale(int w, int room)
{
    int k = w > 0 ? room / w : 1;

    return k < 1 ? 1 : k;
}

/* ------------------------------------------------------------------ */
/* Shared drawing                                                      */
/* ------------------------------------------------------------------ */

#define FOOTER_H 17

static void modal_rect(const EidosUiCtx *c, int *x, int *y, int *w, int *h)
{
    int cw = c->canvas->w, ch = c->canvas->h;
    int mw = cw - cw / 10, mh = ch - FOOTER_H - 12;

    if (mw > 460) mw = 460;
    if (mw < 280) mw = cw - 8;
    if (mh > 216) mh = 216;
    if (mh < 150) mh = ch - FOOTER_H - 4;
    *w = mw;
    *h = mh;
    *x = (cw - mw) / 2;
    *y = (ch - FOOTER_H - mh) / 2;
}

static void draw_modal(EidosUiCtx *c, int x, int y, int w, int h)
{
    ui_panel(c, x, y, w, h, UI_CUT_TL | UI_CUT_BR, 9, UI_BODY, UI_NAVY2, 240);
}

/* A click (press and release) outside the modal, above the footer. */
static int click_outside(const EidosUiCtx *c, int x, int y, int w, int h)
{
    int cw = c->canvas->w, ch = c->canvas->h - FOOTER_H;
    EidosUiRect r[4];
    int i, hit = 0;

    r[0].x = 0;     r[0].y = 0;     r[0].w = cw;          r[0].h = y;
    r[1].x = 0;     r[1].y = y + h; r[1].w = cw;          r[1].h = ch - (y + h);
    r[2].x = 0;     r[2].y = y;     r[2].w = x;           r[2].h = h;
    r[3].x = x + w; r[3].y = y;     r[3].w = cw - (x + w); r[3].h = h;
    for (i = 0; i < 4; i++) {
        if (r[i].w > 0 && r[i].h > 0 && (eidos_ui_hit(r[i]) & EIDOS_UI_CLICK)) {
            hit = 1;
        }
    }
    return hit;
}

/* Footer: the key hints; each is a button. */
static void draw_hints(EidosUiCtx *c, const char *const *pairs, const u32 *keys, int n)
{
    ui_hints(c, c->canvas->h - FOOTER_H, c->canvas->w, pairs, n, keys);
}

#define ARROWS "\xE2\x86\x91\xE2\x86\x93\xE2\x86\x90\xE2\x86\x92"

/* ================================================================== */
/* The party list (overlay 91)                                         */
/* ================================================================== */

/* PokelistWork offsets (ov091/pokelist_types.h) */
#define PL_TOUCHMODE   0x008
#define PL_PHASE       0x00C
#define PL_INPUTSTAGE  0x00E
#define PL_SWITCH_EN   0x014
#define PL_RESTORE18   0x018
#define PL_SELECTED    0x02C
#define PL_SWAPSRC     0x030
#define PL_MSGWIN      0x150
#define PL_MENU        0x154
#define PL_PLATES      0x160
#define PL_ARG         0x280
#define PL_LVSTATS     0x124     /* u16[6]: the stats before a level up     */
#define PL_LVWINDOW    0x130     /* the stats window, while it is open      */
#define PL_SELCOUNT    0x105     /* u8: Pokemon entered so far (modes 22, 23) */
/* PokelistArg.regulation (+0x14): u8 minPartySize +2, maxPartySize +3 */
#define PA_REGULATION  0x14
/* the six stat ids the window lists (ov091 gPlistStatParamIds) */
#define PLIST_STAT_IDS 0x021BECE4u
/* PokelistArg */
#define PA_PARTY       0x00
#define PA_MODE        0x34
/* PlistPlate */
#define PP_MON         0x00
#define PP_HP          0x06
#define PP_ISEGG       0x0C
#define PP_ISEMPTY     0x14
#define PP_LABEL       0x1C      /* 0..5 entry order, 6 not entered, 7 banned, 8 none */
/* PlistMenu */
#define PM_COUNT       0x00
#define PM_IDS         0x02
#define PM_ENTRIES     0x14
#define PM_TASKMENU    0x74
/* PlistMessage */
#define MS_KIND        0x00
#define MS_STREAM      0x0C
#define MS_STREAMTEXT  0x10

/* The game's touch centres of the six plates (DS pixels). */
static const int k_plate_tap[6][2] = {
    { 64, 32 }, { 192, 40 }, { 64, 80 }, { 192, 88 }, { 64, 128 }, { 192, 136 }
};

typedef struct PartyView {
    const void *work;
    const void *arg;
    int phase, stage, mode, selected, swap_src, touch_mode, switch_enabled;
    int count;                  /* party size                               */
} PartyView;

static int party_read(PartyView *v)
{
    const void *w = app_work(91, NULL, NULL);
    const void *arg;
    void *party;

    if (w == NULL) {
        return 0;
    }
    arg = rdp(w, PL_ARG);
    if (arg == NULL) {
        return 0;
    }
    party = rdp(arg, PA_PARTY);
    if (party == NULL) {
        return 0;
    }
    v->work = w;
    v->arg = arg;
    v->phase = (int)rd8(w, PL_PHASE);
    v->stage = (int)rd8(w, PL_INPUTSTAGE);
    v->mode = rds32(arg, PA_MODE);
    v->selected = rds32(w, PL_SELECTED);
    v->swap_src = rds32(w, PL_SWAPSRC);
    v->touch_mode = rds32(w, PL_TOUCHMODE);
    v->switch_enabled = rds32(w, PL_SWITCH_EN);
    v->count = (int)POKEPARTY_GetCount(party);
    return v->count >= 0 && v->count <= 6;
}

/*
 * The labels the teach list (mode 6: a TM or a tutor's move, "ABLE" /
 * "NOT ABLE" / "LEARNED") and the evolution-stone list (mode 16: "ABLE" /
 * "NOT ABLE") print in place of a Pokemon's HP (PLIST_PLATE_DrawMonInfo).
 * The game's own checks decide them (POKELIST_GetMoveLearnStatus,
 * POKELIST_CheckEvolution); they read the personal data and allocate, so
 * they run on the game's thread and the answers are kept here, per plate:
 * the message of bank 157 to print, 0 while not known.
 */
extern int ov091_POKELIST_GetMoveLearnStatus(const void *work, void *mon, u8 slot) BW_WEAK;
extern u32 ov091_POKELIST_CheckEvolution(const void *work, void *mon, u32 item) BW_WEAK;

#define PA_ITEM 0x44            /* PokelistArg.itemId (u16)                  */

static volatile u16 g_pl_label[6];
static const void *volatile g_pl_label_work;
static volatile int g_pl_label_asked;

static int plate_is_mon(const void *work, int i, void **mon);

static void party_labels_game(void *arg)
{
    const void *work = arg;
    const void *pa = rdp(work, PL_ARG);
    int mode = pa != NULL ? rds32(pa, PA_MODE) : -1;
    int teach = mode == 6 || rds32(work, PL_RESTORE18) == 1;
    int i;

    for (i = 0; i < 6; i++) {
        void *mon = NULL;
        u16 msg = 0;

        if (plate_is_mon(work, i, &mon)) {
            if (teach && ov091_POKELIST_GetMoveLearnStatus != NULL) {
                int st = ov091_POKELIST_GetMoveLearnStatus(work, mon, (u8)i);

                msg = st <= 1 ? 0x89 : st == 2 ? 0x8A : 0x8B;
            } else if (mode == 16 && ov091_POKELIST_CheckEvolution != NULL) {
                msg = ov091_POKELIST_CheckEvolution(work, mon, rd16(pa, PA_ITEM)) != 0 ? 0x8C : 0x8D;
            }
        }
        g_pl_label[i] = msg;
    }
    g_pl_label_work = work;
    g_pl_label_asked = 0;
}

/* The label of plate i, or 0; asks the game for the list's labels the first
 * time and again every 30 frames (a Pokemon that learnt the move turns to
 * LEARNED). */
static u16 party_label(const PartyView *v, int i, u32 frame)
{
    static u32 last;

    if (v->mode != 6 && v->mode != 16 && rds32(v->work, PL_RESTORE18) != 1) {
        return 0;
    }
    if (!g_pl_label_asked && (g_pl_label_work != v->work || frame - last >= 30u)) {
        last = frame;
        g_pl_label_asked = eidos_ui_game_call(party_labels_game, (void *)v->work);
    }
    return g_pl_label_work == v->work ? g_pl_label[i] : 0;
}

static int party_match(void)
{
    PartyView v;

    if (!party_read(&v)) {
        return 0;
    }
    /* The plain list, the use-an-item list and the give-an-item list; the
     * list that teaches a move, the battle order list and the like keep
     * the DS screens. */
    if (v.mode != 0 && v.mode != 1 && v.mode != 5 && v.mode != 6 && v.mode != 8 && v.mode != 9 && v.mode != 16
        && v.mode != 21 && v.mode != 22 && v.mode != 23 && rds32(v.work, PL_RESTORE18) == 0) {
        return 0;
    }
    /* mode 8: the list back from the summary's "forget a move" after an
     * item taught one (a Rare Candy's level), with the game's message
     * ("... did not learn ...", "... forgot ..."); PL_RESTORE18 the same
     * on the way through mode 3; modes 22 and 23: the Pokemon a battle
     * facility enters (the Battle Subway), with CONFIRM and CANCEL;
     * mode 1: the Pokemon a link battle enters (the Union Room's
     * Colosseum), with CONFIRM alone;
     * mode 21: the Egg the Spin Trade takes (no back button);
     * mode 9: the Pokemon the Bag gives an item to (pokelist.c: the
     * prompt is message 0xC, "Give to which Pokemon?");
     * mode 6: the Pokemon a TM or a tutor teaches (message 0xE), each with
     * ABLE, NOT ABLE or LEARNED; mode 16: the Pokemon an evolution stone is
     * used on (message 0xD), each with ABLE or NOT ABLE (#24) */
    return 1;
}

/* Plate i of the list's work holds a Pokemon (*mon then); the game's
 * thread asks it (party_labels_game). */
static int plate_is_mon(const void *work, int i, void **mon)
{
    const void *pl = rdp(work, PL_PLATES + 4u * (u32)i);

    if (pl == NULL || rds32(pl, PP_ISEMPTY) != 0 || rdp(pl, PP_MON) == NULL) {
        return 0;
    }
    *mon = rdp(pl, PP_MON);
    return 1;
}

/* The mon of plate i (the plate follows the swap animation), or NULL. */
static void *plate_mon(const PartyView *v, int i)
{
    const void *pl = rdp(v->work, PL_PLATES + 4u * (u32)i);

    if (pl == NULL || rds32(pl, PP_ISEMPTY) != 0) {
        return NULL;
    }
    return rdp(pl, PP_MON);
}

static u32 plate_hp(const PartyView *v, int i, void *mon)
{
    const void *pl = rdp(v->work, PL_PLATES + 4u * (u32)i);

    if (pl != NULL && rds32(pl, PP_ISEMPTY) == 0 && rdp(pl, PP_MON) == mon) {
        return rd16(pl, PP_HP);
    }
    return pv(mon, P_HP);
}

/* The prompt line for the phase (the game prints it in its own window). */
static void party_prompt(const PartyView *v, void *sel_mon, char *out, int cap)
{
    char tmp[256];
    int idx = -1;

    out[0] = '\0';
    switch (v->phase) {
    case 6: {
        const void *menu = rdp(v->work, PL_MENU);
        u32 first = (menu != NULL && rd32(menu, PM_COUNT) & 0xFF) ? rd16(menu, PM_IDS) : 0;

        if (v->mode == 21) {
            idx = 0xA2;                 /* What will you do with the Egg? */
        } else if (first == 0 || first == 3 || first == 6 || (first >= 16 && first <= 19)
            || v->mode == 1 || v->mode == 22 || v->mode == 23) {
            idx = 18;
        } else {
            idx = 19;
        }
        break;
    }
    case 3: idx = 11; break;
    case 2:
        idx = v->mode == 5 || v->mode == 16 ? 13 : v->mode == 9 ? 12 : v->mode == 6 ? 14
              : (v->mode == 21 ? 0xA3 : 9);
        break;
    default:
        break;
    }
    if (idx < 0) {
        return;
    }
    (void)msg_text(BANK_PARTY, (u32)idx, tmp, (int)sizeof tmp, 0);
    if (idx == 18 && sel_mon != NULL) {
        char nick[32];

        mon_nick(sel_mon, nick, (int)sizeof nick);
        /* "Do what with<nl>[name]?": the name takes the placeholder's place */
        snprintf(out, (size_t)cap, ui_trf("Do what with %s?"), nick);
        return;
    }
    snprintf(out, (size_t)cap, "%s", tmp);
}

static int g_party_hover = -1;

static void draw_wrapped(EidosUiCtx *c, int x, int y, int width, int lh, int max,
                         const char *text, int font, u32 color, s32 shadow);

/* The stats window after a Rare Candy (PLIST_MENU_UpdateLevelUp, phase 13):
 * the gains first (input stages 1 and 2), then the new totals (3 to 5),
 * each waiting for A as on the DS.  Drawn as the battle draws its own,
 * at the right over the message box. */
static int party_levelup(EidosUiCtx *c, const PartyView *v, void *mon, int right, int bottom)
{
    const u16 *ids = (const u16 *)bw_ds_try_ptr(PLIST_STAT_IDS);
    int rh = 13, pw = 150, h = 6 * rh + 8, px = right - pw, py = bottom - h, i;
    int totals = v->stage >= 3, ty = ui_text_y(rh, UI_FONT_SMALL);

    if (v->phase != 13 || v->stage < 1 || v->stage > 5 || mon == NULL || ids == NULL
        || rdp(v->work, PL_LVWINDOW) == NULL) {
        return 0;
    }
    ui_panel(c, px, py, pw, h, UI_CUT_TL | UI_CUT_BR, 6, UI_BODY, UI_EDGE, 235);
    for (i = 0; i < 6; i++) {
        char name[32], val[16];
        u32 now = pv(mon, ids[i]);
        u32 before = rd16(v->work, PL_LVSTATS + 2u * (u32)i);
        int ry = py + 4 + i * rh;

        (void)msg_text(BANK_PARTY, 0x95 + (u32)i, name, (int)sizeof name, 0);
        snprintf(val, sizeof val, totals ? "%u" : "+%u", totals ? (unsigned)now : (unsigned)(now - before));
        ui_text(c, px + 10, ry + ty, name, UI_GREY, UI_EDGE, UI_FONT_SMALL, 1);
        ui_text(c, px + pw - 10 - ui_text_w(val, UI_FONT_SMALL), ry + ty, val,
                totals ? UI_WHITE : UI_HP_G, UI_EDGE, UI_FONT_SMALL, 1);
        if (i > 0) {
            ui_fill(c, px + 8, ry - 1, pw - 16, 1, UI_EDGE, 160);
        }
    }
    return 1;
}

static int game_message(EidosUiCtx *c, u32 since, int x, int y, int w, int h);

static int g_detail_at = -1;     /* the slot the theme's pane showed last */
static u32 g_menu_turn_at;       /* the frame the menu opened (the plate turned) */
static int g_menu_was_open;

/* One Pokemon of the party as a theme's plate takes it. */
static void party_mon_fill(const PartyView *v, int i, const EidosUiFrame *in, int sel, int entry, UiPartyMon *m,
                           char *nick, int nick_n, char *note, int note_n)
{
    void *mon = plate_mon(v, i);

    memset(m, 0, sizeof(*m));
    m->slot = i;
    m->status = -1;
    m->sel = sel;
    if (mon == NULL) {
        return;
    }
    {
        u32 hp = plate_hp(v, i, mon);
        u16 species = (u16)pv(mon, P_SPECIES);
        int egg = pv(mon, P_IS_EGG) != 0;
        u16 lm;

        if (egg) {
            (void)msg_text(BANK_SPECIES, 650, nick, nick_n, 0);
        } else {
            mon_nick(mon, nick, nick_n);
        }
        m->name = nick;
        m->icon = ui_mon_icon(egg ? (u16)(species == 490 ? 651 : 650) : species, egg ? 0 : (u8)pv(mon, P_FORM),
                              sel ? (int)((in->frame / 24) & 1) : 0);
        m->gender = egg ? 2 : gender_of(mon);
        m->moving = v->phase == 3 && i == v->swap_src;
        if (egg) {
            return;
        }
        m->level = (int)pv(mon, P_LEVEL);
        m->hp = (int)hp;
        m->maxhp = (int)pv(mon, P_MAXHP);
        m->status = mon_status(mon, hp);
        m->item = ui_held_kind(pv(mon, P_ITEM));
        m->front = ui_mon_front(species, (u8)pv(mon, P_FORM), 0);
        m->species = species;
        m->form = (int)pv(mon, P_FORM);
        m->type1 = kit_type((int)pv(mon, P_TYPE1));
        m->type2 = kit_type((int)pv(mon, P_TYPE2));
        lm = party_label(v, i, in->frame);
        if (lm != 0) {
            (void)msg_text(BANK_PARTY, lm, note, note_n, 0);
            m->note = note;
            m->note_rgb = lm == 0x89 || lm == 0x8C ? UI_SKY : (lm == 0x8B ? UI_GREY : UI_PINK);
        }
        if (entry) {
            const void *pl = rdp(v->work, PL_PLATES + 4u * (u32)i);
            int label = pl != NULL ? rds32(pl, PP_LABEL) : 8;

            if (label >= 0 && label <= 7) {
                (void)msg_text(BANK_PARTY, label <= 5 ? 0x83u + (u32)label : (label == 6 ? 0x81u : 0x82u), note,
                               note_n, 0);
                m->note = note;
                m->note_rgb = label <= 5 ? UI_SKY : (label == 6 ? UI_GREY : UI_PINK);
            }
        }
    }
}

static void party_run(EidosUiCtx *c, EidosUiView *view, const EidosUiFrame *in)
{
    PartyView v;
    UiPartyLayout pl;
    const UiThemeOps *theme = ui_theme_active();
    int mx, my, mw, mh;
    int i, rowh = 30, gap = 7, colw, x0, y0;
    int phase_pick, menu_open, msg_open, stream_msg;
    void *sel_mon;
    char prompt[160], right[16];
    const void *menu = NULL;
    int menu_n = 0;
    int click_slot = -1, back_click = 0, entry;
    static const char *const hints[] = { "A", "Choose", "B", "Back", ARROWS, "Move" };
    static const u32 hint_keys[] = { BW_KEY_A, BW_KEY_B, 0 };

    view->mode = EIDOS_VIEW_WORLD;
    view->blur = 1;
    view->hold_world = 1;     /* an app: the field is not running */
    view->hide_2d = 1;
    view->zoom = 1.0f;

    if (!party_read(&v)) {
        return;
    }
    modal_rect(c, &mx, &my, &mw, &mh);

    phase_pick = v.phase == 2 || v.phase == 3;
    /* phase 9: a menu opened with a callback (POKELIST_OpenMenuWithCallback:
     * the question after a Rare Candy, "forget a move?"), under its message */
    menu_open = v.phase == 6 || v.phase == 9;
    msg_open = v.phase == 7;
    if (menu_open) {
        menu = rdp(v.work, PL_MENU);
        menu_n = menu != NULL ? (int)rd8(menu, PM_COUNT) : 0;
        if (menu_n < 1 || menu_n > 8) {
            menu = NULL;
            menu_n = 0;
        }
    }
    sel_mon = (v.selected >= 0 && v.selected <= 5) ? plate_mon(&v, v.selected) : NULL;

    entry = v.mode == 1 || v.mode == 22 || v.mode == 23;
    if (entry) {
        const void *reg = rdp(v.arg, PA_REGULATION);

        snprintf(right, sizeof right, "%d/%d", (int)rd8(v.work, PL_SELCOUNT),
                 reg != NULL ? (int)rd8(reg, 3) : 6);
    } else {
        snprintf(right, sizeof right, "%d/6", v.count);
    }
    /* The places: Kosmos's (two columns, three rows, in the game's plate
     * order; the prompt under them; the menu at the lower right), then the
     * theme's. */
    colw = (mw - 8 * 2 - 6) / 2;
    x0 = mx + 8;
    y0 = my + 4 + 22 + 7;
    memset(&pl, 0, sizeof pl);
    pl.w = c->canvas->w;
    pl.h = c->canvas->h - FOOTER_H;
    pl.menu_n = menu_n;
    pl.sel = v.selected >= 0 && v.selected <= 5 ? v.selected : -1;
    pl.frame.x = mx;
    pl.frame.y = my;
    pl.frame.w = mw;
    pl.frame.h = mh;
    pl.header = 1;
    for (i = 0; i < 6; i++) {
        pl.slot[i].x = x0 + (i & 1) * (colw + 6);
        pl.slot[i].y = y0 + (i >> 1) * (rowh + gap);
        pl.slot[i].w = colw;
        pl.slot[i].h = rowh;
    }
    pl.msg.x = mx + 8;
    pl.msg.y = y0 + 3 * (rowh + gap) + 1;
    pl.msg.w = mw - 16;
    pl.msg.h = my + mh - 6 - pl.msg.y;
    pl.menu.w = 112;
    pl.menu_eh = 17;
    pl.menu.x = mx + mw - 8 - pl.menu.w;
    pl.menu.y = y0 + 28;
    pl.menu.h = my + mh - 6 - pl.menu.y;
    if (theme->party_layout != NULL) {
        theme->party_layout(&pl);
    }
    mx = pl.frame.x;
    my = pl.frame.y;
    mw = pl.frame.w;
    mh = pl.frame.h;
    if (pl.header) {
        draw_modal(c, mx, my, mw, mh);
        ui_header(c, mx + 4, my + 4, mw - 8, "POK\xC3\x89MON", entry ? "ENTRY" : "PARTY", right, UI_SKY);
    }
    if (theme->party_backdrop != NULL) {
        theme->party_backdrop(c, &pl, "POK\xC3\x89MON", entry ? "ENTRY" : "PARTY", right);
    }

    if (pl.column && phase_pick && !entry) {
        /* one column: up and down go through the party in order (the game's
         * own keys move in its two columns) */
        u32 k = eidos_ui_keys_pressed();
        int d = (k & BW_KEY_DOWN) ? 1 : (k & BW_KEY_UP) ? -1 : 0;

        eidos_ui_take_keys(BW_KEY_UP | BW_KEY_DOWN | BW_KEY_LEFT | BW_KEY_RIGHT);
        if (d != 0 && v.selected >= 0 && v.selected <= 5) {
            int to = v.selected + d;

            if (to >= 0 && to <= 5 && plate_mon(&v, to) != NULL) {
                s32 slot = to;
                s32 key_mode = 0;

                memcpy((u8 *)v.work + PL_SELECTED, &slot, sizeof slot);
                memcpy((u8 *)v.work + PL_TOUCHMODE, &key_mode, sizeof key_mode);
                v.selected = to;
                v.touch_mode = 0;
                eidos_ui_sound(0x548);
            }
        } else if (d != 0) {
            eidos_ui_press(d > 0 ? BW_KEY_DOWN : BW_KEY_UP, 2);     /* the buttons under the party */
        }
    }
    if (menu_open && menu != NULL && !g_menu_was_open) {
        g_menu_turn_at = in->frame;
    }
    g_menu_was_open = menu_open && menu != NULL;
    if (pl.menu_cols > 0 && menu_open && menu != NULL) {
        /* a grid: the arrows move in it (the game's menu is a column) */
        const void *tm = rdp(menu, PM_TASKMENU);
        u32 k = eidos_ui_keys_pressed();
        int cur = (tm != NULL && APP_TASKMENU_GetCursorPos != NULL) ? (int)APP_TASKMENU_GetCursorPos(tm) : 0;
        int to = cur;

        eidos_ui_take_keys(BW_KEY_UP | BW_KEY_DOWN | BW_KEY_LEFT | BW_KEY_RIGHT);
        if (k & BW_KEY_LEFT) to = cur - 1;
        if (k & BW_KEY_RIGHT) to = cur + 1;
        if (k & BW_KEY_UP) to = cur - pl.menu_cols;
        if (k & BW_KEY_DOWN) to = cur + pl.menu_cols;
        if (to != cur && to >= 0 && to < menu_n && tm != NULL && v.stage == 1) {
            *((u8 *)tm + 0) = (u8)to;
            eidos_ui_sound(0x548);
        }
    }
    if (pl.menu_across && menu_open && menu != NULL) {
        /* the menu side by side: left and right are the game's up and down */
        u32 k = eidos_ui_keys_pressed();

        eidos_ui_take_keys(BW_KEY_LEFT | BW_KEY_RIGHT);
        if (k & BW_KEY_LEFT) {
            eidos_ui_press(BW_KEY_UP, 2);
        } else if (k & BW_KEY_RIGHT) {
            eidos_ui_press(BW_KEY_DOWN, 2);
        }
    }
    g_party_hover = -1;
    for (i = 0; i < 6; i++) {
        int x = pl.slot[i].x, y = pl.slot[i].y;
        void *mon = plate_mon(&v, i);
        int sel = 0, st;
        EidosUiRect r;
        int hit = 0;

        colw = pl.slot[i].w;
        r = pl.slot[i];
        if (phase_pick && mon != NULL) {
            hit = eidos_ui_hit(r);
            if (hit & EIDOS_UI_HOVER) {
                g_party_hover = i;
                if (i != v.selected || v.touch_mode != 0) {
                    /* the game's cursor follows the mouse (and the key
                     * mode is on), so a key goes on from the Pokemon the
                     * mouse was on */
                    s32 slot = i;
                    s32 key_mode = 0;

                    memcpy((u8 *)v.work + PL_SELECTED, &slot, sizeof slot);
                    memcpy((u8 *)v.work + PL_TOUCHMODE, &key_mode, sizeof key_mode);
                }
            }
            if (hit & EIDOS_UI_CLICK) {
                click_slot = i;
            }
        }
        if (mon == NULL) {
            if (theme->party_plate != NULL) {
                UiPartyMon pm;

                memset(&pm, 0, sizeof pm);
                pm.slot = i;
                theme->party_plate(c, &pl.slot[i], &pm);
            } else {
                ui_party_row(c, x, y, colw, i, NULL, 0, 0, 0, 0, NULL, 0);
            }
            continue;
        }
        if (v.phase == 3 && i == v.swap_src) {
            sel = 1;
        } else if (v.phase == 6 && i == v.selected) {
            sel = 1;
        } else if (v.touch_mode == 0 && i == v.selected && phase_pick && eidos_ui_keys_lit()) {
            sel = 1;
        } else if (i == g_party_hover) {
            sel = 1;
        }
        if (theme->party_plate != NULL) {
            UiPartyMon pm;
            char nick[40], note[32];

            party_mon_fill(&v, i, in, sel, entry, &pm, nick, (int)sizeof nick, note, (int)sizeof note);
            if (pl.menu_cols > 0 && menu_open && menu != NULL && i == v.selected) {
                pm.turned = (int)(in->frame - g_menu_turn_at) + 1;
            }
            theme->party_plate(c, &pl.slot[i], &pm);
            continue;
        }
        {
            char nick[40];
            u32 hp = plate_hp(&v, i, mon), maxhp = pv(mon, P_MAXHP);
            u16 species = (u16)pv(mon, P_SPECIES);
            int egg = pv(mon, P_IS_EGG) != 0;
            const UiImage *icon = ui_mon_icon(egg ? (u16)(species == 490 ? 651 : 650) : species,
                                              egg ? 0 : (u8)pv(mon, P_FORM),
                                              sel ? (int)((in->frame / 24) & 1) : 0);

            if (egg) {
                /* the game's word for an Egg (the species bank's 650),
                 * as its plate prints it */
                (void)msg_text(BANK_SPECIES, 650, nick, (int)sizeof nick, 0);
            } else {
                mon_nick(mon, nick, (int)sizeof nick);
            }
            if (egg) {
                ui_party_row(c, x, y, colw, i, nick, 2, 0, 0, 0, icon, sel);
            } else {
                int lvw;
                char lv[16];

                ui_party_row_held(ui_held_kind(pv(mon, P_ITEM)));  /* its mark, on the icon's feet */
                ui_party_row(c, x, y, colw, i, nick, gender_of(mon), (int)pv(mon, P_LEVEL),
                             (int)hp, (int)maxhp, icon, sel);
                st = mon_status(mon, hp);
                if (st >= 0) {
                    snprintf(lv, sizeof lv, "%s%d", ui_tr("Lv."), (int)pv(mon, P_LEVEL));
                    lvw = ui_text_w(lv, UI_FONT_SMALL);
                    ui_status_badge(c, x + colw - 9 - lvw - 28, y + 3, st);
                }
            }
            if (v.phase == 3 && i == v.swap_src) {
                ui_text(c, x + colw - 78, y + 3, "MOVE", UI_CYAN, UI_NAVY, UI_FONT_SMALL, 1);
            }
            {
                /* the teach and evolution lists: the game's label in place
                 * of the HP (ABLE in blue, NOT ABLE in pink, LEARNED in grey) */
                u16 lm = egg ? 0 : party_label(&v, i, in->frame);
                char lt[32];

                if (lm != 0) {
                    (void)msg_text(BANK_PARTY, lm, lt, (int)sizeof lt, 0);
                    ui_fill(c, x + 40, y + 15, colw - 46, 13, sel ? UI_NAVY2 : UI_NAVY, 255);
                    ui_text(c, x + 40, y + 15, lt,
                            lm == 0x89 || lm == 0x8C ? UI_SKY : (lm == 0x8B ? UI_GREY : UI_PINK),
                            UI_EDGE, UI_FONT_SMALL, 1);
                }
            }
            if (entry && !egg) {
                /* the game's label in place of the HP: the entry order,
                 * NOT ENTERED or BANNED (bank 157: 0x83 + order, 0x81, 0x82) */
                const void *pl = rdp(v.work, PL_PLATES + 4u * (u32)i);
                int label = pl != NULL ? rds32(pl, PP_LABEL) : 8;
                char lt[32];

                if (label >= 0 && label <= 7) {
                    (void)msg_text(BANK_PARTY, label <= 5 ? 0x83u + (u32)label : (label == 6 ? 0x81u : 0x82u),
                                   lt, (int)sizeof lt, 0);
                    ui_fill(c, x + 40, y + 15, colw - 46, 13, sel ? UI_NAVY2 : UI_NAVY, 255);
                    ui_text(c, x + 40, y + 15, lt, label <= 5 ? UI_SKY : (label == 6 ? UI_GREY : UI_PINK),
                            UI_EDGE, UI_FONT_SMALL, 1);
                }
            }
        }
    }

    if (pl.detail.w > 0 && theme->party_detail != NULL) {
        int at = g_party_hover >= 0 ? g_party_hover : v.selected;

        if (at >= 0 && at <= 5 && plate_mon(&v, at) != NULL) {
            UiPartyMon pm;
            char nick[40], note[32];

            party_mon_fill(&v, at, in, 1, entry, &pm, nick, (int)sizeof nick, note, (int)sizeof note);
            /* its cry when the choice moves to it (not as the screen opens) */
            if (g_detail_at >= 0 && g_detail_at != at && pm.species > 0 && pm.level > 0) {
                eidos_ui_cry((u32)pm.species);
            }
            g_detail_at = at;
            theme->party_detail(c, &pl.detail, &pm, in->frame);
        } else {
            theme->party_detail(c, &pl.detail, NULL, in->frame);
        }
    }

    /* The message line and the menu. */
    {
        int bh = pl.msg.h;
        int msgw = pl.msg.w, menu_x = 0, menu_y = 0, menu_w = 0, menu_h = 0;
        int msx = pl.msg.x, msb = pl.msg.y + pl.msg.h;      /* the prompt's left and foot */

        if (v.switch_enabled && v.phase == 2) {
            msgw -= 52;
        }
        if (entry && v.phase == 2) {
            msgw -= 2 * 72 + 2;
        }
        party_prompt(&v, sel_mon, prompt, (int)sizeof prompt);
        /* a message the game prints (after a Rare Candy, a move to learn):
         * as the battle shows its own, page by page as the game prints it */
        stream_msg = v.phase == 7 || v.phase == 9 || v.phase == 10 || v.phase == 11;
        if (menu_open && menu != NULL) {
            int eh = pl.menu_eh, n = menu_n;

            menu_w = pl.menu.w;
            menu_h = n * (eh + 2) + 8;
            menu_x = pl.menu.x;
            menu_y = pl.menu.y + pl.menu.h - menu_h;
            if (menu_y < pl.menu.y) {
                menu_y = pl.menu.y;
            }
            if (!pl.menu_apart) {
                msgw = menu_x - msx - 6;
            }
        }
        if (party_levelup(c, &v, sel_mon, msx + pl.msg.w, msb - 40 - 4)) {
            /* a click anywhere goes on, as A does */
            EidosUiRect all = { mx, my, mw, mh };

            if (eidos_ui_hit(all) & EIDOS_UI_CLICK) {
                eidos_ui_press(BW_KEY_A, 3);
            }
        }
        if (stream_msg && bh >= 40) {
            EidosUiRect rr;

            rr.x = msx; rr.y = msb - 40; rr.w = msgw; rr.h = 40;
            if (game_message(c, 0xFFFFFFFFu, rr.x, rr.y, rr.w, rr.h) && msg_open
                && (eidos_ui_hit(rr) & EIDOS_UI_CLICK)) {
                eidos_ui_press(BW_KEY_A, 3);
            }
        } else if (prompt[0] != '\0' && bh >= 18) {
            int ty, mh2 = bh < 30 ? bh : 30;

            if (theme->party_prompt != NULL) {
                EidosUiRect pr;

                pr.x = msx;
                pr.y = msb - mh2;
                pr.w = msgw;
                pr.h = mh2;
                theme->party_prompt(c, &pr, prompt);
            } else {
                ui_panel(c, msx, msb - mh2, msgw, mh2, UI_CUT_TL | UI_CUT_BR, 5, UI_BODY, UI_EDGE, 235);
                ty = ui_text_y(mh2, UI_FONT_LARGE);
                ui_text(c, msx + 8, msb - mh2 + ty, prompt, UI_WHITE, UI_EDGE, UI_FONT_LARGE, 1);
            }
        }
        if (menu_open && menu != NULL) {
            const void *tm = rdp(menu, PM_TASKMENU);
            int cur = (tm != NULL && APP_TASKMENU_GetCursorPos != NULL)
                          ? (int)APP_TASKMENU_GetCursorPos(tm) : -1;
            int ey = menu_y + 4, ew = menu_w - 8;
            int cancel = menu_n - 1;        /* the game's cancel is the last entry */
            int across = pl.menu_across, aw = across ? pl.menu.w / menu_n : 0;

            for (i = 0; i < menu_n; i++) {
                if (rd16(menu, PM_IDS + 2u * (u32)i) == 6) {
                    cancel = i;
                }
            }

            if (!across && pl.menu_cols == 0 && theme->party_menu_entry == NULL) {
                ui_panel(c, menu_x, menu_y, menu_w, menu_h, UI_CUT_TL | UI_CUT_BR, 6, UI_BODY2, UI_SKY, 245);
            }
            for (i = 0; i < menu_n; i++) {
                const void *e = (const u8 *)menu + PM_ENTRIES + 12u * (u32)i;
                char label[48];
                EidosUiRect rr;
                int hit, sel, ty;

                (void)strbuf_text(rdp(e, 0), label, (int)sizeof label, 0);
                rr.x = menu_x + 4; rr.y = ey; rr.w = ew; rr.h = pl.menu_eh;
                if (across) {
                    rr.x = pl.menu.x + i * aw;
                    rr.y = pl.menu.y;
                    rr.w = aw - 4;
                    rr.h = pl.menu.h;
                }
                if (pl.menu_cols > 0) {
                    int rows = (menu_n + pl.menu_cols - 1) / pl.menu_cols;
                    int gw = pl.menu.w / pl.menu_cols, gh = pl.menu.h / rows;

                    rr.x = pl.menu.x + (i % pl.menu_cols) * gw + 1;
                    rr.y = pl.menu.y + (i / pl.menu_cols) * gh + 1;
                    rr.w = gw - 2;
                    rr.h = gh - 2;
                    if (in->frame - g_menu_turn_at < 6u) {
                        continue;                   /* the plate is still turning */
                    }
                }
                hit = eidos_ui_hit(rr);
                sel = (hit & EIDOS_UI_HOVER) || (i == cur && eidos_ui_keys_lit());
                if ((hit & EIDOS_UI_HOVER) && i != cur && v.stage == 1 && tm != NULL) {
                    /* the game's cursor follows the mouse, so a key goes
                     * on from the entry the mouse was on */
                    *((u8 *)tm + 0) = (u8)i;
                }
                if (theme->party_menu_entry != NULL) {
                    theme->party_menu_entry(c, rr.x, rr.y, rr.w, rr.h, label, sel, across);
                } else {
                    ui_panel(c, rr.x, rr.y, rr.w, rr.h, UI_CUT_TL | UI_CUT_BR, 4,
                             sel ? UI_NAVY2 : UI_BODY, sel ? UI_SKY : UI_EDGE, 255);
                    ty = ui_text_y(rr.h, UI_FONT_LARGE);
                    ui_text(c, rr.x + 8, rr.y + ty, label, UI_WHITE,
                            sel ? (s32)UI_NAVY : (s32)UI_EDGE, UI_FONT_LARGE, 1);
                }
                (void)ty;
                if ((hit & EIDOS_UI_CLICK) && v.stage == 1) {
                    /* the game's own rectangle of entry i of n (docs 0.5) */
                    eidos_ui_tap(203, (24 - 3 * menu_n) * 8 + 24 * i + 12, 3);
                }
                if (i == cancel && eidos_ui_right_click() && v.stage == 1) {
                    eidos_ui_tap(203, (24 - 3 * menu_n) * 8 + 24 * i + 12, 3);
                }
                ey += pl.menu_eh + 2;
            }
            if (click_outside(c, mx, my, mw, mh) && v.stage == 1) {
                /* a click outside the modal is B: the CANCEL entry */
                eidos_ui_tap(203, (24 - 3 * menu_n) * 8 + 24 * cancel + 12, 3);
            }
        }
    }

    /* The bottom screen's buttons as the game offers them: back (B), and the red cross that
     * leaves for the field at once (the game's "switch" command, selectedIndex 8). */
    if (phase_pick) {
        if (eidos_ui_right_click() || click_outside(c, mx, my, mw, mh)) {
            back_click = 1;
        }
        if (v.mode != 21 && back_click) {
            eidos_ui_tap(236, 180, 3);
        }
        if (click_slot < 0) {
            /* the start menu's party row: pick that Pokemon now */
            int want;

            if (eidos_ui_scene_age() >= 20 &&
                eidos_ui_take_intent(EIDOS_UI_INTENT_PARTY_PICK, &want) &&
                want >= 0 && want < 6) {
                click_slot = want;
            }
        }
        if (click_slot >= 0) {
            eidos_ui_tap(k_plate_tap[click_slot][0], k_plate_tap[click_slot][1], 3);
        }
        if (entry && v.phase == 2) {
            /* CONFIRM and CANCEL, the game's two buttons (touch rects
             * 96..176 and 176..255 on rows 168..191; keys: slots 6 and 7);
             * a link battle has CONFIRM alone, in CANCEL's place */
            int b, nb = v.mode == 1 ? 1 : 2;

            for (b = 0; b < nb; b++) {
                EidosUiRect rr;
                char bt[24];
                int hit, lit;

                rr.w = 68;
                rr.h = 18;
                rr.x = pl.msg.x + pl.msg.w - (nb - b) * (rr.w + 4) + 4;
                rr.y = pl.msg.y + pl.msg.h - 30 + 6;
                hit = eidos_ui_hit(rr);
                lit = (hit & EIDOS_UI_HOVER) || (v.selected == 6 + b && v.touch_mode == 0 && eidos_ui_keys_lit());
                (void)msg_text(BANK_PARTY, (u32)b, bt, (int)sizeof bt, 0);
                ui_panel(c, rr.x, rr.y, rr.w, rr.h, UI_CUT_TL | UI_CUT_BR, 4,
                         lit ? UI_NAVY2 : UI_BODY, lit ? UI_SKY : UI_EDGE, 255);
                ui_text(c, rr.x + (rr.w - ui_text_w(bt, UI_FONT_SMALL)) / 2,
                        rr.y + ui_text_y(rr.h, UI_FONT_SMALL), bt, UI_WHITE, UI_EDGE,
                        UI_FONT_SMALL, 1);
                if (hit & EIDOS_UI_CLICK) {
                    eidos_ui_tap(b == 0 && nb == 2 ? 136 : 216, 180, 3);
                }
            }
        }
        if (v.switch_enabled && v.phase == 2 && !pl.no_exit) {
            EidosUiRect rr;
            int sw = 46;

            rr.x = pl.msg.x + pl.msg.w - sw; rr.y = pl.msg.y + pl.msg.h - 30 + 7; rr.w = sw; rr.h = 16;
            {
                int hit = eidos_ui_hit(rr);

                ui_panel(c, rr.x, rr.y, rr.w, rr.h, UI_CUT_TL | UI_CUT_BR, 4,
                         (hit & EIDOS_UI_HOVER) ? UI_NAVY2 : UI_BODY,
                         (hit & EIDOS_UI_HOVER) ? UI_SKY : UI_EDGE, 255);
                ui_text(c, rr.x + (sw - ui_text_w("EXIT", UI_FONT_SMALL)) / 2,
                        rr.y + ui_text_y(16, UI_FONT_SMALL), "EXIT", UI_WHITE, UI_EDGE,
                        UI_FONT_SMALL, 1);
                if (hit & EIDOS_UI_CLICK) {
                    eidos_ui_tap(212, 180, 3);
                }
            }
        }
    }
    if (msg_open && eidos_ui_right_click()) {
        eidos_ui_press(BW_KEY_A, 3);
    }
    draw_hints(c, hints, hint_keys, 3);
}

static void party_reset(void)
{
    g_detail_at = -1;
    g_party_hover = -1;
}

static const EidosUiRecipe recipe_party_list = {
    "party list", party_match, party_run, party_reset, 0
};

/* ================================================================== */
/* The Pokemon summary (overlay 131)                                   */
/* ================================================================== */

/* PStatusWork offsets (ov131/p_status_types.h) */
#define SW_PARAM       0x008
#define SW_POS         0x018
#define SW_ISEGG       0x038
#define SW_HASRIBBON   0x040
#define SW_INPUTENABLE 0x044
#define SW_SEQ         0x050
#define SW_PAGE        0x058
#define SW_INFO        0x08C
#define SW_SKILL       0x090
#define SW_RIBBON      0x094
#define SW_TEMPPP      0x258
/* PStatusProcParam */
#define SP_PPD         0x00
#define SP_CONFIG      0x08
#define SP_PPT         0x0C
#define SP_MODE        0x0D
#define SP_MAX         0x0E
#define SP_NATIONAL    0x18
#define SP_NEWMOVE     0x14
#define SP_CANUSE      0x20
/* PStaSkillWork */
#define SK_ISMOVEHELD  0x14
#define SK_CURSOR      0x29
#define SK_HELD        0x2A
#define SK_SLOTCOUNT   0x2B
/* PStaInfoWork */
#define IW_DEXTABLE    0x08
/* PStaRibbonWork */
#define RB_COUNT       0x010
#define RB_OWNED       0x138

typedef struct SummaryView {
    const void *work, *param;
    void *mon;
    int pos, max, page, mode, egg, has_ribbon, input_enabled, seq, can_use;
    int cursor, slot_count;
} SummaryView;

static int summary_read(SummaryView *s)
{
    const void *w = app_work(131, NULL, NULL);
    const void *p;
    int ppt;
    void *mon;

    if (w == NULL) {
        return 0;
    }
    p = rdp(w, SW_PARAM);
    if (p == NULL) {
        return 0;
    }
    ppt = (int)rd8(p, SP_PPT);
    s->pos = (int)rd16(w, SW_POS);
    if (ppt == 0) {
        mon = rdp(p, SP_PPD);
    } else if (ppt == 1) {
        void *party = rdp(p, SP_PPD);

        mon = party != NULL ? POKEPARTY_GetMember(party, (u32)s->pos) : NULL;
    } else {
        mon = rdp(w, SW_TEMPPP);
    }
    if (mon == NULL) {
        return 0;
    }
    s->work = w;
    s->param = p;
    s->mon = mon;
    s->max = (int)rd8(p, SP_MAX);
    s->page = rds32(w, SW_PAGE);
    s->mode = (int)rd8(p, SP_MODE);
    s->egg = (int)rd32(w, SW_ISEGG) != 0;
    s->has_ribbon = rds32(w, SW_HASRIBBON) != 0;
    s->input_enabled = rds32(w, SW_INPUTENABLE) != 0;
    s->seq = rds32(w, SW_SEQ);
    s->can_use = rds32(p, SP_CANUSE) != 0;
    s->cursor = 0xFF;
    s->slot_count = 4;
    {
        const void *sk = rdp(w, SW_SKILL);

        if (sk != NULL) {
            s->cursor = (int)rd8(sk, SK_CURSOR);
            s->slot_count = (int)rd8(sk, SK_SLOTCOUNT);
        }
    }
    return 1;
}

static int summary_match(void)
{
    SummaryView s;

    return summary_read(&s) && s.page >= 0 && s.page <= 3;
}

/* The state the recipe keeps between frames. */
static u32 g_prev_buttons;
static int g_move_hover = -1;

/* Move data from the game's move table. */
typedef struct MoveInfo {
    int type, klass, power, accuracy, always;
} MoveInfo;

static void move_info(u32 move, MoveInfo *mi)
{
    mi->type = UI_TYPE_UNKNOWN;
    mi->klass = 0;
    mi->power = 0;
    mi->accuracy = 0;
    mi->always = 0;
    if (WAZA_TOOL_GetParam == NULL || move == 0) {
        return;
    }
    mi->type = kit_type((int)WAZA_TOOL_GetParam(move, 0));
    mi->klass = (int)WAZA_TOOL_GetParam(move, 2);
    mi->power = (int)WAZA_TOOL_GetParam(move, 3);
    mi->accuracy = (int)WAZA_TOOL_GetParam(move, 4);
    mi->always = WAZA_TOOL_IsAlwaysHit != NULL ? (int)WAZA_TOOL_IsAlwaysHit((u16)move) : 0;
}

/* The game's class (0 status, 1 physical, 2 special) in the kit's order. */
static int kit_class(int k)
{
    return k == 1 ? 0 : k == 2 ? 1 : 2;
}

typedef struct WrapOut {
    EidosUiCtx *c;
    int x, y, lh, n, max, font;
    u32 color;
    s32 shadow;
} WrapOut;

static void wrap_line(void *user, const char *s, int len)
{
    WrapOut *w = (WrapOut *)user;
    char tmp[200];

    if (w->n >= w->max) {
        return;
    }
    if (len > (int)sizeof tmp - 1) {
        len = (int)sizeof tmp - 1;
    }
    memcpy(tmp, s, (size_t)len);
    tmp[len] = '\0';
    ui_text(w->c, w->x, w->y + w->n * w->lh, tmp, w->color, w->shadow, w->font, 1);
    w->n++;
}

/* Wrapped text inside a width, at most `max` lines. */
static void draw_wrapped(EidosUiCtx *c, int x, int y, int width, int lh, int max,
                         const char *text, int font, u32 color, s32 shadow)
{
    WrapOut w;

    w.c = c; w.x = x; w.y = y; w.lh = lh; w.n = 0; w.max = max; w.font = font;
    w.color = color; w.shadow = shadow;
    (void)ui_wrap(text, width, font, wrap_line, &w);
}


/* ---- the left card: name, picture, types, number, OT, item ---- */

static void draw_card(EidosUiCtx *c, const SummaryView *s, int x, int y, int w, int h,
                      const EidosUiFrame *in)
{
    char nick[40], tmp[64];
    int nx, species = (int)pv(s->mon, P_SPECIES), form = (int)pv(s->mon, P_FORM);
    const UiImage *img;
    int k, picx, picy, picw, ty, t1, t2, ry, column = 0;
    int gender = gender_of(s->mon);

    {
        int fx = x, fy = y, fw = w, fh = h;

        if (!ui_app_window(c, "summary-card", &fx, &fy, &fw, &fh)) {
            ui_panel(c, x, y, w, h, UI_CUT_TL | UI_CUT_BR, 6, UI_BODY2, UI_EDGE, 255);
        } else {
            column = 1;         /* a theme's column: its rows at its foot */
        }
    }
    mon_nick(s->mon, nick, (int)sizeof nick);
    ty = ui_text_y(16, UI_FONT_LARGE);
    nx = ui_text(c, x + 6, y + 3 + ty, nick, UI_WHITE, UI_EDGE, UI_FONT_LARGE, 1);
    if (!s->egg) {
        char lv[16];

        ui_gender(c, nx + 3, y + 3 + ty, gender, UI_FONT_LARGE);
        snprintf(lv, sizeof lv, "%s%d", ui_tr("Lv."), (int)pv(s->mon, P_LEVEL));
        ui_text(c, x + w - 6 - ui_text_w(lv, UI_FONT_SMALL), y + 3 + ui_text_y(16, UI_FONT_SMALL),
                lv, UI_LIGHT, UI_EDGE, UI_FONT_SMALL, 1);
    }

    /* the picture: the game's 3D model cannot be copied, so the party icon
     * grows by a whole number */
    img = ui_mon_icon((u16)species, (u8)form, (int)((in->frame / 24) & 1));
    if (w > 130 && !s->egg && ui_mon_front((u16)species, (u8)form, 0) != NULL) {
        img = ui_mon_front((u16)species, (u8)form, 0);      /* a wide card: its picture */
    }
    picw = w - 12;
    k = fit_scale(img != NULL ? img->w : 32, picw);
    {
        int ih = img != NULL ? img->h : 32;
        int room_h = h - 22 - 2 - 3 - 16 - 2 * 17 - 4;     /* two rows stay */

        if (k * ih > room_h) {
            k = room_h / ih;
        }
        if (k < 1) k = 1;
    }
    picx = x + (w - (img != NULL ? img->w * k : 32)) / 2;
    picy = y + 22 + 2;
    if (column && !s->egg) {
        /* the rows at the foot, the tags over them, the picture in the
         * middle of the room above; its shadow under its feet */
        int iw = img != NULL ? img->w : 32, ih = img != NULL ? img->h : 32;
        int rows_y = y + h - 3 * 17 - 2, tags_y = rows_y - 19, room = tags_y - 8 - picy, foot = ih, yy, xx;

        k = fit_scale(iw, picw);
        while (k > 1 && k * ih > room) {
            k--;
        }
        if (img != NULL && img->rgba != NULL) {
            for (yy = ih - 1; yy > 0; yy--) {
                for (xx = 0; xx < iw; xx++) {
                    if (img->rgba[((size_t)yy * (size_t)iw + (size_t)xx) * 4u + 3u] != 0) {
                        break;
                    }
                }
                if (xx < iw) {
                    break;
                }
            }
            foot = yy + 1;
        }
        picx = x + (w - iw * k) / 2;
        picy += (room - ih * k) / 2 > 0 ? (room - ih * k) / 2 : 0;
        ui_ellipse(c, x + w / 2 - 30 * k / 2, picy + foot * k - 5, 30 * k, 10, 0x0A0A0Au, UI_NONE, 255);
        if (img != NULL) {
            ui_image(c, picx, picy, img, k);
        }
        ry = tags_y;
    } else {
        ui_ellipse(c, x + w / 2 - 26, picy + (img != NULL ? img->h * k : 32) - 8, 52, 12,
                   0x0A0A0Au, UI_NONE, 255);
        if (img != NULL) {
            ui_image(c, picx, picy, img, k);
        }
        ry = picy + (img != NULL ? img->h * k : 32) + 3;
    }

    if (!s->egg) {
        t1 = kit_type((int)pv(s->mon, P_TYPE1));
        t2 = kit_type((int)pv(s->mon, P_TYPE2));
        if (getenv("EIDOS_UI_DEBUG") != NULL) {
            fprintf(stderr, "party: types %d %d species %d\n", t1, t2, species);
        }
        if (t2 != t1) {
            int tw = (w - 16) / 2;

            ui_type_tag(c, x + 6, ry, tw, t1);
            ui_type_tag(c, x + w - 6 - tw, ry, tw, t2);
        } else {
            ui_type_tag(c, x + (w - 60) / 2, ry, 60, t1);
        }
    }
    ry += column && !s->egg ? 19 : 16;
    /* number, original trainer, held item */
    if (!s->egg) {
        u32 dex = (u32)species;
        const void *info = rdp(s->work, SW_INFO);

        if (rd32(s->param, SP_NATIONAL) == 0 && info != NULL) {
            const u16 *tab = (const u16 *)rdp(info, IW_DEXTABLE);

            if (tab != NULL && species < 650) {
                dex = tab[species];
            }
        }
        snprintf(tmp, sizeof tmp, "%03u", (unsigned)dex);
        (void)msg_text(BANK_SUMMARY, 8, nick, (int)sizeof nick, 0);
        if (ry + 17 * 3 <= y + h) {         /* the number only when all three rows fit */
            ui_info_row(c, x + 4, ry, w - 8, nick, tmp);
            ry += 17;
        }
    }
    mon_ot(s->mon, tmp, (int)sizeof tmp);
    (void)msg_text(BANK_SUMMARY, 13, nick, (int)sizeof nick, 0);
    ui_info_row(c, x + 4, ry, w - 8, nick, tmp);
    ry += 17;
    {
        u32 item = pv(s->mon, P_ITEM);

        (void)msg_text(BANK_SUMMARY, 4, nick, (int)sizeof nick, 0);
        if (item != 0) {
            (void)msg_text(BANK_ITEM, item, tmp, (int)sizeof tmp, 0);
        } else {
            (void)msg_text(BANK_SUMMARY, 6, tmp, (int)sizeof tmp, 0);
        }
        ui_info_row(c, x + 4, ry, w - 8, nick, tmp);
    }
}

/* ---- pages ---- */

static void draw_info_page(EidosUiCtx *c, const SummaryView *s, int x, int y, int w, int h)
{
    char tmp[128], lab[48], val[80];
    u32 level = pv(s->mon, P_LEVEL), exp = pv(s->mon, P_EXP);
    u32 species = pv(s->mon, P_SPECIES), form = pv(s->mon, P_FORM);
    u32 cur = 0, next = 0;
    int yy = y;

    ui_panel(c, x, y, w, h, UI_CUT_TL | UI_CUT_BR, 6, UI_BODY2, UI_EDGE, 255);
    if (s->egg) {
        draw_wrapped(c, x + 8, y + 8, w - 16, 16, 4,
                     "What will hatch from this Egg? It will take some time.",
                     UI_FONT_LARGE, UI_WHITE, UI_EDGE);
        return;
    }
    yy = y + 6;
    (void)msg_text(BANK_SUMMARY, 10, lab, (int)sizeof lab, 0);
    (void)msg_text(BANK_SPECIES, species, val, (int)sizeof val, 0);
    ui_info_row(c, x + 6, yy, w - 12, lab, val);
    yy += 17;
    (void)msg_text(BANK_SUMMARY, 15, lab, (int)sizeof lab, 0);
    snprintf(val, sizeof val, "%05u", (unsigned)(pv(s->mon, P_OT_ID) & 0xFFFFu));
    ui_info_row(c, x + 6, yy, w - 12, lab, val);
    yy += 17;
    (void)msg_text(BANK_SUMMARY, 17, lab, (int)sizeof lab, 0);
    snprintf(val, sizeof val, "%u", (unsigned)exp);
    ui_info_row(c, x + 6, yy, w - 12, lab, val);
    yy += 17;
    if (POKE_TOOL_GetExpForLevel != NULL) {
        cur = POKE_TOOL_GetExpForLevel(species, form, level);
        next = POKE_TOOL_GetExpForLevel(species, form, level + 1);
    }
    (void)msg_text(BANK_SUMMARY, 19, lab, (int)sizeof lab, 0);
    snprintf(val, sizeof val, "%u", (unsigned)(next > exp ? next - exp : 0));
    ui_info_row(c, x + 6, yy, w - 12, lab, val);
    yy += 17;
    if (next > cur && level < 100) {
        ui_text(c, x + 8, yy + ui_text_y(10, UI_FONT_SMALL), "EXP", UI_SKY, UI_NAVY,
                UI_FONT_SMALL, 1);
        ui_bar(c, x + 34, yy + 3, w - 46, 5, (int)(exp > cur ? exp - cur : 0),
               (int)(next - cur));
    }
    yy += 14;
    /* nature, and where it was met */
    (void)msg_text(BANK_NATURE, pv(s->mon, P_NATURE), val, (int)sizeof val, 0);
    snprintf(tmp, sizeof tmp, ui_trf("%s nature."), val);
    ui_text(c, x + 8, yy + ui_text_y(14, UI_FONT_LARGE), tmp, UI_WHITE, UI_EDGE,
            UI_FONT_LARGE, 1);
    yy += 15;
    {
        u32 loc = pv(s->mon, P_MET_LOC);
        char place[64];

        (void)msg_text(BANK_PLACE, loc, place, (int)sizeof place, 0);
        if (place[0] != '\0') {
            snprintf(tmp, sizeof tmp, ui_trf("Met at %s, Lv. %u."), place, (unsigned)pv(s->mon, P_MET_LEVEL));
            draw_wrapped(c, x + 8, yy + 2, w - 16, 14, 2, tmp, UI_FONT_MEDIUM, UI_LIGHT, UI_EDGE);
        }
    }
}

static const int k_slot_tap_y[5] = { 32, 64, 96, 128, 176 };
static int g_sum_big;           /* the fused summary: descriptions in the medium letters */

static void draw_moves(EidosUiCtx *c, const SummaryView *s, int x, int y, int w, int h,
                       int rowh, const EidosUiFrame *in)
{
    int i, n = s->slot_count > 4 ? 5 : 4;
    int shown_move = 0, hov = -1, yy = y;
    MoveInfo mi;
    char name[64], d[300], tmp[32];
    int detail_y;
    u32 newmove = rd16(s->param, SP_NEWMOVE);

    static int drag_from = -1;
    int px, py, pressed, released;

    (void)eidos_ui_pointer(&px, &py, &pressed, &released);
    g_move_hover = -1;
    for (i = 0; i < n; i++) {
        u32 mv = i < 4 ? pv(s->mon, P_MOVE1 + (u32)i) : newmove;
        EidosUiRect r;
        int hit, sel, over;

        r.x = x; r.y = yy; r.w = w; r.h = rowh;
        sel = (!s->input_enabled && s->cursor == i) || (drag_from == i && eidos_ui_held());
        over = px >= r.x && py >= r.y && px < r.x + r.w && py < r.y + r.h;
        if (mv != 0) {
            MoveInfo m2;

            hit = eidos_ui_hit(r);
            if (hit & EIDOS_UI_HOVER) {
                hov = i;
            }
            /* A move dragged onto another swaps them, as the game's drag
             * on its own screen does (P_STA_SKILL_HandleTouch); a click
             * only showed a move, so the order could not be changed with
             * the mouse or a finger (#24). */
            if (pressed && over && i < 4) {
                drag_from = i;
            }
            if (released && over && i < 4 && drag_from >= 0 && drag_from != i && s->seq == 4) {
                eidos_ui_drag(76, k_slot_tap_y[drag_from], 76, k_slot_tap_y[i]);
                drag_from = -1;
            }
            if ((hit & EIDOS_UI_CLICK) && s->seq == 4) {
                eidos_ui_tap(76, k_slot_tap_y[i], 3);
            }
            move_info(mv, &m2);
            (void)msg_text(BANK_MOVE, mv, name, (int)sizeof name, 0);
            if (ui_move_name_modern((int)mv, name) != NULL) {
                snprintf(name, sizeof name, "%s", ui_move_name_modern((int)mv, name));
            }
            ui_move_row(c, x, yy, w, m2.type, name,
                        i < 4 ? (int)pv(s->mon, P_PP1 + (u32)i) : 0,
                        i < 4 ? (int)pv(s->mon, P_MAXPP1 + (u32)i) : 0, sel || hov == i);
            if (i == 4) {
                ui_text(c, x + w - 44, yy + ui_text_y(rowh, UI_FONT_SMALL), "NEW", UI_CYAN,
                        UI_NAVY, UI_FONT_SMALL, 1);
            }
        } else {
            ui_move_row(c, x, yy, w, 0, NULL, 0, 0, 0);
        }
        yy += rowh + 3;
    }
    g_move_hover = hov;
    if (released || !eidos_ui_held()) {
        drag_from = released ? -1 : drag_from;
    }

    /* the move under the pointer, else the chosen one, else the first */
    if (hov >= 0) {
        shown_move = hov;
    } else if (!s->input_enabled && s->cursor < 5) {
        shown_move = s->cursor;
    }
    {
        u32 mv = shown_move < 4 ? pv(s->mon, P_MOVE1 + (u32)shown_move) : newmove;

        detail_y = yy + 1;
        if (mv == 0 || detail_y + 30 > y + h) {
            return;
        }
        move_info(mv, &mi);
        ui_panel(c, x, detail_y, w, y + h - detail_y, UI_CUT_TL | UI_CUT_BR, 5, UI_BODY2,
                 UI_EDGE, 255);
        ui_category_icon(c, x + 5, detail_y + 4, kit_class(mi.klass));
        (void)msg_text(BANK_SUMMARY, 147, tmp, (int)sizeof tmp, 0);
        snprintf(name, sizeof name, "%s %s", tmp, mi.power <= 1 ? "--" : "");
        if (mi.power > 1) {
            snprintf(name, sizeof name, "%s %d", tmp, mi.power);
        }
        ui_text(c, x + 25, detail_y + 3 + ui_text_y(11, UI_FONT_SMALL), name, UI_WHITE,
                UI_EDGE, UI_FONT_SMALL, 1);
        (void)msg_text(BANK_SUMMARY, 148, tmp, (int)sizeof tmp, 0);
        if (mi.accuracy == 0 || mi.always) {
            snprintf(name, sizeof name, "%s --", tmp);
        } else {
            snprintf(name, sizeof name, "%s %d", tmp, mi.accuracy);
        }
        ui_text(c, x + w - 6 - ui_text_w(name, UI_FONT_SMALL),
                detail_y + 3 + ui_text_y(11, UI_FONT_SMALL), name, UI_WHITE, UI_EDGE,
                UI_FONT_SMALL, 1);
        {
            int lh = g_sum_big ? 16 : 11;
            int ty = detail_y + (g_sum_big ? 20 : 17), lines = (y + h - ty - 2) / lh;

            (void)msg_text(BANK_MOVE_DESC, mv, d, (int)sizeof d, 0);
            if (lines > 0) {
                draw_wrapped(c, x + 6, ty, w - 12, lh, lines, d, g_sum_big ? UI_FONT_LARGE : UI_FONT_SMALL, UI_LIGHT,
                             UI_EDGE);
            }
        }
    }
    (void)in;
}

/* The stats: HP, then the five, one each `pitch` lines.  Returns the line
 * under them. */
static int draw_stats(EidosUiCtx *c, const SummaryView *s, int x, int y, int colw, int pitch)
{
    static const u32 stat_id[5] = { P_ATK, P_DEF, P_SPA, P_SPD, P_SPE };
    u32 hp = pv(s->mon, P_HP), maxhp = pv(s->mon, P_MAXHP);
    char lab[32], val[32];
    int i, yy = y, maxstat = 1;

    ui_panel(c, x, yy, colw, 17, UI_CUT_TL | UI_CUT_BR, 4, UI_BODY2, UI_EDGE, 255);
    ui_text(c, x + 6, yy + ui_text_y(17, UI_FONT_LARGE), "HP", UI_LIME, UI_DEX3, UI_FONT_LARGE, 1);
    snprintf(val, sizeof val, "%u/%u", (unsigned)hp, (unsigned)maxhp);
    ui_bar(c, x + 26, yy + 6, colw - 32 - ui_text_w(val, UI_FONT_SMALL) - 4, 5, (int)hp, (int)maxhp);
    ui_text(c, x + colw - 6 - ui_text_w(val, UI_FONT_SMALL), yy + ui_text_y(17, UI_FONT_SMALL),
            val, UI_LIGHT, UI_EDGE, UI_FONT_SMALL, 1);
    yy += pitch + 2;
    for (i = 0; i < 5; i++) {
        if ((int)pv(s->mon, stat_id[i]) > maxstat) {
            maxstat = (int)pv(s->mon, stat_id[i]);
        }
    }
    for (i = 0; i < 5; i++) {
        u32 v = pv(s->mon, stat_id[i]);

        (void)msg_text(BANK_SUMMARY, 111 + (u32)i, lab, (int)sizeof lab, 0);
        ui_stat_row(c, x, yy, colw, lab, (int)v, (int)v, maxstat * 3 / 2, UI_SKY);
        yy += pitch;
    }
    return yy;
}

/* The ability, with its description. */
static void draw_ability(EidosUiCtx *c, const SummaryView *s, int x, int y, int w, int h)
{
    u32 ability = pv(s->mon, P_ABILITY);
    char d[300], ab[64];

    if (h < 22) {
        return;
    }
    ui_panel(c, x, y, w, h, UI_CUT_TL | UI_CUT_BR, 5, UI_BODY2, UI_EDGE, 255);
    (void)msg_text(BANK_ABILITY, ability, ab, (int)sizeof ab, 0);
    ui_text(c, x + 6, y + 2 + ui_text_y(13, UI_FONT_LARGE), ab, UI_WHITE, UI_EDGE, UI_FONT_LARGE, 1);
    (void)msg_text(BANK_ABILITY_D, ability, d, (int)sizeof d, 0);
    if (h >= 34) {
        int lh = g_sum_big ? 16 : 11;

        draw_wrapped(c, x + 6, y + (g_sum_big ? 20 : 17), w - 12, lh, (h - (g_sum_big ? 22 : 19)) / lh, d,
                     g_sum_big ? UI_FONT_LARGE : UI_FONT_SMALL, UI_LIGHT, UI_EDGE);
    }
}

static void draw_skills_page(EidosUiCtx *c, const SummaryView *s, int x, int y, int w, int h,
                             const EidosUiFrame *in)
{
    int colw = w * 40 / 100, yy;

    yy = draw_stats(c, s, x, y, colw, 17);
    draw_ability(c, s, x, yy, colw, y + h - yy);
    draw_moves(c, s, x + colw + 6, y, w - colw - 6, h, 19, in);
}

/* INFO and SKILLS on one screen, over its whole height.  Left: the facts,
 * the stats under them.  Right: the moves, the chosen move's card, the
 * ability. */
#define INFO_H 140

static void draw_one_screen(EidosUiCtx *c, const SummaryView *s, int x, int y, int w, int h,
                            const EidosUiFrame *in)
{
    int lw = w * 46 / 100, rx = x + lw + 6, rw = w - lw - 6;
    int pitch = (h - INFO_H - 6 - 2) / 6, mvh = 4 * 22 + 1, abh;

    pitch = pitch < 17 ? 17 : pitch > 24 ? 24 : pitch;
    draw_info_page(c, s, x, y, lw, INFO_H);
    (void)draw_stats(c, s, x, y + INFO_H + 6, lw, pitch);
    abh = (h - mvh) * 42 / 100;
    abh = abh < 58 ? 58 : abh > 76 ? 76 : abh;
    g_sum_big = 1;
    draw_moves(c, s, rx, y, rw, h - abh - 6, 19, in);
    draw_ability(c, s, rx, y + h - abh, rw, abh);
    g_sum_big = 0;
}

static void draw_forget_page(EidosUiCtx *c, const SummaryView *s, int x, int y, int w, int h,
                             const EidosUiFrame *in)
{
    /* choose a move to forget: the game's page 3, moves only */
    draw_moves(c, s, x, y, w, h, 19, in);
}

/* The ribbon table (ov131 data, 16 byte rows: parameter id, file, anim,
 * name message, description message, selector). */
#define RIBBON_TABLE_ADDR 0x021DC2F8u
#define RIBBON_ROWS 80

static const u8 *ribbon_table(void)
{
    const u8 *t = (const u8 *)bw_ds_try_ptr(RIBBON_TABLE_ADDR);
    int i;

    if (t == NULL) {
        return NULL;
    }
    /* a sanity check: every row names messages inside the ribbon bank */
    for (i = 0; i < RIBBON_ROWS; i += 9) {
        if (rd16(t, 16u * (u32)i + 8) > 200 || rd16(t, 16u * (u32)i + 10) > 200 ||
            rd32(t, 16u * (u32)i) > 0xB1) {
            return NULL;
        }
    }
    return t;
}

static int g_ribbon_sel;
static int g_ribbon_scroll;

static void draw_ribbon_page(EidosUiCtx *c, const SummaryView *s, int x, int y, int w, int h,
                             const EidosUiFrame *in)
{
    const void *rw = rdp(s->work, SW_RIBBON);
    const u8 *tab = ribbon_table();
    int n = rw != NULL ? (int)rd8(rw, RB_COUNT) : 0, i, rows, rowh = 17, listw;
    char name[80], d[300];
    EidosUiRect lr;

    ui_panel(c, x, y, w, h, UI_CUT_TL | UI_CUT_BR, 6, UI_BODY2, UI_EDGE, 255);
    if (n <= 0 || tab == NULL) {
        ui_text(c, x + 8, y + 8, "No ribbons.", UI_GREY, UI_EDGE, UI_FONT_LARGE, 1);
        return;
    }
    if (n > 81) n = 81;
    listw = w * 55 / 100;
    rows = (h - 8) / (rowh + 1);
    lr.x = x; lr.y = y; lr.w = listw; lr.h = h;
    {
        int wheel = eidos_ui_wheel(lr);

        g_ribbon_scroll -= wheel;
    }
    if (g_ribbon_sel >= n) g_ribbon_sel = 0;
    if (g_ribbon_sel < g_ribbon_scroll) g_ribbon_scroll = g_ribbon_sel;
    if (g_ribbon_sel >= g_ribbon_scroll + rows) g_ribbon_scroll = g_ribbon_sel - rows + 1;
    if (g_ribbon_scroll > n - rows) g_ribbon_scroll = n - rows;
    if (g_ribbon_scroll < 0) g_ribbon_scroll = 0;
    for (i = 0; i < rows && g_ribbon_scroll + i < n; i++) {
        int idx = g_ribbon_scroll + i;
        u32 no = rd8(rw, RB_OWNED + 8u * (u32)idx + 4);
        EidosUiRect r;
        int hit;

        r.x = x + 4; r.y = y + 4 + i * (rowh + 1); r.w = listw - 12; r.h = rowh;
        hit = eidos_ui_hit(r);
        if (hit & EIDOS_UI_CLICK) {
            g_ribbon_sel = idx;
        }
        ui_row(c, r.x, r.y, r.w, r.h, idx == g_ribbon_sel, (hit & EIDOS_UI_HOVER) != 0,
               &UI_THEME_PARTY);
        if (no < RIBBON_ROWS) {
            (void)msg_text(BANK_RIBBON, rd16(tab, 16u * no + 8), name, (int)sizeof name, 0);
            ui_text(c, r.x + 7, r.y + ui_text_y(rowh, UI_FONT_LARGE), name, UI_WHITE, UI_EDGE,
                    UI_FONT_LARGE, 1);
        }
    }
    ui_scrollbar(c, x + listw - 6, y + 4, h - 8, g_ribbon_scroll, rows, n, UI_SKY);
    {
        u32 no = rd8(rw, RB_OWNED + 8u * (u32)g_ribbon_sel + 4);

        if (no < RIBBON_ROWS) {
            int dx = x + listw + 6, dw = w - listw - 12;

            (void)msg_text(BANK_RIBBON, rd16(tab, 16u * no + 8), name, (int)sizeof name, 0);
            draw_wrapped(c, dx, y + 8, dw, 15, 2, name, UI_FONT_LARGE, UI_WHITE, UI_EDGE);
            (void)msg_text(BANK_RIBBON, rd16(tab, 16u * no + 10), d, (int)sizeof d, 0);
            draw_wrapped(c, dx, y + 42, dw, 12, (h - 46) / 12, d, UI_FONT_MEDIUM, UI_LIGHT,
                         UI_EDGE);
        }
    }
    (void)in;
}

/* Choosing a move to forget for a new one (the summary's mode 2), laid out
 * as the battle's forget page (recipe_battle.c, pl_summary): the four moves
 * and the new one under them, the details of one, FORGET and BACK.  The
 * game's own page takes two steps (P_STA_SKILL_HandleKeysForget and
 * ...TouchForget): a move is picked (PStaSkillWork.isPickingForget, its slot
 * heldSlot, the cursor then on the new move), and A, or a touch on the new
 * move, confirms.  So a click on a move picks it (a touch of its slot), its
 * details show with FORGET, which is A; BACK and B put it back.  Before a
 * move is picked, B gives the new move up, as on the DS. */
#define SK_PICKING     0x18
#define SK_CONFIRMED   0x20

static int g_forget_next = -1;  /* a move to pick once the picked one is put back */
static int g_forget_steps;      /* cursor steps still to press: + down, - up */
static u32 g_forget_step_frame;

/* The slot an arrow leads to on the page: 0 1 / 2 3 / the new move, 4. */
static int forget_target(int cur, u32 keys)
{
    if (keys & BW_KEY_LEFT) return cur < 4 ? cur ^ 1 : cur;
    if (keys & BW_KEY_RIGHT) return cur < 4 ? cur ^ 1 : cur;
    if (keys & BW_KEY_UP) return cur == 4 ? 2 : cur >= 2 ? cur - 2 : 4;
    if (keys & BW_KEY_DOWN) return cur == 4 ? 0 : cur + 2 > 4 ? 4 : cur + 2;
    return cur;
}

static int move_pp_max(u32 mv)
{
    return WAZA_TOOL_GetParam != NULL ? (int)WAZA_TOOL_GetParam(mv, 5) : 0;
}

static void forget_view(EidosUiCtx *c, const SummaryView *s, int mx, int my, int mw, int mh,
                        u32 in_frame)
{
    const void *sk = rdp(s->work, SW_SKILL);
    int picking = sk != NULL && rds32(sk, SK_PICKING) != 0;
    int held = sk != NULL ? (int)rd8(sk, SK_HELD) : 5;
    int busy = sk == NULL || rds32(sk, SK_CONFIRMED) != 0 || s->seq != 4;
    int ix = mx + 8, iy = my + 4 + 22 + 6, iw = mw - 16;
    int nav_y = my + mh - 6 - 18, i, hov = -1, shown, st;
    int mw2 = (iw - 24) / 2;
    u32 newmove = rd16(s->param, SP_NEWMOVE);
    char nick[40], q[48];
    static const char *const hints_pick[] = { "A", "Forget", "B", "Back" };
    static const char *const hints_list[] = { "A", "Choose", "B", "Give up" };
    static const u32 keys[] = { BW_KEY_A, BW_KEY_B };

    if (held > 3) {
        picking = 0;
    }
    if (!picking && !busy) {
        u32 keys;

        eidos_ui_take_keys(BW_KEY_UP | BW_KEY_DOWN | BW_KEY_LEFT | BW_KEY_RIGHT);
        keys = eidos_ui_keys_pressed() & (BW_KEY_UP | BW_KEY_DOWN | BW_KEY_LEFT | BW_KEY_RIGHT);
        if (keys != 0 && g_forget_steps == 0 && s->cursor <= 4) {
            int to = forget_target(s->cursor, keys), d = to - s->cursor;

            /* the game's column wraps through five slots: the shorter way */
            if (d > 2) d -= 5;
            if (d < -2) d += 5;
            g_forget_steps = d;
        }
        /* one press every other frame, so the game sees each as new */
        if (g_forget_steps != 0 && in_frame - g_forget_step_frame >= 2) {
            eidos_ui_press(g_forget_steps > 0 ? BW_KEY_DOWN : BW_KEY_UP, 1);
            g_forget_steps += g_forget_steps > 0 ? -1 : 1;
            g_forget_step_frame = in_frame;
        }
    } else {
        g_forget_steps = 0;
    }
    /* a move clicked while another was picked: once that one is back */
    if (g_forget_next >= 0 && !picking && !busy) {
        eidos_ui_tap(76, k_slot_tap_y[g_forget_next], 3);
        g_forget_next = -1;
    }
    ui_panel(c, ix, iy, iw, nav_y - iy - 4, UI_CUT_TL | UI_CUT_BR, 5, UI_NAVY, 0x084A73u, 245);
    {
        const UiImage *icon = ui_mon_icon((u16)pv(s->mon, P_SPECIES), (u8)pv(s->mon, P_FORM), 0);
        u32 hp = pv(s->mon, P_HP), maxhp = pv(s->mon, P_MAXHP);
        int nx;

        if (icon != NULL) {
            ui_image(c, ix + 8, iy + 6, icon, 1);
        }
        mon_nick(s->mon, nick, (int)sizeof nick);
        nx = ui_text(c, ix + 38, iy + 6, nick, UI_WHITE, UI_EDGE, UI_FONT_LARGE, 1);
        ui_gender(c, nx + 3, iy + 6, gender_of(s->mon), UI_FONT_LARGE);
        snprintf(q, sizeof q, "%s%d", ui_tr("Lv."), (int)pv(s->mon, P_LEVEL));
        ui_text(c, ix + iw - 8 - ui_text_w(q, UI_FONT_LARGE), iy + 6, q, UI_LIGHT, UI_EDGE,
                UI_FONT_LARGE, 1);
        ui_bar(c, ix + 38, iy + 24, iw - 100, 4, (int)hp, (int)maxhp);
        snprintf(q, sizeof q, "%u/%u", (unsigned)hp, (unsigned)maxhp);
        ui_text(c, ix + iw - 8 - ui_text_w(q, UI_FONT_SMALL), iy + 20, q, UI_LIGHT, UI_EDGE,
                UI_FONT_SMALL, 1);
    }
    for (i = 0; i < 5; i++) {
        u32 mv = i < 4 ? pv(s->mon, P_MOVE1 + (u32)i) : newmove;
        int x2 = i < 4 ? ix + 8 + (i % 2) * (mw2 + 8) : ix + 8 + (iw - 16 - mw2) / 2;
        int y2 = iy + 34 + (i / 2) * 26;
        EidosUiRect r;
        MoveInfo m;
        char name[64];
        int hit, sel;

        if (mv == 0) {
            ui_move_row(c, x2, y2, mw2, 0, NULL, 0, 0, 0);
            continue;
        }
        r.x = x2; r.y = y2; r.w = mw2; r.h = 22;
        hit = busy ? 0 : eidos_ui_hit(r);
        if (hit & EIDOS_UI_HOVER) {
            hov = i;
        }
        if (hit & EIDOS_UI_CLICK) {
            if (i == 4) {
                if (picking) {
                    eidos_ui_press(BW_KEY_B, 3);        /* the new move stays: back */
                }
            } else if (!picking) {
                eidos_ui_tap(76, k_slot_tap_y[i], 3);
            } else if (i != held) {
                eidos_ui_press(BW_KEY_B, 3);
                g_forget_next = i;
            }
        }
        move_info(mv, &m);
        (void)msg_text(BANK_MOVE, mv, name, (int)sizeof name, 0);
        if (ui_move_name_modern((int)mv, name) != NULL) {
            snprintf(name, sizeof name, "%s", ui_move_name_modern((int)mv, name));
        }
        sel = (picking && i == held) || hov == i ||
              (!picking && s->cursor == i && eidos_ui_keys_lit());
        ui_move_row(c, x2, y2, mw2, m.type, name,
                    i < 4 ? (int)pv(s->mon, P_PP1 + (u32)i) : move_pp_max(mv),
                    i < 4 ? (int)pv(s->mon, P_MAXPP1 + (u32)i) : move_pp_max(mv), sel);
        if (i == 4) {
            ui_text(c, x2 + mw2 + 8, y2 + ui_text_y(22, UI_FONT_SMALL), "NEW", UI_CYAN, UI_NAVY,
                    UI_FONT_SMALL, 1);
        }
    }
    /* the details: the move under the pointer, else the picked one, else
     * the one under the game's cursor */
    shown = hov >= 0 ? hov : picking ? held : (s->cursor < 5 ? s->cursor : 4);
    {
        u32 mv = shown < 4 ? pv(s->mon, P_MOVE1 + (u32)shown) : newmove;
        int dy = iy + 34 + 3 * 26, dh = nav_y - 4 - 4 - dy;
        MoveInfo m;
        char lab[24], info[48], d[300];

        if (mv != 0 && dh >= 24) {
            move_info(mv, &m);
            ui_panel(c, ix + 8, dy, iw - 16, dh, UI_CUT_TL | UI_CUT_BR, 5, UI_BODY2, UI_EDGE, 255);
            ui_category_icon(c, ix + 13, dy + 4, kit_class(m.klass));
            (void)msg_text(BANK_SUMMARY, 147, lab, (int)sizeof lab, 0);
            if (m.power > 1) {
                snprintf(info, sizeof info, "%s %d", lab, m.power);
            } else {
                snprintf(info, sizeof info, "%s --", lab);
            }
            ui_text(c, ix + 33, dy + 3 + ui_text_y(11, UI_FONT_SMALL), info, UI_WHITE, UI_EDGE,
                    UI_FONT_SMALL, 1);
            (void)msg_text(BANK_SUMMARY, 148, lab, (int)sizeof lab, 0);
            if (m.accuracy == 0 || m.always) {
                snprintf(info, sizeof info, "%s --", lab);
            } else {
                snprintf(info, sizeof info, "%s %d", lab, m.accuracy);
            }
            ui_text(c, ix + iw - 14 - ui_text_w(info, UI_FONT_SMALL), dy + 3 + ui_text_y(11, UI_FONT_SMALL),
                    info, UI_WHITE, UI_EDGE, UI_FONT_SMALL, 1);
            (void)msg_text(BANK_MOVE_DESC, mv, d, (int)sizeof d, 0);
            draw_wrapped(c, ix + 13, dy + 16, iw - 26, 10, (dh - 17) / 10, d, UI_FONT_SMALL, UI_LIGHT,
                         UI_EDGE);
        }
    }
    /* FORGET while a move is picked; BACK puts it back, or GIVE UP gives
     * the new move up when none is */
    if (picking) {
        EidosUiRect r = { ix, nav_y, 140, 18 };

        st = busy ? 0 : eidos_ui_hit(r);
        ui_cmd_button(c, r.x, r.y, r.w, r.h, "FORGET", UI_PINK, (st & EIDOS_UI_HOVER) != 0);
        if (st & EIDOS_UI_CLICK) {
            eidos_ui_press(BW_KEY_A, 3);
        }
    }
    {
        int bw = picking ? 54 : 80;
        EidosUiRect r = { ix + iw - bw, nav_y, bw, 18 };

        st = busy ? 0 : eidos_ui_hit(r);
        ui_cmd_button(c, r.x, r.y, r.w, r.h, picking ? "BACK" : "GIVE UP", UI_GREY,
                      (st & EIDOS_UI_HOVER) != 0);
        if (((st & EIDOS_UI_CLICK) || eidos_ui_right_click()) && !busy) {
            eidos_ui_press(BW_KEY_B, 3);
        }
    }
    draw_hints(c, picking ? hints_pick : hints_list, keys, 2);
}

/* The Pokemon after `dir` that the game would step to (it skips empty
 * entries and, on the ribbon page, Pokemon without ribbons); the screen's
 * own up and down handle it, so the recipe only presses the keys. */

static void summary_run(EidosUiCtx *c, EidosUiView *view, const EidosUiFrame *in)
{
    SummaryView s;
    int mx, my, mw, mh, cx, cy, cw, ch, cardw, tabx, taby;
    int page_idx, wide_frame = 0, card_right = 0, one_screen = 0, tabs_row = 1;
    char right[24], sub[24];
    static const char *const hints_n[] = {
        "L R", "Page", "\xE2\x86\x91\xE2\x86\x93", "Pok\xC3\xA9mon", "B", "Back"
    };
    static const u32 keys_n[] = { BW_KEY_RIGHT, BW_KEY_DOWN, BW_KEY_B };
    int back = 0;

    view->mode = EIDOS_VIEW_WORLD;
    view->blur = 1;
    view->hold_world = 1;     /* an app: the field is not running */
    view->hide_2d = 1;
    view->zoom = 1.0f;

    if (!summary_read(&s)) {
        return;
    }
    modal_rect(c, &mx, &my, &mw, &mh);
    {
        EidosUiRect fr;

        fr.x = mx;
        fr.y = my;
        fr.w = mw;
        fr.h = mh;
        if (ui_theme_active()->app_frame != NULL && ui_theme_active()->app_frame(c, "summary", &fr)) {
            mx = fr.x;
            my = fr.y;
            mw = fr.w;
            mh = fr.h;
            wide_frame = 1;
        } else {
            draw_modal(c, mx, my, mw, mh);
        }
    }

    /* a theme's wide screen holds INFO and SKILLS together when it has the
     * width for both */
    one_screen = wide_frame && c->canvas->w >= 600;
    /* L and R turn the pages (the game's own keys for it are left and right) */
    {
        BwInputState st;
        u32 now, edge;

        bw_input_current(&st);
        now = in->buttons | st.buttons;
        edge = now & ~g_prev_buttons;
        g_prev_buttons = now;
        if (s.seq == 4 && s.input_enabled && s.mode != 2) {
            /* the pages turn with L and R alone: the arrows' left and right
             * (the game's own keys for it) are not offered twice */
            eidos_ui_take_keys(BW_KEY_LEFT | BW_KEY_RIGHT);
            if (one_screen && !s.egg) {
                /* INFO and SKILLS are one page: the keys go between it and
                 * the ribbons, when it has any (the game's own page buttons) */
                if ((edge & (BW_KEY_R | BW_KEY_L)) && s.has_ribbon) {
                    eidos_ui_tap(s.page == 2 ? 20 : 100, 180, 3);
                }
            } else {
                if (edge & BW_KEY_R) eidos_ui_press(BW_KEY_RIGHT, 2);
                if (edge & BW_KEY_L) eidos_ui_press(BW_KEY_LEFT, 2);
            }
        }
    }

    page_idx = s.page;
    snprintf(sub, sizeof sub, "%s",
             s.mode == 2 ? "FORGET A MOVE" : one_screen && page_idx <= 1 && !s.egg ? "" :
             page_idx == 0 ? "INFO" : page_idx == 1 ? "SKILLS" :
             page_idx == 2 ? "RIBBONS" : "MOVES");
    right[0] = '\0';
    if (s.max > 1) {
        snprintf(right, sizeof right, "%d/%d", s.pos + 1, s.max);
    }
    ui_header(c, mx + 4, my + 4, mw - 8, "SUMMARY", sub, "", UI_SKY);
    if (s.mode == 2) {
        forget_view(c, &s, mx, my, mw, mh, in->frame);
        return;
    }

    /* the Pokemon arrows, on the title bar */
    if (s.max > 1 && s.mode != 2) {
        int ax = mx + mw - 8 - 44, ay = my + 4 + 3;
        EidosUiRect rp, rn;
        int hp, hn;

        rp.x = ax; rp.y = ay; rp.w = 20; rp.h = 15;
        rn.x = ax + 22; rn.y = ay; rn.w = 20; rn.h = 15;
        hp = eidos_ui_hit(rp);
        hn = eidos_ui_hit(rn);
        ui_fill(c, rp.x, rp.y, rp.w, rp.h, (hp & EIDOS_UI_HOVER) ? UI_EDGE : UI_BODY2, 255);
        ui_fill(c, rn.x, rn.y, rn.w, rn.h, (hn & EIDOS_UI_HOVER) ? UI_EDGE : UI_BODY2, 255);
        ui_text(c, rp.x + 5, rp.y + ui_text_y(15, UI_FONT_SMALL), "\xE2\x86\x91", UI_WHITE,
                UI_EDGE, UI_FONT_SMALL, 1);
        ui_text(c, rn.x + 5, rn.y + ui_text_y(15, UI_FONT_SMALL), "\xE2\x86\x93", UI_WHITE,
                UI_EDGE, UI_FONT_SMALL, 1);
        ui_text(c, ax - 6 - ui_text_w(right, UI_FONT_LARGE), my + 4 + ui_text_y(19, UI_FONT_LARGE),
                right, UI_LIGHT, UI_EDGE, UI_FONT_LARGE, 1);
        if (s.seq == 4 && s.input_enabled && (hp & EIDOS_UI_CLICK)) eidos_ui_tap(156, 180, 3);
        if (s.seq == 4 && s.input_enabled && (hn & EIDOS_UI_CLICK)) eidos_ui_tap(180, 180, 3);
        if (s.seq == 4 && s.input_enabled && s.page != 2 && eidos_ui_wheel((EidosUiRect){ mx, my, mw, mh }) != 0) {
            /* the wheel steps through the Pokemon */
            int wh = eidos_ui_wheel((EidosUiRect){ mx, my, mw, mh });

            if (wh > 0) eidos_ui_tap(156, 180, 3);
            else if (wh < 0) eidos_ui_tap(180, 180, 3);
        }
    }

    /* the tabs: the game's three pages, shown as it offers them */
    tabx = mx + 8;
    taby = my + 4 + 22 + 3;
    tabs_row = !(one_screen && !s.egg && !s.has_ribbon);
    if (s.mode != 2 && tabs_row) {
        static const char *const names_n[3] = { "INFO", "SKILLS", "RIBBONS" };
        static const char *const names_1[3] = { "SUMMARY", "SKILLS", "RIBBONS" };
        const char *const *names = one_screen && !s.egg ? names_1 : names_n;
        static const int tap_x[3] = { 20, 60, 100 };
        int t;

        for (t = 0; t < 3; t++) {
            int tw = ui_text_w(names[t], UI_FONT_SMALL) + 16;
            EidosUiRect r;
            int hit, avail = 1;

            if (t == 1 && s.egg) avail = 0;
            if (t == 1 && one_screen) avail = 0;        /* with INFO on one screen */
            if (t == 2 && (s.egg || !s.has_ribbon)) avail = 0;
            if (!avail) {
                continue;
            }
            r.x = tabx; r.y = taby; r.w = tw; r.h = 14;
            hit = eidos_ui_hit(r);
            ui_tab(c, tabx, taby, names[t], t == s.page || (one_screen && t == 0 && s.page == 1) || (hit & EIDOS_UI_HOVER),
                   t == s.page ? UI_SKY : UI_EDGE2, t == s.page ? UI_NAVY2 : UI_NAVY);
            if ((hit & EIDOS_UI_CLICK) && s.seq == 4 && s.input_enabled && t != s.page) {
                eidos_ui_tap(tap_x[t], 180, 3);
            }
            tabx += tw + 3;
        }
    }

    /* the content */
    cx = mx + 8;
    cy = my + 4 + 22 + 3 + (tabs_row ? 14 + 4 : 2);
    cw = mw - 16;
    ch = my + mh - 6 - cy;
    cardw = cw * 28 / 100;
    if (cardw < 100) cardw = 100;
    if (cardw > 130) cardw = 130;
    if (wide_frame) {
        cardw = cw * 30 / 100;
    }
    {
        int a = 0, b = 0, d = 0, e = 0;

        card_right = wide_frame && ui_app_window(c, "summary-side", &a, &b, &d, &e);
    }
    draw_card(c, &s, card_right ? cx + cw - cardw : cx, cy, cardw, ch, in);
    {
        int px = card_right ? cx : cx + cardw + 6, pw = cw - cardw - 6;

        if (one_screen && s.page <= 1 && !s.egg) {
            /* a theme's wide screen: the facts and the skills together */
            draw_one_screen(c, &s, px, cy, pw, ch, in);
        } else if (s.page == 0) {
            draw_info_page(c, &s, px, cy, pw, ch);
        } else if (s.page == 1) {
            draw_skills_page(c, &s, px, cy, pw, ch, in);
        } else if (s.page == 2) {
            draw_ribbon_page(c, &s, px, cy, pw, ch, in);
        } else {
            draw_forget_page(c, &s, px, cy, pw, ch, in);
        }
    }

    /* B: a right click, or a click outside the modal */
    if (eidos_ui_right_click() || click_outside(c, mx, my, mw, mh)) {
        back = 1;
    }
    if (back && s.seq == 4) {
        eidos_ui_tap(244, 180, 3);
    }
    if (tabs_row) {
        draw_hints(c, hints_n, keys_n, 3);
    } else {
        draw_hints(c, hints_n + 2, keys_n + 1, 2);      /* no pages to turn */
    }
}

static void summary_reset(void)
{
    g_prev_buttons = 0;
    g_ribbon_sel = 0;
    g_ribbon_scroll = 0;
    g_move_hover = -1;
    g_forget_next = -1;
    g_forget_steps = 0;
}

static const EidosUiRecipe recipe_summary = {
    "pokemon summary", summary_match, summary_run, summary_reset, 0
};

/* ------------------------------------------------------------------ */
/* The evolution scene (overlay 195, SHINKA_DEMO)                      */
/* ------------------------------------------------------------------ */

/* The game draws it on the top screen alone (the Pokemon on its glowing
 * stage, the message box under it): the window shows the scene across its
 * width, as a battle, with the message in the interface's box.  A click is
 * A (the messages go on), a right click B (the game's own: it stops the
 * evolution). */
static int evolution_match(void)
{
    return bw_overlay_is_loaded(EVO_OVERLAY);
}

/* recipe_battle.c: the battle's party list, opened by the evolution scene */
int eidos_ui_plist_outside(EidosUiCtx *c, EidosUiView *view, const EidosUiFrame *in, void *sys,
                           const void *host);

/* YesNoMenu (ov067): its step and the answer under the key cursor */
#define YN_STATE        0x98
#define YN_CURSOR       0xC0

/* The scene's question when the new form learns a move with four known
 * (state 22: "Should a move be deleted...?"): the game's two buttons on
 * the bottom screen (YESNO_MENU, yes over rows 0 to 87, no under them) as
 * two buttons over the message box.  The keys work as on the DS. */
static void evolution_yesno(EidosUiCtx *c, const void *sc, int box_x, int box_y, int box_w)
{
    const void *yn = rdp(sc, SC_YESNO);
    int i, bw = 150, bh = 18;
    char label[48];

    if (yn == NULL || rds32(yn, YN_STATE) != 2) {
        return;
    }
    for (i = 0; i < 2; i++) {
        EidosUiRect r;
        int st, sel;

        r.x = box_x + box_w - bw;
        r.y = box_y - 6 - (2 - i) * (bh + 4);
        r.w = bw;
        r.h = bh;
        (void)strbuf_text(rdp(sc, i == 0 ? SC_STRBUF_YES : SC_STRBUF_NO), label, (int)sizeof label, 0);
        st = eidos_ui_hit(r);
        sel = (st & EIDOS_UI_HOVER) != 0 || (eidos_ui_keys_lit() && rds32(yn, YN_CURSOR) == i);
        ui_cmd_button(c, r.x, r.y, r.w, r.h, label, i == 0 ? UI_PINK : UI_GREY, sel);
        if (st & EIDOS_UI_CLICK) {
            eidos_ui_tap(128, i == 0 ? 44 : 140, 3);
        }
    }
}

/* engine/platform/text_instant.c: the window the game printed into last */
struct BmpWin;
struct BmpWin *eidos_text_last_window(u32 *count) BW_WEAK;   /* not in builds without the game */
extern void *BMP_WIN_GetBmp(void *win) __attribute__((weak));
extern u8 BMP_WIN_GetBgLayer(void *win) __attribute__((weak));

/* A pixel of a 4-bit tiled message bitmap. */
static int evo_px(const u8 *px, int bw, int x, int y)
{
    u8 v = px[((y >> 3) * (bw >> 3) + (x >> 3)) * 32 + (y & 7) * 4 + ((x & 7) >> 1)];

    return (x & 1) != 0 ? v >> 4 : v & 15;
}

/* The game's message as the battle shows its own (recipe_battle.c,
 * draw_battle_message): the window the game printed a message into last,
 * its letters at the DS size in the interface's box.  The window is read as
 * the game draws it, so a message comes page by page and letter by letter
 * as on the DS.  Only while the game shows it (its BG on: DISPCNT bits 8 to
 * 11 of the screen the window is on; the text stays in the bitmap after the
 * box is hidden), and only a window printed into after `since`.  Returns
 * whether a message is on show. */
static int game_message(EidosUiCtx *c, u32 since, int x, int y, int w, int h)
{
    u32 count = 0;
    void *win = eidos_text_last_window != NULL ? eidos_text_last_window(&count) : NULL;
    const u8 *bmp, *px;
    int bw, bh, cnt[16] = { 0 }, ground = 0, ink = -1, xx, yy, i;

    if (win == NULL || count == since || BMP_WIN_GetBmp == NULL || BMP_WIN_GetBgLayer == NULL) {
        return 0;
    }
    /* The game may have deleted that window since it printed into it (after
     * an item is used the party screen deletes its message window and makes
     * another): the kept pointer then names freed memory, and reading it as
     * a window crashed (issue #33, a second Potion from the Bag).  A window
     * is the game's (BmpWin, arm9/bmp_win_types.h): in the game's memory,
     * tagged 0x7FB2, its bitmap at +0x0C and the bitmap's pixels in the
     * game's memory too, the bitmap as large as the window's tiles. */
    {
        const u8 *wp = (const u8 *)win, *bp, *pp;
        int tw, th;

        if (((uintptr_t)wp & 1u) != 0 || !bw_ds_game_ptr(wp) || !bw_ds_game_ptr(wp + 0x0F)
            || (rd16(wp, 0) & 0x7FFFu) != 0x7FB2u) {
            return 0;
        }
        bp = (const u8 *)rdp(wp, 0x0C);
        if (bp == NULL || ((uintptr_t)bp & 3u) != 0 || !bw_ds_game_ptr(bp) || !bw_ds_game_ptr(bp + 7)) {
            return 0;
        }
        pp = (const u8 *)rdp(bp, 0x00);
        tw = wp[5];
        th = wp[6];
        if (pp == NULL || tw <= 0 || th <= 0 || (int)rd16(bp, 0x04) != tw * 8 || (int)rd16(bp, 0x06) != th * 8
            || !bw_ds_game_ptr(pp) || !bw_ds_game_ptr(pp + (size_t)tw * (size_t)th * 32u - 1u)) {
            return 0;
        }
    }
    {
        u32 layer = BMP_WIN_GetBgLayer(win);
        u32 dispcnt = bw_io_read32(layer < 4u ? 0x04000000u : 0x04001000u);

        if ((dispcnt & (0x100u << (layer & 3u))) == 0) {
            return 0;
        }
    }
    bmp = (const u8 *)BMP_WIN_GetBmp(win);
    if (bmp == NULL || (px = rdp(bmp, 0x00)) == NULL) {
        return 0;
    }
    bw = (int)rd16(bmp, 0x04);
    bh = (int)rd16(bmp, 0x06);
    if (bw <= 0 || bh <= 0 || bw > 256 || bh > 64) {
        return 0;
    }
    for (yy = 0; yy < bh; yy++) {
        for (xx = 0; xx < bw; xx++) {
            cnt[evo_px(px, bw, xx, yy)]++;
        }
    }
    for (i = 1; i < 16; i++) {
        if (cnt[i] > cnt[ground]) {
            ground = i;
        }
    }
    /* the letters are colour 1 (the evolution prints with
     * GF_FONT_SetTextColor(1, 2, 15), and so do most windows); the most
     * used other colour when the window has no colour 1 */
    if (ground != 1 && cnt[1] > 0) {
        ink = 1;
    } else {
        for (i = 0; i < 16; i++) {
            if (i != ground && cnt[i] > 0 && (ink < 0 || cnt[i] > cnt[ink])) {
                ink = i;
            }
        }
    }
    if (ink < 0) {
        return 0;                       /* an empty window: no message */
    }
    {
        u32 ink_c = UI_WHITE, sh_c = UI_EDGE;

        if (ui_theme_active()->textbox != NULL) {
            /* a theme's own message box, the letters in its colours */
            u32 fill, edge;

            ui_theme_active()->textbox(c, UI_TEXTBOX_NARRATION | 16, x, y, w, h, &fill, &edge, &ink_c, &sh_c);
        } else {
            ui_panel(c, x, y, w, h, UI_CUT_TL | UI_CUT_BR, 6, UI_BODY, UI_EDGE, 225);
        }
        for (yy = 0; yy < bh && yy + 4 < h; yy++) {
            for (xx = 0; xx < bw && xx + 10 < w; xx++) {
                int v = evo_px(px, bw, xx, yy);

                if (v != ground) {
                    ui_fill(c, x + 10 + xx, y + (h - bh) / 2 + yy, 1, 1, v == ink ? ink_c : sh_c, 255);
                }
            }
        }
    }
    return 1;
}

static u32 g_evo_since;
static int g_evo_seen;

static void evolution_reset(void)
{
    g_evo_seen = 0;
}

static void evolution_run(EidosUiCtx *c, EidosUiView *view, const EidosUiFrame *in)
{
    EidosUiRect all;
    const void *sc = evo_scene();

    /* When the evolution teaches a move the game asks on the bottom screen:
     * FORGET or KEEP OLD MOVES (drawn here), then the moves, in the battle's
     * party list after a battle (its page, below) or in the summary after a
     * Rare Candy (the summary's recipe). */
    if (sc != NULL && rds32(sc, SC_STATE) == 28 &&
        eidos_ui_plist_outside(c, view, in, rdp(sc, SC_TCB), (const u8 *)sc + SC_PLISTHOST)) {
        view->hide_2d = 1;          /* the scene's message box under it */
        return;
    }
    /* the scene across the window, as a battle: the game's message box
     * (its 2D) is not shown, its message is in the interface's box, where
     * the battle has its own */
    view->mode = EIDOS_VIEW_WORLD;
    view->world_screen = 0;
    view->hide_2d = 1;
    view->spare_world = 1;      /* the party list after it shows the field */
    if (!g_evo_seen) {
        if (eidos_text_last_window != NULL) {
            (void)eidos_text_last_window(&g_evo_since);  /* printed before the scene: not its */
        }
        g_evo_seen = 1;
    }
    {
        int cw = c->canvas->w, ch = c->canvas->h, bw = cw * 2 / 3;
        static const char *const hints[] = { "A", "Next" };
        static const u32 keys[] = { BW_KEY_A };
        static const char *const hints_yn[] = { "A", "Choose", ARROWS, "Move" };
        static const u32 keys_yn[] = { BW_KEY_A, 0 };
        int state = sc != NULL ? rds32(sc, SC_STATE) : 0;

        /* not while the list opens and closes (states 27 to 30): the
         * question stays in the window, under the game's fade */
        if (state < 27 || state > 30) {
            (void)game_message(c, g_evo_since, (cw - bw) / 2, ch - FOOTER_H - 6 - 40, bw, 40);
        }
        if (state == 22) {
            evolution_yesno(c, sc, (cw - bw) / 2, ch - FOOTER_H - 6 - 40, bw);
            draw_hints(c, hints_yn, keys_yn, 2);
            return;
        }
        draw_hints(c, hints, keys, 1);
    }
    all.x = 0;
    all.y = 0;
    all.w = c->canvas->w;
    all.h = c->canvas->h;
    if (eidos_ui_hit(all) & EIDOS_UI_CLICK) {
        eidos_ui_press(BW_KEY_A, 2);
    } else if (eidos_ui_right_click()) {
        eidos_ui_press(BW_KEY_B, 2);
    }
}

static const EidosUiRecipe recipe_evolution = {
    "evolution", evolution_match, evolution_run, evolution_reset, 0
};

/* ------------------------------------------------------------------ */

const EidosUiRecipe *const ui_recipes_party[] = { &recipe_summary, &recipe_party_list, &recipe_evolution };
const u32 ui_recipes_party_count = 3;
