/*
 * engine/world/remade/building.c -- a building without a back.  The map's
 * houses have a front, two sides and a roof; the wall away from the field's
 * camera, and often the roof's far slope, are not in the model.
 *
 * A building's back is made, never copied from its front: the front has the
 * door.  What is made:
 *   1. The roof's far slope, where it is missing: a slope that looks south
 *      gets its twin on the other side of the ridge (a roof is alike on
 *      both sides of its ridge), unless a slope is there.
 *   2. The back wall: under every edge where the model ends at its north
 *      side (the roof's far eave, a gable's slope, a flat roof's rim) a
 *      wall goes down to the ground, where no wall stands.  It follows that
 *      edge in plan, so a round or an L-shaped house gets a back of its own
 *      shape, set in from the eave as far as the front wall is set in from
 *      the front eave, and it reaches up to the roof.
 *   The wall wears the building's own front, seen square on, without what
 *   belongs to the entrance: `erase` names those places for each building
 *   (a door, its posts, a sign), and each row there is plain wall from the
 *   front's own plain place `plain`.  Windows stay: a back has windows.
 *   Its inner side is dark, as a house is behind an open door.
 *
 * Settings: roof=0 (no roof twin), wall=0 (no back wall), shade (0.85: the
 * back wall's shade of the front's colours: it stands in the shade),
 * erase=X0:X1:Y0:Y1[:DX]+.. and plain=X (map units of the model's own space;
 * with DX a place takes the wall DX to its side: windows go on where a door was),
 * foot=Y (where the wall ends at the bottom: a house on posts), src=east
 * with span=Z0:Z1 (the picture is the east side's, that stretch of it laid
 * across the back: a tower's back is its side), lean=D (the wall's foot
 * stands D out, as the sides' feet do), flare=D (and D wider at each end),
 * twosided=1 (every upright wall from both sides: an open basin), small=0
 * (no closing of small pieces: chimneys, posts), sides=0 (no wall under an
 * eave that runs north-south: the model's own side walls stand set in under
 * the roof, a hut on posts), eaves=1 (each side wall carried up to the roof's
 * underside over it).
 */

#include <math.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include "remade.h"

typedef struct {
    double p[3][3], n[3];
    float uv[3][2];
    unsigned id;
    unsigned char rgb[3];
    const RmBatch *bt;
    int added;                  /* a twin made here, not the model's own */
} Tr;

typedef struct { int a[3], b[3]; int owner, count, third; } Edge;

static void tri_normal(Tr *t)
{
    double e1[3], e2[3];
    int k;

    for (k = 0; k < 3; k++) {
        e1[k] = t->p[1][k] - t->p[0][k];
        e2[k] = t->p[2][k] - t->p[0][k];
    }
    rm_cross(e1, e2, t->n);
    rm_norm(t->n);
}

/* Where the ray from o along d (a unit vector) meets the triangle: the distance, or -1. */
static double ray_hit(const Tr *t, const double o[3], const double d[3])
{
    double e1[3], e2[3], h[3], s[3], q[3], a, f, u, v, dist;
    int k;

    for (k = 0; k < 3; k++) {
        e1[k] = t->p[1][k] - t->p[0][k];
        e2[k] = t->p[2][k] - t->p[0][k];
        s[k] = o[k] - t->p[0][k];
    }
    rm_cross(d, e2, h);
    a = rm_dot(e1, h);
    if (fabs(a) < 1e-9) {
        return -1.0;
    }
    f = 1.0 / a;
    u = f * rm_dot(s, h);
    if (u < -1e-6 || u > 1.0 + 1e-6) {
        return -1.0;
    }
    rm_cross(s, e1, q);
    v = f * rm_dot(d, q);
    if (v < -1e-6 || u + v > 1.0 + 1e-6) {
        return -1.0;
    }
    dist = f * rm_dot(e2, q);
    return dist > 1e-6 ? dist : -1.0;
}

/* Does a triangle that looks the way of `n` cover the point c (lying in its plane, to a quarter unit)? */
static int covered(const Tr *tr, unsigned nt, const double c[3], const double n[3])
{
    unsigned j;
    int x;

    for (j = 0; j < nt; j++) {
        double f1[3], f2[3], d[3], den, w1, w2;

        if (rm_dot(n, tr[j].n) <= 0.9) {
            continue;
        }
        for (x = 0; x < 3; x++) {
            f1[x] = tr[j].p[1][x] - tr[j].p[0][x];
            f2[x] = tr[j].p[2][x] - tr[j].p[0][x];
            d[x] = c[x] - tr[j].p[0][x];
        }
        if (fabs(rm_dot(d, tr[j].n)) >= 0.6) {
            continue;
        }
        den = rm_dot(f1, f1) * rm_dot(f2, f2) - rm_dot(f1, f2) * rm_dot(f1, f2);
        if (fabs(den) <= 1e-9) {
            continue;
        }
        w1 = (rm_dot(d, f1) * rm_dot(f2, f2) - rm_dot(d, f2) * rm_dot(f1, f2)) / den;
        w2 = (rm_dot(d, f2) * rm_dot(f1, f1) - rm_dot(d, f1) * rm_dot(f1, f2)) / den;
        if (1.0 - w1 - w2 >= -0.02 && w1 >= -0.02 && w2 >= -0.02) {
            return 1;
        }
    }
    return 0;
}

/* A wall's pixel at the point (x, y, z) on triangle t: its texture's pixel there (by the corners' weights) in
 * the triangle's own colour, or the colour alone without a texture.  0 at a hole of a cut-out picture. */
static int wall_px(const Tr *t, const RmTex *tex, unsigned ntex, double x, double y, double z, unsigned char *out4)
{
    const RmTex *st = t->bt->tex >= 0 && (unsigned)t->bt->tex < ntex && tex[t->bt->tex].rgba != NULL ? &tex[t->bt->tex] : NULL;
    double f1[3], f2[3], dd[3], hp[3] = { x, y, z }, den, w1, w2, su, sv;
    const unsigned char *sp;
    int sx, sy, k;

    if (st == NULL) {
        if (out4 != NULL) {
            out4[0] = t->rgb[0]; out4[1] = t->rgb[1]; out4[2] = t->rgb[2]; out4[3] = 255;
        }
        return 1;
    }
    for (k = 0; k < 3; k++) {
        f1[k] = t->p[1][k] - t->p[0][k];
        f2[k] = t->p[2][k] - t->p[0][k];
        dd[k] = hp[k] - t->p[0][k];
    }
    den = rm_dot(f1, f1) * rm_dot(f2, f2) - rm_dot(f1, f2) * rm_dot(f1, f2);
    if (fabs(den) < 1e-12) {
        return 0;
    }
    w1 = (rm_dot(dd, f1) * rm_dot(f2, f2) - rm_dot(dd, f2) * rm_dot(f1, f2)) / den;
    w2 = (rm_dot(dd, f2) * rm_dot(f1, f1) - rm_dot(dd, f1) * rm_dot(f1, f2)) / den;
    su = t->uv[0][0] + w1 * ((double)t->uv[1][0] - t->uv[0][0]) + w2 * ((double)t->uv[2][0] - t->uv[0][0]);
    sv = t->uv[0][1] + w1 * ((double)t->uv[1][1] - t->uv[0][1]) + w2 * ((double)t->uv[2][1] - t->uv[0][1]);
    sx = (int)floor(su * st->w);
    sy = (int)floor(sv * st->h);
    sx = ((sx % st->w) + st->w) % st->w;
    sy = ((sy % st->h) + st->h) % st->h;
    sp = st->rgba + ((size_t)sy * st->w + (size_t)sx) * 4u;
    if (sp[3] < 128) {
        return 0;
    }
    if (out4 != NULL) {
        for (k = 0; k < 3; k++) {
            out4[k] = (unsigned char)((unsigned)sp[k] * t->rgb[k] / 255u);
        }
        out4[3] = 255;
    }
    return 1;
}

/* The nearest roof (a slope) along the ray from o along d, a unit vector, past a twentieth of a unit: the
 * distance, or -1.  Triangle `skip` is not looked at. */
static double roof_hit(const Tr *tr, unsigned n, unsigned skip, const double o[3], const double d[3], double far)
{
    double best = -1.0;
    unsigned i;

    for (i = 0; i < n; i++) {
        double hd;

        if (i == skip || !(tr[i].n[1] > 0.25 && tr[i].n[1] < 0.98)) {
            continue;
        }
        hd = ray_hit(&tr[i], o, d);
        if (hd > 0.05 && hd < far && (best < 0.0 || hd < best)) {
            best = hd;
        }
    }
    return best;
}

/*
 * `valley=1`: a roof board whose low back edge ends in the air over the roof (a dormer's little roof, seen from
 * behind: under it the dormer is open and dark) goes on down its own slope until it meets the roof under it, in
 * its own picture.  Along the edge, the part that is under the roof already stays where it is.
 */
static void valley(const Tr *tr, unsigned n, RmOut *out, const char *opt)
{
    enum { S = 24 };
    unsigned i, j, s, m;
    int k;

    if (rm_optf(opt, "valley", 0) == 0.0) {
        return;
    }
    for (i = 0; i < n; i++) {
        const Tr *t = &tr[i];

        if (t->added || !(t->n[1] > 0.25 && t->n[1] < 0.98)) {
            continue;
        }
        for (j = 0; j < 3u; j++) {
            const double *a = t->p[j], *b = t->p[(j + 1u) % 3u], *c = t->p[(j + 2u) % 3u];
            double e[3], w[3], g[3], cr[3], len, we, f1[3], f2[3], den, up[3] = { 0.0, 1.0, 0.0 };
            double pt[S + 1][3], pd[S + 1][3], ds[S + 1], uv[S + 1][2], uvd[S + 1][2];
            int shared = 0, any = 0, flip;

            if (c[1] < (a[1] > b[1] ? a[1] : b[1]) + 0.25) {
                continue;               /* (not the triangle's low edge) */
            }
            /* (an edge another triangle has too is no end of the board) */
            for (m = 0; m < n && !shared; m++) {
                unsigned u, hits = 0;

                for (u = 0; m != i && u < 3u; u++) {
                    double da = fabs(tr[m].p[u][0] - a[0]) + fabs(tr[m].p[u][1] - a[1]) + fabs(tr[m].p[u][2] - a[2]);
                    double db = fabs(tr[m].p[u][0] - b[0]) + fabs(tr[m].p[u][1] - b[1]) + fabs(tr[m].p[u][2] - b[2]);

                    hits += da < 0.1 || db < 0.1;
                }
                shared = hits >= 2u;
            }
            if (shared) {
                continue;
            }
            /* down the board: in its plane, square to the edge, away from its high corner */
            for (k = 0; k < 3; k++) {
                e[k] = b[k] - a[k];
                w[k] = c[k] - a[k];
            }
            len = rm_norm(e);
            if (len < 0.5) {
                continue;
            }
            we = rm_dot(w, e);
            for (k = 0; k < 3; k++) {
                g[k] = -(w[k] - we * e[k]);
            }
            rm_norm(g);
            if (g[1] > -0.1 || g[2] > -0.3) {
                continue;               /* (it must go down, and to the back) */
            }
            /* the board's picture at a place of its plane: by the corners' weights, carried on past its edge */
            for (k = 0; k < 3; k++) {
                f1[k] = t->p[1][k] - t->p[0][k];
                f2[k] = t->p[2][k] - t->p[0][k];
            }
            den = rm_dot(f1, f1) * rm_dot(f2, f2) - rm_dot(f1, f2) * rm_dot(f1, f2);
            if (fabs(den) < 1e-9) {
                continue;
            }
            for (s = 0; s <= (unsigned)S; s++) {
                double d0;

                for (k = 0; k < 3; k++) {
                    pt[s][k] = a[k] + (b[k] - a[k]) * s / S;
                }
                ds[s] = 0.0;
                if (roof_hit(tr, n, i, pt[s], up, 40.0) < 0.0) {        /* (under the roof: it stays) */
                    d0 = roof_hit(tr, n, i, pt[s], g, 20.0);
                    ds[s] = d0 > 0.0 ? d0 : 0.0;
                    any |= d0 > 0.0;
                }
            }
            if (!any) {
                continue;
            }
            /* each place's end down the board, and the picture at both */
            for (s = 0; s <= (unsigned)S; s++) {
                unsigned v;

                for (k = 0; k < 3; k++) {
                    pd[s][k] = pt[s][k] + g[k] * ds[s];
                }
                for (v = 0; v < 2u; v++) {
                    const double *q = v == 0 ? pt[s] : pd[s];
                    double dd[3], w1, w2, *o = v == 0 ? uv[s] : uvd[s];

                    for (k = 0; k < 3; k++) {
                        dd[k] = q[k] - t->p[0][k];
                    }
                    w1 = (rm_dot(dd, f1) * rm_dot(f2, f2) - rm_dot(dd, f2) * rm_dot(f1, f2)) / den;
                    w2 = (rm_dot(dd, f2) * rm_dot(f1, f1) - rm_dot(dd, f1) * rm_dot(f1, f2)) / den;
                    o[0] = (1.0 - w1 - w2) * t->uv[0][0] + w1 * t->uv[1][0] + w2 * t->uv[2][0];
                    o[1] = (1.0 - w1 - w2) * t->uv[0][1] + w1 * t->uv[1][1] + w2 * t->uv[2][1];
                }
            }
            /* (turned the way the board looks: the edge, then down it) */
            rm_cross(e, g, cr);
            flip = rm_dot(cr, t->n) < 0.0;
            /* the strip, piece by piece: the edge from one place to the next, and back along their ends down the
             * board (where a place stays, its end is the place itself: that piece is one triangle) */
            for (s = 1; s <= (unsigned)S; s++) {
                if (ds[s] > 0.0) {
                    if (flip) {
                        rm_tri(out, t->id, -1, 1, t->rgb, pt[s - 1], pd[s], pt[s], uv[s - 1], uvd[s], uv[s], 0, 0);
                    } else {
                        rm_tri(out, t->id, -1, 1, t->rgb, pt[s - 1], pt[s], pd[s], uv[s - 1], uv[s], uvd[s], 0, 0);
                    }
                }
                if (ds[s - 1] > 0.0) {
                    if (flip) {
                        rm_tri(out, t->id, -1, 1, t->rgb, pt[s - 1], pd[s - 1], pd[s], uv[s - 1], uvd[s - 1], uvd[s], 0, 0);
                    } else {
                        rm_tri(out, t->id, -1, 1, t->rgb, pt[s - 1], pd[s], pd[s - 1], uv[s - 1], uvd[s], uvd[s - 1], 0, 0);
                    }
                }
            }
        }
    }
}

/*
 * `rim=1`: the roof's back end gets the edge its front end has.  The roof is a slab: at its south end its
 * thickness is closed by upright faces (a blue band under the slope's edge, a trim board); at its north end the
 * model has nothing.  Those faces, the model's own that look south and stand at the slopes' south end, are
 * carried to the slopes' north end, looking north: the roof's edge stands out over the back wall as it does
 * over the front.
 */
static void rim(const Tr *tr, unsigned n, RmOut *out, const char *opt)
{
    double zs = -1e30, zn = 1e30, yeave = 1e30;
    /* (`rimdrop=D`: how far under the eaves the roof's end may hang, 2: a band under the roof's edge, more) */
    const double rimdrop = rm_optf(opt, "rimdrop", 2.0);
    /* (`rimout=D`: the copy stands D further out: a frame in the wall's own plane, in front of it, not in it) */
    const double rimout = rm_optf(opt, "rimout", 0.0);
    unsigned i, j;

    if (rm_optf(opt, "rim", 0) == 0.0) {
        return;
    }
    for (i = 0; i < n; i++) {
        if (!tr[i].added && tr[i].n[1] > 0.25 && tr[i].n[1] < 0.98) {
            for (j = 0; j < 3u; j++) {
                zs = tr[i].p[j][2] > zs ? tr[i].p[j][2] : zs;
                zn = tr[i].p[j][2] < zn ? tr[i].p[j][2] : zn;
            }
        }
    }
    /* (`rimat=Z`: the roof end at Z is the one copied, to the far end of the slopes that reach Z: a building of
     * several roofs, or a little roof over the door further out than the main roof's end) */
    if (rm_optf(opt, "rimat", 1e30) < 1e29) {
        unsigned m;

        zs = rm_optf(opt, "rimat", 0);
        zn = 1e30;
        /* (the slopes that reach Z, and every slope in the same plane as one of them: a roof cut in pieces along
         * its length is one roof; its far end is the far end of its planes) */
        for (i = 0; i < n; i++) {
            int reach = 0;

            if (tr[i].added || !(tr[i].n[1] > 0.25 && tr[i].n[1] < 0.98)) {
                continue;
            }
            for (j = 0; j < 3u; j++) {
                reach |= fabs(tr[i].p[j][2] - zs) < 0.3;
            }
            for (m = 0; reach && m < n; m++) {
                double d[3];

                if (tr[m].added || rm_dot(tr[m].n, tr[i].n) < 0.999) {
                    continue;
                }
                for (j = 0; j < 3u; j++) {
                    d[j] = tr[m].p[0][j] - tr[i].p[0][j];
                }
                if (fabs(rm_dot(d, tr[i].n)) > 0.3) {
                    continue;           /* (parallel, but another roof) */
                }
                for (j = 0; j < 3u; j++) {
                    zn = tr[m].p[j][2] < zn ? tr[m].p[j][2] : zn;
                }
            }
        }
    }
    if (zs - zn < 1.0) {
        return;
    }
    /* (the eaves: the lowest corner of the slopes that reach the roof's end, their tops and their undersides; only
     * slopes of the roof itself, whose plane runs on to its far end: a little sloped hood or sill at the front is
     * no roof, and with it the corner pillars under the eaves were copied too) */
    for (i = 0; i < n; i++) {
        int reach = 0, roof = 0;
        unsigned m;

        if (tr[i].added || !(fabs(tr[i].n[1]) > 0.25 && fabs(tr[i].n[1]) < 0.98)) {
            continue;
        }
        for (j = 0; j < 3u; j++) {
            reach |= fabs(tr[i].p[j][2] - zs) < 0.3;
        }
        for (m = 0; reach && !roof && m < n; m++) {
            double d[3];

            if (tr[m].added || rm_dot(tr[m].n, tr[i].n) < 0.999) {
                continue;
            }
            for (j = 0; j < 3u; j++) {
                d[j] = tr[m].p[0][j] - tr[i].p[0][j];
            }
            if (fabs(rm_dot(d, tr[i].n)) > 0.3) {
                continue;
            }
            for (j = 0; j < 3u; j++) {
                roof |= tr[m].p[j][2] < zn + 0.3;
            }
        }
        for (j = 0; reach && roof && j < 3u; j++) {
            yeave = tr[i].p[j][1] < yeave ? tr[i].p[j][1] : yeave;
        }
    }
    for (i = 0; i < n; i++) {
        const Tr *t = &tr[i];
        double p[3][3];
        double uv[3][2];
        int at_end = 1;

        if (t->added || t->n[2] < 0.9) {
            continue;
        }
        for (j = 0; j < 3u; j++) {
            at_end &= fabs(t->p[j][2] - zs) < 0.3 && t->p[j][1] > yeave - rimdrop;
        }
        if (!at_end) {
            continue;           /* (not at the roof's end; or under its eaves: a door's frame, no roof's edge) */
        }
        /* (mirrored along the roof: corners the other way round, so it looks north) */
        for (j = 0; j < 3u; j++) {
            unsigned s = j == 0 ? 0u : 3u - j;

            p[j][0] = t->p[s][0];
            p[j][1] = t->p[s][1];
            p[j][2] = zn + (zs - t->p[s][2]) - rimout;
            uv[j][0] = t->uv[s][0];
            uv[j][1] = t->uv[s][1];
        }
        rm_tri(out, t->id, -1, 1, t->rgb, p[0], p[1], p[2], uv[0], uv[1], uv[2], 0, 0);
    }
}

/*
 * `door=X:Z0:Z1:Y0:Y1:U0:V0:U1:V1`: an opening that is only a black hole (a doorway at the top of a stair, open on
 * nothing) gets a door: the model's faces in the upright plane x = X, between Z0 and Z1 and Y0 and Y1, give way
 * to two door leaves side by side, the second mirrored, cut from the place U0..U1, V0..V1 of the same texture
 * (the building's own door, from its front).
 */
static void door(const Tr *tr, unsigned n, RmOut *out, const char *opt)
{
    char db[128];
    double d[9];
    unsigned i, j, src = 0;
    int found = 0;
    unsigned char rgb[3] = { 255, 255, 255 };

    if (rm_opt(opt, "door", db, sizeof db) == NULL
        || sscanf(db, "%lf:%lf:%lf:%lf:%lf:%lf:%lf:%lf:%lf", &d[0], &d[1], &d[2], &d[3], &d[4], &d[5], &d[6], &d[7], &d[8]) != 9) {
        return;
    }
    for (i = 0; i < n; i++) {
        int in = fabs(tr[i].n[0]) > 0.9;

        for (j = 0; j < 3u && in; j++) {
            in = fabs(tr[i].p[j][0] - d[0]) < 0.3 && tr[i].p[j][2] > d[1] - 0.3 && tr[i].p[j][2] < d[2] + 0.3
                 && tr[i].p[j][1] > d[3] - 0.3 && tr[i].p[j][1] < d[4] + 0.3;
        }
        if (in) {
            rm_drop(out, tr[i].id);
            if (!found) {
                src = tr[i].id;
                memcpy(rgb, tr[i].rgb, 3u);
                found = 1;
            }
        }
    }
    if (!found) {
        return;
    }
    {
        const double zm = (d[1] + d[2]) / 2.0;
        int leaf;

        for (leaf = 0; leaf < 2; leaf++) {
            const double za = leaf == 0 ? d[1] : zm, zb = leaf == 0 ? zm : d[2];
            const double ua = leaf == 0 ? d[5] : d[7], ub = leaf == 0 ? d[7] : d[5];
            double p0[3] = { d[0], d[3], za }, p1[3] = { d[0], d[3], zb }, p2[3] = { d[0], d[4], zb }, p3[3] = { d[0], d[4], za };
            double t0[2] = { ua, d[8] }, t1[2] = { ub, d[8] }, t2[2] = { ub, d[6] }, t3[2] = { ua, d[6] };

            /* (both ways round: the door looks out of the wall, and from inside it is the door's back) */
            rm_tri(out, src, -1, 0, rgb, p0, p1, p2, t0, t1, t2, 0, 0);
            rm_tri(out, src, -1, 0, rgb, p0, p2, p3, t0, t2, t3, 0, 0);
        }
    }
}

/*
 * `twin=Y0:Y1`: a band round the building between those heights (a ledge halfway up, a slab with a top, two ends
 * and a front) has no back end: the camera never saw it.  Each of its faces that looks south gets its twin at the
 * band's north end, looking north, in the same picture: from behind it is the ledge the sides show, not a line.
 */
static void twin_band(const Tr *tr, unsigned n, RmOut *out, const char *opt)
{
    char tb[48];
    double y0b, y1b, zb = 1e30;
    unsigned i, j;

    if (rm_opt(opt, "twin", tb, sizeof tb) == NULL || sscanf(tb, "%lf:%lf", &y0b, &y1b) != 2) {
        return;
    }
    /* (the band's north end: the northmost corner of its faces) */
    for (i = 0; i < n; i++) {
        int in = !tr[i].added;

        for (j = 0; j < 3u && in; j++) {
            in = tr[i].p[j][1] > y0b - 0.1 && tr[i].p[j][1] < y1b + 0.1;
        }
        for (j = 0; in && j < 3u; j++) {
            zb = tr[i].p[j][2] < zb ? tr[i].p[j][2] : zb;
        }
    }
    if (zb > 1e29) {
        return;
    }
    for (i = 0; i < n; i++) {
        double p[3][3], uv[3][2];
        int in = !tr[i].added && tr[i].n[2] > 0.9;

        for (j = 0; j < 3u && in; j++) {
            in = tr[i].p[j][1] > y0b - 0.1 && tr[i].p[j][1] < y1b + 0.1;
        }
        if (!in) {
            continue;
        }
        for (j = 0; j < 3u; j++) {
            const unsigned s = j == 0 ? 0u : 3u - j;      /* (corners the other way round: it looks north) */

            p[j][0] = tr[i].p[s][0];
            p[j][1] = tr[i].p[s][1];
            p[j][2] = zb;
            uv[j][0] = tr[i].uv[s][0];
            uv[j][1] = tr[i].uv[s][1];
        }
        rm_tri(out, tr[i].id, -1, 1, tr[i].rgb, p[0], p[1], p[2], uv[0], uv[1], uv[2], 0, 0);
    }
}

static int dbl_cmp(const void *a, const void *b)
{
    double x = *(const double *)a, y = *(const double *)b;

    return x < y ? -1 : x > y;
}

void rm_building(const RmBatch *b, unsigned nb, const RmTex *tex, unsigned ntex, const char *opt, RmOut *out)
{
    const double shade = rm_optf(opt, "shade", 0.85);
    const int do_roof = rm_optf(opt, "roof", 1) != 0.0, do_wall = rm_optf(opt, "wall", 1) != 0.0, do_small = rm_optf(opt, "small", 1) != 0.0;
    unsigned bi, i, j, n = 0, n0, ne = 0, nq = 0;
    Tr *tr;
    Edge *ed = NULL;
    double lo[3] = { 1e30, 1e30, 1e30 }, hi[3] = { -1e30, -1e30, -1e30 }, y0, over = 0.0, wx0 = 1e30, wx1 = -1e30, wzn = 1e30, wzs = -1e30;
    double (*quad)[4][3] = NULL;
    double ret[16][4];                  /* `inset`'s return walls: x, from z, to z, height */
    unsigned nret = 0;
    int fitted = 0;
    unsigned char *qside = NULL;
    double *minz = NULL;
    int k, nbin;

    for (bi = 0; bi < nb; bi++) {
        n += b[bi].bb ? 0u : b[bi].n;
    }
    if (n == 0) {
        return;
    }
    tr = (Tr *)calloc((size_t)n * 3u, sizeof *tr);
    if (tr == NULL) {
        out->fail = 1;
        return;
    }
    for (bi = 0, n = 0; bi < nb; bi++) {
        for (i = 0; !b[bi].bb && i < b[bi].n; i++) {
            const RmTri *t = &b[bi].tri[i];

            for (j = 0; j < 3; j++) {
                for (k = 0; k < 3; k++) {
                    tr[n].p[j][k] = t->p[j][k];
                    lo[k] = t->p[j][k] < lo[k] ? t->p[j][k] : lo[k];
                    hi[k] = t->p[j][k] > hi[k] ? t->p[j][k] : hi[k];
                }
            }
            memcpy(tr[n].uv, t->uv, sizeof tr[n].uv);
            tr[n].id = t->id;
            memcpy(tr[n].rgb, t->rgb, 3u);
            tr[n].bt = &b[bi];
            tri_normal(&tr[n]);
            n++;
        }
    }
    n0 = n;
    y0 = lo[1];
    /* a flat board that stands or leans by itself (a lid against a kiln, a sign): shown from both sides */
    {
        int *par = (int *)malloc((size_t)n0 * sizeof *par);

        for (i = 0; par != NULL && i < n0; i++) {
            par[i] = (int)i;
        }
        for (i = 0; par != NULL && i < n0; i++) {
            for (j = 0; j < i; j++) {
                int share = 0, p1, p2, ra, rb;

                for (p1 = 0; p1 < 3 && !share; p1++) {
                    for (p2 = 0; p2 < 3 && !share; p2++) {
                        share = fabs(tr[i].p[p1][0] - tr[j].p[p2][0]) < 0.3 && fabs(tr[i].p[p1][1] - tr[j].p[p2][1]) < 0.3
                                && fabs(tr[i].p[p1][2] - tr[j].p[p2][2]) < 0.3;
                    }
                }
                if (!share) {
                    continue;
                }
                for (ra = (int)i; par[ra] != ra; ra = par[ra]) {
                }
                for (rb = (int)j; par[rb] != rb; rb = par[rb]) {
                }
                par[ra] = rb;
            }
        }
        for (i = 0; par != NULL && i < n0; i++) {
            int root, flat = 1, cnt = 0;

            for (root = (int)i; par[root] != root; root = par[root]) {
            }
            if (root != (int)i) {
                continue;
            }
            for (j = 0; j < n0; j++) {
                int r2;

                for (r2 = (int)j; par[r2] != r2; r2 = par[r2]) {
                }
                if (r2 == root) {
                    cnt++;
                    flat = flat && fabs(rm_dot(tr[j].n, tr[i].n)) > 0.98;
                }
            }
            if (!flat) {
                /* a small piece (a chimney, a post) is closed: a side that looks south gets its twin that looks
                 * north on the piece's other end, in the same pixel and colour, unless something is there */
                double plo[3] = { 1e30, 1e30, 1e30 }, phi[3] = { -1e30, -1e30, -1e30 };

                for (j = 0; j < n0; j++) {
                    int r2, q3;

                    for (r2 = (int)j; par[r2] != r2; r2 = par[r2]) {
                    }
                    for (q3 = 0; r2 == root && q3 < 3; q3++) {
                        for (k = 0; k < 3; k++) {
                            plo[k] = tr[j].p[q3][k] < plo[k] ? tr[j].p[q3][k] : plo[k];
                            phi[k] = tr[j].p[q3][k] > phi[k] ? tr[j].p[q3][k] : phi[k];
                        }
                    }
                }
                if (phi[0] - plo[0] <= 20.0 && phi[2] - plo[2] <= 20.0 && do_small) {
                    for (j = 0; j < n0; j++) {
                        Tr q = tr[j];
                        double c3[3] = { 0, 0, 0 }, t0[2], t1[2], t2[2];
                        int r2, q3;

                        for (r2 = (int)j; par[r2] != r2; r2 = par[r2]) {
                        }
                        if (r2 != root || tr[j].n[2] < 0.7) {
                            continue;
                        }
                        for (q3 = 0; q3 < 3; q3++) {
                            int sidx = q3 == 0 ? 0 : 3 - q3;

                            q.p[q3][0] = tr[j].p[sidx][0];
                            q.p[q3][1] = tr[j].p[sidx][1];
                            q.p[q3][2] = plo[2] + phi[2] - tr[j].p[sidx][2];
                            q.uv[q3][0] = tr[j].uv[sidx][0];
                            q.uv[q3][1] = tr[j].uv[sidx][1];
                            for (k = 0; k < 3; k++) {
                                c3[k] += q.p[q3][k] / 3.0;
                            }
                        }
                        tri_normal(&q);
                        if (covered(tr, n, c3, q.n)) {
                            continue;
                        }
                        t0[0] = q.uv[0][0]; t0[1] = q.uv[0][1];
                        t1[0] = q.uv[1][0]; t1[1] = q.uv[1][1];
                        t2[0] = q.uv[2][0]; t2[1] = q.uv[2][1];
                        {
                            unsigned char rgb2[3] = { (unsigned char)(q.rgb[0] * 0.8), (unsigned char)(q.rgb[1] * 0.8), (unsigned char)(q.rgb[2] * 0.8) };

                            rm_tri(out, q.id, -1, 1, rgb2, q.p[0], q.p[1], q.p[2], t0, t1, t2, 0, 0);
                        }
                        q.added = 1;
                        tr[n++] = q;
                    }
                }
            }
            if (flat && cnt <= 8 && fabs(tr[i].n[1]) < 0.9) {
                for (j = 0; j < n0; j++) {
                    int r2;

                    for (r2 = (int)j; par[r2] != r2; r2 = par[r2]) {
                    }
                    if (r2 == root) {
                        rm_two(out, tr[j].id);
                    }
                }
            }
        }
        free(par);
    }
    /* `twosided=1`: every upright wall is shown from both sides (an open basin, whose walls one looks at from inside) */
    if (rm_optf(opt, "twosided", 0) != 0.0) {
        for (i = 0; i < n0; i++) {
            if (fabs(tr[i].n[1]) < 0.3) {
                rm_two(out, tr[i].id);
            }
        }
    }
    /* 1. the roof's far slope: the twin of each slope that looks south, on the other side of the ridge */
    if (do_roof) {
        double ytop = -1e30, zr = 0.0;
        unsigned cnt = 0;

        for (i = 0; i < n0; i++) {
            if (tr[i].n[1] > 0.25 && tr[i].n[1] < 0.98) {
                for (j = 0; j < 3; j++) {
                    ytop = tr[i].p[j][1] > ytop ? tr[i].p[j][1] : ytop;
                }
            }
        }
        for (i = 0; i < n0; i++) {
            if (tr[i].n[1] > 0.25 && tr[i].n[1] < 0.98) {
                for (j = 0; j < 3; j++) {
                    if (tr[i].p[j][1] >= ytop - 0.25) {
                        zr += tr[i].p[j][2];
                        cnt++;
                    }
                }
            }
        }
        zr = cnt ? zr / cnt : 0.0;
        for (i = 0; cnt && i < n0; i++) {
            Tr q = tr[i];
            char sb0[16];
            double c[3] = { 0, 0, 0 };
            double low = tr[i].p[0][1] < tr[i].p[1][1] ? tr[i].p[0][1] : tr[i].p[1][1];

            low = tr[i].p[2][1] < low ? tr[i].p[2][1] : low;
            if (!(tr[i].n[1] > 0.25 && tr[i].n[1] < 0.98 && tr[i].n[2] > 0.3)
                || low < rm_optf(opt, "rooflow", y0 + 0.45 * (hi[1] - y0))) {
                continue;               /* (not a slope that looks south, or low on the house: a window's sill) */
            }
            /* (`rooflow=Y`: slopes from that height up, so an awning over the ground floor goes round the back
             * too; a white slope is an arch or a sign, no roof) */
            if (tr[i].rgb[0] > 190 && tr[i].rgb[1] > 190 && tr[i].rgb[2] > 170 && rm_opt(opt, "rooflow", sb0, sizeof sb0) != NULL) {
                continue;
            }
            for (j = 0; j < 3; j++) {       /* mirrored through the ridge, corners the other way round */
                unsigned s = j == 0 ? 0u : 3u - j;

                q.p[j][0] = tr[i].p[s][0];
                q.p[j][1] = tr[i].p[s][1];
                q.p[j][2] = 2.0 * zr - tr[i].p[s][2];
                q.uv[j][0] = tr[i].uv[s][0];
                q.uv[j][1] = tr[i].uv[s][1];
            }
            tri_normal(&q);
            for (j = 0; j < 3; j++) {
                for (k = 0; k < 3; k++) {
                    c[k] += q.p[j][k] / 3.0;
                }
            }
            if (c[2] < lo[2] - 1.0 || c[2] > zr || covered(tr, n, c, q.n)) {
                continue;               /* beyond the building, on the same side, or a slope is there */
            }
            {
                double t0[2] = { q.uv[0][0], q.uv[0][1] }, t1[2] = { q.uv[1][0], q.uv[1][1] }, t2[2] = { q.uv[2][0], q.uv[2][1] };

                rm_tri(out, q.id, -1, 1, q.rgb, q.p[0], q.p[1], q.p[2], t0, t1, t2, 0, 0);
            }
            q.added = 1;
            tr[n++] = q;
        }
    }
    door(tr, n0, out, opt);
    twin_band(tr, n0, out, opt);
    valley(tr, n, out, opt);
    rim(tr, n, out, opt);
    if (!do_wall) {
        goto done;
    }
    /* 2. the edges where the model ends: an edge of one triangle only */
    ed = (Edge *)calloc((size_t)n * 3u, sizeof *ed);
    nbin = (int)(hi[0] - lo[0]) + 3;
    minz = (double *)malloc((size_t)nbin * sizeof *minz);
    quad = (double (*)[4][3])malloc((size_t)n * 3u * sizeof *quad);
    qside = (unsigned char *)calloc((size_t)n * 3u, 1);
    if (ed == NULL || minz == NULL || quad == NULL || qside == NULL) {
        out->fail = 1;
        goto done;
    }
    for (i = 0; i < n; i++) {
        for (j = 0; j < 3; j++) {
            int qa[3], qb[3], sw = 0;
            unsigned e;

            for (k = 0; k < 3; k++) {
                qa[k] = (int)lround(tr[i].p[j][k] * 4.0);
                qb[k] = (int)lround(tr[i].p[(j + 1u) % 3u][k] * 4.0);
            }
            for (k = 0; k < 3 && !sw; k++) {
                if (qa[k] != qb[k]) {
                    sw = qa[k] > qb[k] ? 1 : -1;
                }
            }
            if (sw == 0) {
                continue;
            }
            if (sw > 0) {
                int t3[3];

                memcpy(t3, qa, sizeof t3); memcpy(qa, qb, sizeof qa); memcpy(qb, t3, sizeof qb);
            }
            for (e = 0; e < ne; e++) {
                if (memcmp(ed[e].a, qa, sizeof qa) == 0 && memcmp(ed[e].b, qb, sizeof qb) == 0) {
                    break;
                }
            }
            if (e == ne) {
                memcpy(ed[ne].a, qa, sizeof qa);
                memcpy(ed[ne].b, qb, sizeof qb);
                ed[ne].owner = (int)i;
                ed[ne].third = (int)((j + 2u) % 3u);
                ne++;
            }
            ed[e].count++;
        }
    }
    /* how far the front wall is set in from the front eave */
    {
        double *smp = (double *)malloc((size_t)ne * sizeof *smp + 8u);
        unsigned ns = 0, e;

        for (e = 0; smp != NULL && e < ne; e++) {
            const Tr *t = &tr[ed[e].owner];
            double a[3], bb2[3], c[3], ex, ez, len, ox, oz, o[3], d[3], best = -1.0;

            if (ed[e].count != 1) {
                continue;
            }
            for (k = 0; k < 3; k++) {
                a[k] = ed[e].a[k] / 4.0; bb2[k] = ed[e].b[k] / 4.0; c[k] = t->p[ed[e].third][k];
            }
            ex = bb2[0] - a[0]; ez = bb2[2] - a[2];
            len = sqrt(ex * ex + ez * ez);
            if (len < 0.5 || fabs(bb2[1] - a[1]) > 1.2 * len || (a[1] + bb2[1]) / 2.0 - y0 < 4.0) {
                continue;
            }
            ox = -ez / len; oz = ex / len;
            if (fabs(t->n[1]) < 0.3) {
                if (c[1] < (a[1] + bb2[1]) / 2.0 + 0.25) {
                    continue;           /* (the top of a wall: see below) */
                }
                if (ox * t->n[0] + oz * t->n[2] < 0.0) {
                    ox = -ox; oz = -oz;
                }
            } else if (ox * (c[0] - a[0]) + oz * (c[2] - a[2]) > 0.0) {
                ox = -ox; oz = -oz;
            }
            if (oz < 0.7) {
                continue;               /* (the front's edges only) */
            }
            o[0] = (a[0] + bb2[0]) / 2.0 + ox * 3.0; o[1] = (y0 + (a[1] + bb2[1]) / 2.0) / 2.0; o[2] = (a[2] + bb2[2]) / 2.0 + oz * 3.0;
            d[0] = -ox; d[1] = 0.0; d[2] = -oz;
            for (i = 0; i < n0; i++) {
                double hd = tr[i].n[0] * ox + tr[i].n[2] * oz > 0.3 ? ray_hit(&tr[i], o, d) : -1.0;

                if (hd > 0.0 && (best < 0.0 || hd < best)) {
                    best = hd;
                }
            }
            if (best >= 2.5 && best <= 11.0) {
                smp[ns++] = best - 3.0;
            }
        }
        if (ns > 0) {
            qsort(smp, ns, sizeof *smp, dbl_cmp);
            over = smp[ns / 2u];
            over = over < 0.0 ? 0.0 : over;
        }
        free(smp);
    }
    /* (`over=D`: the back wall stands D in from the roof's back edge; 0: flush with it, a gable closed at the
     * roof's end, so nobody looks up under the roof from behind) */
    over = rm_optf(opt, "over", over);
    /* the edges at the north side, high over the ground, with no wall under them: the northmost at each place */
    for (k = 0; k < nbin; k++) {
        minz[k] = 1e30;
    }
    /* where the side walls stand: the big upright triangles that look east and west */
    for (i = 0; i < n0; i++) {
        double e1[3], e2[3], c3[3];

        if (fabs(tr[i].n[0]) < 0.7 || fabs(tr[i].n[1]) > 0.3) {
            continue;
        }
        for (k = 0; k < 3; k++) {
            e1[k] = tr[i].p[1][k] - tr[i].p[0][k];
            e2[k] = tr[i].p[2][k] - tr[i].p[0][k];
        }
        rm_cross(e1, e2, c3);
        if (sqrt(rm_dot(c3, c3)) < 0.02 * (hi[1] - y0) * (hi[2] - lo[2])) {
            continue;                   /* (a small one: a chimney's side, a post's) */
        }
        /* (`groundwalls=1`: a side wall stands on the ground: a board under the eaves further out is the roof's) */
        if (rm_optf(opt, "groundwalls", 0) != 0.0
            && !(tr[i].p[0][1] < y0 + 3.0 || tr[i].p[1][1] < y0 + 3.0 || tr[i].p[2][1] < y0 + 3.0)) {
            continue;
        }
        for (j = 0; j < 3u; j++) {
            wzs = tr[i].p[j][2] > wzs ? tr[i].p[j][2] : wzs;
        }
        for (j = 0; j < 3u; j++) {
            wx0 = tr[i].p[j][0] < wx0 ? tr[i].p[j][0] : wx0;
            wx1 = tr[i].p[j][0] > wx1 ? tr[i].p[j][0] : wx1;
            wzn = tr[i].p[j][2] < wzn ? tr[i].p[j][2] : wzn;
        }
    }
    /* `pipes=W:YTOP:U:V`: a drainpipe at each corner of the walls, W square, from the ground up to YTOP, in the
     * pixel U, V of the walls' own texture (the grey the model paints as a flat stripe on each wall at the corner):
     * a pipe has sides; its sides shaded by the way they look */
    {
        char pb2[64];
        double pw, ptop, pu, pv;

        if (wx1 > wx0 && wzs > wzn && rm_opt(opt, "pipes", pb2, sizeof pb2) != NULL
            && sscanf(pb2, "%lf:%lf:%lf:%lf", &pw, &ptop, &pu, &pv) == 4) {
            unsigned src = 0;
            unsigned char rgb[3] = { 255, 255, 255 };
            int c4, f;

            /* (the material: a side wall's, the texture the stripe is in) */
            for (i = 0; i < n0; i++) {
                if (fabs(tr[i].n[0]) > 0.9 && (tr[i].p[0][1] < y0 + 3.0 || tr[i].p[1][1] < y0 + 3.0)) {
                    src = tr[i].id;
                    memcpy(rgb, tr[i].rgb, 3u);
                    break;
                }
            }
            for (c4 = 0; c4 < 4; c4++) {
                const double cx2 = c4 & 1 ? wx1 : wx0, cz2 = c4 & 2 ? wzs : wzn, h = pw / 2.0;
                const double uvp[2] = { pu, pv };

                for (f = 0; f < 4; f++) {
                    /* the four sides: east, west, south, north */
                    static const double sh4[4] = { 0.86, 0.86, 1.0, 0.72 };
                    double q[4][3], e1[3], e2[3], cr[3], nn[3] = { 0, 0, 0 };
                    unsigned char col[3];

                    if (f < 2) {
                        const double x2 = cx2 + (f == 0 ? h : -h);

                        nn[0] = f == 0 ? 1 : -1;
                        q[0][0] = q[1][0] = q[2][0] = q[3][0] = x2;
                        q[0][2] = q[3][2] = cz2 - h; q[1][2] = q[2][2] = cz2 + h;
                    } else {
                        const double z2 = cz2 + (f == 2 ? h : -h);

                        nn[2] = f == 2 ? 1 : -1;
                        q[0][2] = q[1][2] = q[2][2] = q[3][2] = z2;
                        q[0][0] = q[3][0] = cx2 - h; q[1][0] = q[2][0] = cx2 + h;
                    }
                    q[0][1] = q[1][1] = y0;
                    q[2][1] = q[3][1] = ptop;
                    for (k = 0; k < 3; k++) {
                        e1[k] = q[1][k] - q[0][k];
                        e2[k] = q[2][k] - q[0][k];
                        col[k] = (unsigned char)(rgb[k] * sh4[f]);
                    }
                    rm_cross(e1, e2, cr);
                    if (rm_dot(cr, nn) >= 0.0) {
                        rm_tri(out, src, -1, 1, col, q[0], q[1], q[2], uvp, uvp, uvp, 0, 0);
                        rm_tri(out, src, -1, 1, col, q[0], q[2], q[3], uvp, uvp, uvp, 0, 0);
                    } else {
                        rm_tri(out, src, -1, 1, col, q[0], q[2], q[1], uvp, uvp, uvp, 0, 0);
                        rm_tri(out, src, -1, 1, col, q[0], q[3], q[2], uvp, uvp, uvp, 0, 0);
                    }
                }
            }
        }
    }
    {
        unsigned e, pass;
        double tw0 = 1e30, tw1 = -1e30;
        char twb[48];

        /* (`twin`'s band, a ledge round the building: its edges are its own, no roof's edge with a wall under it) */
        if (rm_opt(opt, "twin", twb, sizeof twb) != NULL) {
            sscanf(twb, "%lf:%lf", &tw0, &tw1);
        }
        for (pass = 0; pass < 2u; pass++) {
            for (e = 0; e < ne; e++) {
                const Tr *t = &tr[ed[e].owner];
                double a[3], bb2[3], c[3], ex, ez, len, ox, oz, o[3], d[3], mid[3];
                int wall = 0, side;

                if (ed[e].count != 1) {
                    continue;
                }
                for (k = 0; k < 3; k++) {
                    a[k] = ed[e].a[k] / 4.0; bb2[k] = ed[e].b[k] / 4.0; c[k] = t->p[ed[e].third][k];
                    mid[k] = (a[k] + bb2[k]) / 2.0;
                }
                ex = bb2[0] - a[0]; ez = bb2[2] - a[2];
                len = sqrt(ex * ex + ez * ez);
                /* (`flush=1` or `rim=1`: a steep roof's edge too: a gable's steep side is no less a gable) */
                if (len < 0.5
                    || fabs(bb2[1] - a[1]) > (rm_optf(opt, "flush", 0) != 0.0 || rm_optf(opt, "rim", 0) != 0.0 ? 4.0 : 1.2) * len
                    || mid[1] - y0 < 4.0 || (mid[1] > tw0 - 0.1 && mid[1] < tw1 + 0.1)) {
                    continue;           /* (short, steep, at the ground, or the ledge's) */
                }
                ox = -ez / len; oz = ex / len;
                if (fabs(t->n[1]) < 0.3) {
                    /* an upright triangle: only its lower edge (an eave's board; a wall's top has the wall under
                     * it), and the wall under it looks the way the board looks */
                    if (c[1] < mid[1] + 0.25) {
                        continue;
                    }
                    if (ox * t->n[0] + oz * t->n[2] < 0.0) {
                        ox = -ox; oz = -oz;
                    }
                } else if (ox * (c[0] - a[0]) + oz * (c[2] - a[2]) > 0.0) {
                    ox = -ox; oz = -oz;
                }
                if (oz > 0.35) {
                    continue;           /* (the front has its wall) */
                }
                side = oz > -0.35;      /* looks east or west: a side wall */
                if (side && rm_optf(opt, "sides", 1) == 0.0) {
                    continue;           /* (`sides=0`: the model's own side walls stand set in under the eaves) */
                }
                /* an edge over the roof (a chimney's foot) is no place for a wall: is a roof under the air beside it? */
                {
                    double po[3] = { mid[0] + ox * 2.0, mid[1] + 0.5, mid[2] + oz * 2.0 }, dn[3] = { 0.0, -1.0, 0.0 };
                    int roof = 0;

                    for (i = 0; i < n && !roof; i++) {
                        double hd = tr[i].n[1] > 0.25 ? ray_hit(&tr[i], po, dn) : -1.0;

                        roof = hd > 0.0 && hd < 0.6 * (mid[1] + 0.5 - y0);   /* (not the building's own base slab on the ground) */
                    }
                    if (roof) {
                        continue;
                    }
                }
                if (pass == 0) {
                    continue;
                }
                /* an edge inside the model (a courtyard's rim) is no place for a wall: does something stand close
                 * outside it? */
                {
                    double po[3] = { mid[0], mid[1] - 0.5, mid[2] }, dd[3] = { ox, 0.0, oz };
                    int near = 0;

                    for (i = 0; i < n0 && !near; i++) {
                        double hd = ray_hit(&tr[i], po, dd);

                        near = hd > 0.5 && hd < 12.0;
                    }
                    /* (and half way down: the far wall of a basin or a yard the edge looks into) */
                    po[1] = (y0 + mid[1]) / 2.0;
                    for (i = 0; i < n0 && !near; i++) {
                        double hd = ray_hit(&tr[i], po, dd);

                        near = hd > 0.5 && hd < 120.0;
                    }
                    if (near) {
                        continue;
                    }
                }
                /* does a wall stand under it already? */
                o[0] = mid[0] + ox * 3.0; o[1] = (y0 + mid[1]) / 2.0; o[2] = mid[2] + oz * 3.0;
                d[0] = -ox; d[1] = 0.0; d[2] = -oz;
                for (i = 0; i < n0 && !wall; i++) {
                    double hd = tr[i].n[0] * ox + tr[i].n[2] * oz > 0.3 ? ray_hit(&tr[i], o, d) : -1.0;

                    wall = hd > 0.0 && hd < over + 11.0;
                }
                if (wall) {
                    continue;
                }
                /* the wall: set in from the edge, up to the roof over it, down to the ground */
                for (j = 0; j < 2u; j++) {
                    const double *src = j == 0 ? a : bb2;
                    /* (a back wall is set in straight south, so two pieces of it share their corners exactly
                     * and no crack opens between them; a side wall along its own way in) */
                    double top[3] = { side ? src[0] - ox * over : src[0], src[1], side ? src[2] - oz * over : src[2] + over };
                    double upd[3] = { 0.0, 1.0, 0.0 }, ro[3], best = -1.0;

                    if (over > 0.0) {
                        ro[0] = top[0]; ro[1] = top[1] - 0.2; ro[2] = top[2];
                        for (i = 0; i < n; i++) {
                            double hd = tr[i].n[1] > 0.1 || tr[i].n[1] < -0.1 ? ray_hit(&tr[i], ro, upd) : -1.0;

                            if (hd > 0.0 && hd < 12.0 && (best < 0.0 || hd < best)) {
                                best = hd;
                            }
                        }
                        if (best > 0.0) {
                            top[1] = ro[1] + best;
                        }
                    }
                    memcpy(quad[nq][j == 0 ? 0 : 1], top, sizeof top);
                    top[1] = y0;
                    memcpy(quad[nq][j == 0 ? 3 : 2], top, sizeof top);
                }
                /* a back wall ends where the side walls stand (a roof's edge runs on past them) */
                if (!side && wx1 > wx0) {
                    double x0 = quad[nq][0][0], x1 = quad[nq][1][0];
                    int skip = 0;

                    for (j = 0; j < 2u && !skip; j++) {
                        double xv = quad[nq][j][0], xo = quad[nq][1u - j][0], cl = xv < wx0 ? wx0 : xv > wx1 ? wx1 : xv, f;

                        if (cl == xv) {
                            continue;
                        }
                        if ((xo <= wx0 && xv <= wx0) || (xo >= wx1 && xv >= wx1) || fabs(xo - xv) < 1e-9) {
                            skip = 1;
                            break;
                        }
                        f = (cl - xo) / (xv - xo);
                        for (k = 0; k < 3; k++) {
                            quad[nq][j][k] = quad[nq][1u - j][k] + (quad[nq][j][k] - quad[nq][1u - j][k]) * f;
                            quad[nq][3u - j][k] = k == 1 ? quad[nq][3u - j][k]
                                                  : quad[nq][2u + j][k] + (quad[nq][3u - j][k] - quad[nq][2u + j][k]) * f;
                        }
                    }
                    (void)x0;
                    (void)x1;
                    if (skip) {
                        continue;
                    }
                    /* (`groundwalls=1`: and a back wall that ends short of a side wall, under a roof that ends short of
                     * it too, goes on to it: the corner is closed, no wall floats beside the building) */
                    if (rm_optf(opt, "groundwalls", 0) != 0.0) {
                        for (j = 0; j < 2u; j++) {
                            const double xe = quad[nq][j][0], to = xe > (wx0 + wx1) / 2.0 ? wx1 : wx0;

                            if (fabs(to - xe) > 0.05 && fabs(to - xe) < 6.0) {
                                quad[nq][j][0] = to;
                                quad[nq][3u - j][0] = to;
                            }
                        }
                        if (fabs(quad[nq][0][0] - quad[nq][1][0]) < 0.05) {
                            continue;       /* (a piece that was the corner's alone: nothing left of it) */
                        }
                    }
                }
                /* (kept facing outward: its corners counter-clockwise seen from outside) */
                {
                    double e1[3], e2[3], nn[3];

                    for (k = 0; k < 3; k++) {
                        e1[k] = quad[nq][1][k] - quad[nq][0][k];
                        e2[k] = quad[nq][2][k] - quad[nq][0][k];
                    }
                    rm_cross(e1, e2, nn);
                    if (nn[0] * ox + nn[2] * oz < 0.0) {
                        double t3[3];

                        memcpy(t3, quad[nq][0], sizeof t3); memcpy(quad[nq][0], quad[nq][1], sizeof t3); memcpy(quad[nq][1], t3, sizeof t3);
                        memcpy(t3, quad[nq][3], sizeof t3); memcpy(quad[nq][3], quad[nq][2], sizeof t3); memcpy(quad[nq][2], t3, sizeof t3);
                    }
                }
                qside[nq] = (unsigned char)side;
                nq++;
            }
        }
    }
    /* `fit=1`: the back is one wall from the west side wall's north edge to the east side wall's (a kiln, whose
     * sides lean: a wall under the roof's edge met neither side) */
    if (nq > 0 && rm_optf(opt, "fit", 0) != 0.0) {
        double c[2][2][3], ytop = -1e30, cxm = (lo[0] + hi[0]) / 2.0;      /* [west, east][foot, top] */
        int have[2][2] = { { 0, 0 }, { 0, 0 } }, sd, lv;
/* a side wall of the body: looks east or west and reaches the ground (a chimney's side does not) */
#define BIG_SIDE(i_) (fabs(tr[i_].n[0]) > 0.5 && fabs(tr[i_].n[1]) < 0.45 && \
                      (tr[i_].p[0][1] < y0 + 1.0 || tr[i_].p[1][1] < y0 + 1.0 || tr[i_].p[2][1] < y0 + 1.0))

        for (i = 0; i < n0; i++) {
            if (BIG_SIDE(i)) {
                for (j = 0; j < 3u; j++) {
                    ytop = tr[i].p[j][1] > ytop ? tr[i].p[j][1] : ytop;
                }
            }
        }
        for (i = 0; i < n0; i++) {
            if (!BIG_SIDE(i)) {
                continue;
            }
            for (j = 0; j < 3u; j++) {
                const double *v = tr[i].p[j];

                sd = v[0] > cxm;
                lv = v[1] > ytop - 1.0 ? 1 : v[1] < y0 + 1.0 ? 0 : -1;
                if (lv >= 0 && (!have[sd][lv] || v[2] < c[sd][lv][2])) {
                    memcpy(c[sd][lv], v, sizeof c[sd][lv]);
                    have[sd][lv] = 1;
                }
            }
        }
        if (have[0][0] && have[0][1] && have[1][0] && have[1][1]) {
            /* (corners counter-clockwise seen from the north: outside) */
            memcpy(quad[0][0], c[1][1], sizeof quad[0][0]);
            memcpy(quad[0][1], c[0][1], sizeof quad[0][1]);
            memcpy(quad[0][2], c[0][0], sizeof quad[0][2]);
            memcpy(quad[0][3], c[1][0], sizeof quad[0][3]);
            qside[0] = 0;
            nq = 1;
            fitted = 1;
        }
    }
#undef BIG_SIDE
    /* back wall pieces that stand within 2 units of the northmost are one plane: no slit between them */
    {
        double zn = 1e30, zroof = 1e30;
        unsigned q2;

        for (q2 = 0; q2 < nq; q2++) {
            for (j = 0; !qside[q2] && j < 4u; j++) {
                zn = quad[q2][j][2] < zn ? quad[q2][j][2] : zn;
            }
        }
        if (wzn < 1e29 && fabs(zn - wzn) < 8.0) {
            zn = wzn;                   /* where the side walls end */
        }
        /* (the roof's back edge: the northmost corner of a slope; a sheet on the ground can reach further) */
        for (i = 0; i < n0; i++) {
            if (tr[i].n[1] > 0.25 && tr[i].n[1] < 0.98) {
                for (j = 0; j < 3u; j++) {
                    zroof = tr[i].p[j][2] < zroof ? tr[i].p[j][2] : zroof;
                }
            }
        }
        /* `flush=1`: the back wall stands at the roof's back edge (its northmost corner), not where the side
         * walls end: seen from behind, nothing under the roof shows (its underside, the top of the storey under
         * it).  The side walls are carried on to it (below, the corner strips). */
        if (rm_optf(opt, "flush", 0) != 0.0 && zroof < 1e29) {
            zn = zroof;
        }
        for (q2 = 0; !fitted && q2 < nq; q2++) {
            for (j = 0; !qside[q2] && j < 4u; j++) {
                if (fabs(quad[q2][j][2] - zn) < 8.0) {
                    quad[q2][j][2] = zn;
                }
            }
        }
        /* `inset=X0:X1:D+..`: the back wall pieces between X0 and X1 (by their middles) stand D further in, as the
         * front's wall there stands in from its roof's end (a gable set back in the roof's frame) */
        {
            char ib[128], *ip;

            if (rm_opt(opt, "inset", ib, sizeof ib) != NULL) {
                for (ip = ib; ip != NULL && *ip != '\0'; ) {
                    double i0, i1, idz;

                    if (sscanf(ip, "%lf:%lf:%lf", &i0, &i1, &idz) == 3) {
                        for (q2 = 0; q2 < nq; q2++) {
                            const double qm = (quad[q2][0][0] + quad[q2][1][0] + quad[q2][2][0] + quad[q2][3][0]) / 4.0;

                            /* (a piece of the back only: within a unit of the back wall's line) */
                            if (!qside[q2] && qm > i0 && qm < i1 && fabs(quad[q2][0][2] - zn) < 1.0) {
                                /* (where the piece's end meets a wall that stays, a return wall between the two, as
                                 * tall as the one that stays is there) */
                                unsigned e2, q3;

                                for (e2 = 0; e2 < 2u; e2++) {
                                    const double xe = quad[q2][e2 == 0 ? 0 : 1][0];
                                    double h = -1e30;

                                    for (q3 = 0; q3 < nq; q3++) {
                                        const double qm3 = (quad[q3][0][0] + quad[q3][1][0] + quad[q3][2][0] + quad[q3][3][0]) / 4.0;
                                        unsigned c4;

                                        if (q3 == q2 || qside[q3] || (qm3 > i0 && qm3 < i1)) {
                                            continue;
                                        }
                                        for (c4 = 0; c4 < 2u; c4++) {
                                            if (fabs(quad[q3][c4][0] - xe) < 0.3 && quad[q3][c4][1] > h) {
                                                h = quad[q3][c4][1];
                                            }
                                        }
                                    }
                                    if (h > y0 + 1.0 && nret < 16u) {
                                        ret[nret][0] = xe;
                                        ret[nret][1] = quad[q2][0][2];
                                        ret[nret][2] = quad[q2][0][2] + idz;
                                        ret[nret][3] = h;
                                        nret++;
                                    }
                                }
                                for (j = 0; j < 4u; j++) {
                                    quad[q2][j][2] += idz;
                                }
                            }
                        }
                    }
                    ip = strchr(ip, '+');
                    ip = ip != NULL ? ip + 1 : NULL;
                }
            }
        }
    }
    /* The back wall's picture: the building's own front as it is seen square on from the south (its walls,
     * not its roof), a pixel for each half map unit; what belongs to the entrance (`erase`) is plain wall, each
     * row taken from the front's plain place `plain` at the same height; above the front wall's top (a gable)
     * the wall's highest row goes on up.  The back wall takes the pixel at its own place (x, y). */
    if (nq > 0 && out->ntex < 8) {
        const double ppu = 2.0;
        char eb[256], *ep;
        char sb[16];
        const int east = rm_opt(opt, "src", sb, sizeof sb) != NULL && strcmp(sb, "east") == 0;
        const int ax = east ? 2 : 0, dp = east ? 0 : 2;     /* the picture's across, and the way it is looked at */
        double er[8][5], plain = rm_optf(opt, "plain", 1e30), xa = lo[ax], xb = hi[ax], yb = hi[1], wz = hi[dp];
        const int flatw = rm_optf(opt, "flat", 0) != 0.0;     /* (`flat=1`: the plain place's column all across: bands, no openings) */
        const double at_most = rm_optf(opt, "at", 1e30);      /* (`at=Z`: the front wall that stands at most there: a model of two huts) */
        /* (`atleast=Z`: and at least there: the outer wall, not a taller block's side further in) */
        const double at_least = rm_optf(opt, "atleast", -1e30);
        double spn[8][4];
        unsigned nspan = 0;
        double gb[7], gd[16][3];       /* (`gable`: its numbers; each set-in piece's way back out to the wall) */
        unsigned gq[16], ngq = 0;
        int gable = 0;
        double sp0 = xa, sp1 = xb, qx0 = 1e30, qx1 = -1e30, lean = rm_optf(opt, "lean", 0.0), flare = rm_optf(opt, "flare", 0.0);
        unsigned char *px, *ok, white[3], dark[3] = { 0, 0, 0 };
        unsigned q, first = out->ntri, ner = 0, src = tr[0].id;
        int Wm = (int)ceil((xb - xa) * ppu), Hm = (int)ceil((yb - y0) * ppu), x, y, tx = -1;

        if (rm_opt(opt, "erase", eb, sizeof eb) != NULL) {
            for (ep = eb; ep != NULL && *ep != '\0' && ner < 8u; ) {
                int got;

                er[ner][4] = 0.0;
                got = sscanf(ep, "%lf:%lf:%lf:%lf:%lf", &er[ner][0], &er[ner][1], &er[ner][2], &er[ner][3], &er[ner][4]);
                if (got >= 4) {
                    ner++;
                }
                ep = strchr(ep, '+');
                ep = ep != NULL ? ep + 1 : NULL;
            }
        }
        if (Wm < 2 || Hm < 2 || Wm > 1024 || Hm > 1024) {
            goto done;
        }
        /* (`nodark=1`: a face the model paints near black, the shade behind a window or inside a recess, is no
         * wall's material: it is passed over, when the wall is chosen and when its picture is read) */
        const int nodark = rm_optf(opt, "nodark", 0) != 0.0;
#define DARK(i_) (nodark && tr[i_].rgb[0] < 80 && tr[i_].rgb[1] < 80 && tr[i_].rgb[2] < 80)

        /* the front wall's plane: where the biggest upright triangle that looks south stands */
        {
            double big = 0.0;

            for (i = 0; i < n0; i++) {
                double e1[3], e2[3], c3[3], area;

                if (tr[i].n[dp] < 0.9 || tr[i].p[0][dp] > at_most || tr[i].p[0][dp] < at_least || DARK(i)) {
                    continue;
                }
                for (k = 0; k < 3; k++) {
                    e1[k] = tr[i].p[1][k] - tr[i].p[0][k];
                    e2[k] = tr[i].p[2][k] - tr[i].p[0][k];
                }
                rm_cross(e1, e2, c3);
                area = sqrt(rm_dot(c3, c3));
                if (area > big) {
                    big = area;
                    wz = tr[i].p[0][dp];
                }
            }
        }
        px = (unsigned char *)calloc((size_t)Wm * Hm, 4);
        ok = (unsigned char *)calloc((size_t)Wm * Hm, 1);
        if (px == NULL || ok == NULL) {
            free(px);
            free(ok);
            out->fail = 1;
            goto done;
        }
        for (y = 0; y < Hm; y++) {
            for (x = 0; x < Wm; x++) {
                double o[3], d[3] = { 0.0, 0.0, 0.0 }, best = -1.0, cz3;
                const Tr *bt2 = NULL;

                o[ax] = xa + (x + 0.5) / ppu;
                o[1] = yb - (y + 0.5) / ppu;
                o[dp] = hi[dp] + 8.0;
                d[dp] = -1.0;
                for (i = 0; i < n0; i++) {
                    double hd;

                    if (tr[i].n[dp] < 0.2 || tr[i].n[1] > 0.25 || DARK(i)) {
                        continue;           /* (not a wall that looks that way) */
                    }
                    cz3 = (tr[i].p[0][dp] + tr[i].p[1][dp] + tr[i].p[2][dp]) / 3.0;
                    if (cz3 > wz + rm_optf(opt, "near", 1.5) || cz3 < wz - rm_optf(opt, "far", 8.0)) {
                        continue;           /* (the eave's board in front of the wall, a chimney far behind it) */
                    }
                    hd = ray_hit(&tr[i], o, d);
                    if (hd > 0.0 && (best < 0.0 || hd < best)
                        && wall_px(&tr[i], tex, ntex, o[0] + d[0] * hd, o[1], o[2] + d[2] * hd, NULL)) {
                        best = hd;
                        bt2 = &tr[i];
                    }
                }
                if (bt2 != NULL) {
                    wall_px(bt2, tex, ntex, o[0] + d[0] * best, o[1], o[2] + d[2] * best, px + ((size_t)y * Wm + (size_t)x) * 4u);
                    ok[(size_t)y * Wm + (size_t)x] = 1;
                }
            }
        }
        /*
         * `fill=1`: the back is composed, not cut out of the front.  The whole picture is first the wall's own
         * plain material: each row the plain place's pixel of that row; a row above the plain place's top
         * takes the row `period` map units lower (boards and courses repeat), so the material goes on unbroken
         * up to the roof.  Then `keep=X0:X1:Y0:Y1+..` puts back the front's own pixels in those places only (a
         * corner post, a beam, one window).  Nothing of the front's roof edge, door or trim comes along.
         */
        if (rm_optf(opt, "fill", 0) != 0.0 && plain < 1e29) {
            unsigned char *orig = (unsigned char *)malloc((size_t)Wm * Hm * 4u), *ook = (unsigned char *)malloc((size_t)Wm * Hm);
            int per = (int)rint(rm_optf(opt, "period", 8.0) * ppu), ftx = (int)((plain - xa) * ppu);
            const double filltop = rm_optf(opt, "filltop", 1e30);
            char kb[256], *kp;

            ftx = ftx < 0 ? 0 : ftx >= Wm ? Wm - 1 : ftx;
            per = per < 1 ? 1 : per;
            if (orig != NULL && ook != NULL) {
                memcpy(orig, px, (size_t)Wm * Hm * 4u);
                memcpy(ook, ok, (size_t)Wm * Hm);
                for (y = Hm - 1; y >= 0; y--) {
                    int sy = y;

                    /* (`filltop=Y`: the plain place is the wall's material up to that height only: over it
                     * the front has a beam, a gable, the roof's edge) */
                    while (sy < Hm && (!ook[(size_t)sy * Wm + (size_t)ftx] || yb - (sy + 0.5) / ppu > filltop)) {
                        sy += per;
                    }
                    if (sy >= Hm) {
                        continue;
                    }
                    for (x = 0; x < Wm; x++) {
                        memcpy(px + ((size_t)y * Wm + (size_t)x) * 4u, orig + ((size_t)sy * Wm + (size_t)ftx) * 4u, 4u);
                        ok[(size_t)y * Wm + (size_t)x] = 1;
                    }
                }
                if (rm_opt(opt, "keep", kb, sizeof kb) != NULL) {
                    for (kp = kb; kp != NULL && *kp != '\0'; ) {
                        double k0, k1, k2, k3;

                        if (sscanf(kp, "%lf:%lf:%lf:%lf", &k0, &k1, &k2, &k3) == 4) {
                            int x0 = (int)floor((k0 - xa) * ppu), x1 = (int)ceil((k1 - xa) * ppu);
                            int y1 = (int)ceil((yb - k2) * ppu), y0p = (int)floor((yb - k3) * ppu);

                            for (y = y0p < 0 ? 0 : y0p; y < y1 && y < Hm; y++) {
                                for (x = x0 < 0 ? 0 : x0; x < x1 && x < Wm; x++) {
                                    if (ook[(size_t)y * Wm + (size_t)x]) {
                                        memcpy(px + ((size_t)y * Wm + (size_t)x) * 4u, orig + ((size_t)y * Wm + (size_t)x) * 4u, 4u);
                                    }
                                }
                            }
                        }
                        kp = strchr(kp, '+');
                        kp = kp != NULL ? kp + 1 : NULL;
                    }
                }
            }
            free(orig);
            free(ook);
        }
        if (flatw && plain > 1e29) {
            /* `flat=1` alone: the plain place is the picture's middle, and each row there is the row's mean
             * colour (a brushed-metal side is drawn in dots: one column of it, repeated, is noise) */
            plain = (xa + xb) / 2.0;
            tx = (int)((plain - xa) * ppu);
            tx = tx < 0 ? 0 : tx >= Wm ? Wm - 1 : tx;
            for (y = 0; y < Hm; y++) {
                unsigned long sum[3] = { 0, 0, 0 }, cnt = 0;

                for (x = 0; x < Wm; x++) {
                    if (ok[(size_t)y * Wm + (size_t)x]) {
                        const unsigned char *o4 = px + ((size_t)y * Wm + (size_t)x) * 4u;

                        sum[0] += o4[0]; sum[1] += o4[1]; sum[2] += o4[2];
                        cnt++;
                    }
                }
                if (cnt > 0) {
                    unsigned char *o4 = px + ((size_t)y * Wm + (size_t)tx) * 4u;

                    o4[0] = (unsigned char)(sum[0] / cnt); o4[1] = (unsigned char)(sum[1] / cnt); o4[2] = (unsigned char)(sum[2] / cnt);
                    o4[3] = 255;
                    ok[(size_t)y * Wm + (size_t)tx] = 1;
                }
            }
        }
        /* the entrance taken out: plain wall, row by row from the plain place */
        if (plain < 1e29) {
            tx = (int)((plain - xa) * ppu);
            tx = tx < 0 ? 0 : tx >= Wm ? Wm - 1 : tx;
        }
        for (q = 0; q < ner && (tx >= 0 || er[q][4] != 0.0); q++) {
            int x0 = (int)floor((er[q][0] - xa) * ppu), x1 = (int)ceil((er[q][1] - xa) * ppu);
            int y1 = (int)ceil((yb - er[q][2]) * ppu), y0p = (int)floor((yb - er[q][3]) * ppu);

            for (y = y0p < 0 ? 0 : y0p; y < y1 && y < Hm; y++) {
                for (x = x0 < 0 ? 0 : x0; x < x1 && x < Wm; x++) {
                    int sx2 = er[q][4] != 0.0 ? x + (int)rint(er[q][4] * ppu) : tx;

                    if (sx2 < 0 || sx2 >= Wm) {
                        continue;
                    }
                    memcpy(px + ((size_t)y * Wm + (size_t)x) * 4u, px + ((size_t)y * Wm + (size_t)sx2) * 4u, 4u);
                    ok[(size_t)y * Wm + (size_t)x] = ok[(size_t)y * Wm + (size_t)sx2];
                }
            }
        }
        /* where the front shows no wall (over its top, beside it): the nearest wall pixel under, then beside */
        for (x = 0; x < Wm; x++) {
            int last = -1;

            for (y = Hm - 1; y >= 0; y--) {
                if (ok[(size_t)y * Wm + (size_t)x]) {
                    last = y;
                } else if (last >= 0) {
                    memcpy(px + ((size_t)y * Wm + (size_t)x) * 4u, px + ((size_t)last * Wm + (size_t)x) * 4u, 4u);
                }
            }
            for (y = 0, last = -1; y < Hm; y++) {       /* (under the wall's foot: the lowest row) */
                if (ok[(size_t)y * Wm + (size_t)x]) {
                    last = y;
                } else if (last >= 0 && px[((size_t)y * Wm + (size_t)x) * 4u + 3u] == 0) {
                    memcpy(px + ((size_t)y * Wm + (size_t)x) * 4u, px + ((size_t)last * Wm + (size_t)x) * 4u, 4u);
                }
            }
        }
        for (y = 0; y < Hm; y++) {
            int last = -1;

            for (x = 0; x < Wm; x++) {
                if (px[((size_t)y * Wm + (size_t)x) * 4u + 3u]) {
                    last = x;
                } else if (last >= 0) {
                    memcpy(px + ((size_t)y * Wm + (size_t)x) * 4u, px + ((size_t)y * Wm + (size_t)last) * 4u, 4u);
                }
            }
            for (x = Wm - 1, last = -1; x >= 0; x--) {
                if (px[((size_t)y * Wm + (size_t)x) * 4u + 3u]) {
                    last = x;
                } else if (last >= 0) {
                    memcpy(px + ((size_t)y * Wm + (size_t)x) * 4u, px + ((size_t)y * Wm + (size_t)last) * 4u, 4u);
                }
            }
        }
        for (i = 0; i < (unsigned)(Wm * Hm); i++) {
            px[(size_t)i * 4u + 3u] = 255;
        }
        free(ok);
        for (k = 0; k < 3; k++) {
            white[k] = (unsigned char)(255.0 * shade);
        }
        /* (`span=A:B`, with the east side as the picture: that stretch of the side lies across the back) */
        if (rm_opt(opt, "span", eb, sizeof eb) != NULL) {
            sscanf(eb, "%lf:%lf", &sp0, &sp1);
        }
        if (rm_opt(opt, "spans", eb, sizeof eb) != NULL) {
            for (ep = eb; ep != NULL && *ep != '\0' && nspan < 8u; ) {
                if (sscanf(ep, "%lf:%lf:%lf:%lf", &spn[nspan][0], &spn[nspan][1], &spn[nspan][2], &spn[nspan][3]) == 4) {
                    nspan++;
                }
                ep = strchr(ep, '+');
                ep = ep != NULL ? ep + 1 : NULL;
            }
        }
        for (q = 0; q < nq; q++) {
            for (j = 0; j < 4u; j++) {
                qx0 = quad[q][j][0] < qx0 ? quad[q][j][0] : qx0;
                qx1 = quad[q][j][0] > qx1 ? quad[q][j][0] : qx1;
            }
        }
        /* `gable=XA:XB:XC:XD:YI:YO:D`: the gable under a roof band copied by `rim` built as the front's is: the band's
         * feet stand on two pillars (XA..XB, XC..XD) in the wall's plane, cut to the band's lower end (YI at the inner
         * side, YO at the outer), and the wall between them over YI is set D into the house, behind the band. Without
         * it the band lay on a flat wall, in front of it. */
        if (rm_opt(opt, "gable", eb, sizeof eb) != NULL
            && sscanf(eb, "%lf:%lf:%lf:%lf:%lf:%lf:%lf", &gb[0], &gb[1], &gb[2], &gb[3], &gb[4], &gb[5], &gb[6]) == 7) {
            unsigned q0 = nq, c;

            /* (cut at the pillars' sides: corners 0 and 3 at one x, 1 and 2 at the other, 0 and 1 the top) */
            for (c = 0; c < 4u; c++) {
                for (q = 0; q < q0 && nq < n * 3u; q++) {
                    double xc = gb[c], a = quad[q][0][0], b = quad[q][1][0], f;

                    if (!((xc > a + 0.05 && xc < b - 0.05) || (xc > b + 0.05 && xc < a - 0.05))) {
                        continue;
                    }
                    f = (xc - a) / (b - a);
                    memcpy(quad[nq], quad[q], sizeof quad[q]);
                    qside[nq] = qside[q];
                    for (k = 0; k < 3; k++) {
                        double top = quad[q][0][k] + (quad[q][1][k] - quad[q][0][k]) * f;
                        double bot = quad[q][3][k] + (quad[q][2][k] - quad[q][3][k]) * f;

                        quad[q][1][k] = top;        /* (this one: from corner 0 to the cut) */
                        quad[q][2][k] = bot;
                        quad[nq][0][k] = top;       /* (the new one: from the cut to corner 1) */
                        quad[nq][3][k] = bot;
                    }
                    nq++;
                }
                q0 = nq;
            }
            for (q = 0, q0 = nq; q < q0; q++) {
                const double qm = (quad[q][0][0] + quad[q][1][0]) / 2.0;
                const int lft = qm > gb[0] && qm < gb[1], rgt = qm > gb[2] && qm < gb[3];

                if (lft || rgt) {
                    /* (a pillar: its top is the band's lower end) */
                    for (j = 0; j < 2u; j++) {
                        const double x = quad[q][j][0];
                        const double f = lft ? (gb[1] - x) / (gb[1] - gb[0]) : (x - gb[2]) / (gb[3] - gb[2]);
                        const double yt = gb[4] + (gb[5] - gb[4]) * f;

                        quad[q][j][1] = quad[q][j][1] > yt ? yt : quad[q][j][1];
                    }
                } else if (qm > gb[1] && qm < gb[2] && quad[q][0][1] > gb[4] + 0.05 && quad[q][1][1] > gb[4] + 0.05
                           && nq < n * 3u && ngq < 16u) {
                    /* (between the pillars: the part over YI goes into the house) */
                    double e1[3], e2[3], nn[3];

                    for (k = 0; k < 3; k++) {
                        e1[k] = quad[q][1][k] - quad[q][0][k];
                        e2[k] = quad[q][2][k] - quad[q][0][k];
                    }
                    rm_cross(e1, e2, nn);
                    rm_norm(nn);
                    memcpy(quad[nq], quad[q], sizeof quad[q]);
                    qside[nq] = qside[q];
                    quad[nq][2][1] = gb[4];
                    quad[nq][3][1] = gb[4];
                    for (j = 0; j < 4u; j++) {
                        for (k = 0; k < 3; k++) {
                            quad[nq][j][k] -= nn[k] * gb[6];
                        }
                    }
                    quad[q][0][1] = gb[4];
                    quad[q][1][1] = gb[4];
                    for (k = 0; k < 3; k++) {
                        gd[ngq][k] = nn[k] * gb[6];     /* (from the set-in gable back out to the wall's plane) */
                    }
                    gq[ngq++] = nq;
                    nq++;
                }
            }
            gable = 1;
        }
        for (q = 0; q < nq; q++) {
            double t[4][2], in[4][3], foot = rm_optf(opt, "foot", y0), ux[4];
            int high = 0;       /* (`gable`'s set-in piece: it stands on the ledge, not on the ground) */

            for (j = 0; j < ngq; j++) {
                high |= gq[j] == q;
            }
            for (j = 0; j < 4u; j++) {
                ux[j] = quad[q][j][0];
            }
            for (j = 0; j < 4u; j++) {
                if (j >= 2u && !fitted && !high) {
                    quad[q][j][1] = foot;       /* (a house on posts: its wall ends at its floor) */
                    quad[q][j][2] -= lean;      /* (`lean`: the foot stands out, as the sides' feet do) */
                    if (flare != 0.0 && qx1 > qx0) {
                        quad[q][j][0] = (qx0 + qx1) / 2.0 + (quad[q][j][0] - (qx0 + qx1) / 2.0) * (1.0 + 2.0 * flare / (qx1 - qx0));
                    }
                }
                /* (a side wall runs along the house: every place on it is the front's plain place) */
                if (east) {
                    double zz = qx1 > qx0 ? sp1 + (ux[j] - qx0) / (qx1 - qx0) * (sp0 - sp1) : sp0;

                    /* `spans=X0:X1:Z0:Z1+..`: the back's stretch X0..X1 (a wing, a middle block) takes the side's
                     * stretch Z0..Z1, at the side's own scale: each part of a back its own window column, not the
                     * whole side spread over the whole back (the piece by its middle) */
                    {
                        const double qm = (ux[0] + ux[1] + ux[2] + ux[3]) / 4.0;
                        unsigned s4;

                        for (s4 = 0; s4 < nspan; s4++) {
                            if (qm >= spn[s4][0] - 0.01 && qm <= spn[s4][1] + 0.01 && spn[s4][1] > spn[s4][0]) {
                                zz = spn[s4][2] + (ux[j] - spn[s4][0]) / (spn[s4][1] - spn[s4][0]) * (spn[s4][3] - spn[s4][2]);
                                break;
                            }
                        }
                    }

                    t[j][0] = (((qside[q] || flatw) && plain < 1e29 ? plain : zz) - xa) / (xb - xa);
                } else
                t[j][0] = (((qside[q] || flatw) && plain < 1e29 ? plain : ux[j]) - xa) / (xb - xa);
                t[j][1] = (yb - quad[q][j][1]) / (yb - y0);
                in[j][0] = quad[q][j][0];
                in[j][1] = quad[q][j][1];
                in[j][2] = quad[q][j][2];
            }
            {
                /* (the inner side a quarter unit inside: two walls in one plane would flicker) */
                double e1[3], e2[3], nn[3];

                for (k = 0; k < 3; k++) {
                    e1[k] = quad[q][1][k] - quad[q][0][k];
                    e2[k] = quad[q][2][k] - quad[q][0][k];
                }
                rm_cross(e1, e2, nn);
                rm_norm(nn);
                for (j = 0; j < 4u; j++) {
                    for (k = 0; k < 3; k++) {
                        in[j][k] -= nn[k] * 0.0;    /* (in the wall's own plane: the two look opposite ways, one is drawn) */
                    }
                }
            }
            rm_tri(out, src, out->ntex, 1, white, quad[q][0], quad[q][1], quad[q][2], t[0], t[1], t[2], 0, 0);
            rm_tri(out, src, out->ntex, 1, white, quad[q][0], quad[q][2], quad[q][3], t[0], t[2], t[3], 0, 0);
            /* its inner side, dark: through an open door or a window the house is dark inside, as the field shows it */
            rm_tri(out, src, out->ntex, 1, dark, in[0], in[2], in[1], t[0], t[2], t[1], 0, 0);
            rm_tri(out, src, out->ntex, 1, dark, in[0], in[3], in[2], t[0], t[3], t[2], 0, 0);
        }
        /* `gable`'s ledge at YI and the pillars' inner sides, from the wall's plane to the set-in gable, in plain
         * stone (both ways: seen from either side, nothing behind them) */
        for (q = 0; gable && q < ngq; q++) {
            const double tu = plain < 1e29 ? (plain - xa) / (xb - xa) : 0.5;
            const double *g0 = quad[gq[q]][3], *g1 = quad[gq[q]][2];
            double f[4][3], tf[4][2];
            int s;

            /* (the ledge under this piece of the set-in gable) */
            for (k = 0; k < 3; k++) {
                f[0][k] = g0[k]; f[1][k] = g1[k];
                f[2][k] = g1[k] + gd[q][k]; f[3][k] = g0[k] + gd[q][k];
            }
            for (j = 0; j < 4u; j++) {
                tf[j][0] = tu;
                tf[j][1] = (yb - f[j][1]) / (yb - y0);
            }
            rm_tri(out, src, out->ntex, 1, white, f[0], f[1], f[2], tf[0], tf[1], tf[2], 0, 0);
            rm_tri(out, src, out->ntex, 1, white, f[0], f[2], f[3], tf[0], tf[2], tf[3], 0, 0);
            rm_tri(out, src, out->ntex, 1, white, f[0], f[2], f[1], tf[0], tf[2], tf[1], 0, 0);
            rm_tri(out, src, out->ntex, 1, white, f[0], f[3], f[2], tf[0], tf[3], tf[2], 0, 0);
            /* (a pillar's inner side where this piece ends at XB or XC) */
            for (s = 0; s < 2; s++) {
                const double *top = quad[gq[q]][s == 0 ? 0 : 1], *bot = quad[gq[q]][s == 0 ? 3 : 2];

                if (fabs(top[0] - gb[1]) > 0.05 && fabs(top[0] - gb[2]) > 0.05) {
                    continue;
                }
                for (k = 0; k < 3; k++) {
                    f[0][k] = bot[k]; f[1][k] = top[k];
                    f[2][k] = top[k] + gd[q][k]; f[3][k] = bot[k] + gd[q][k];
                }
                for (j = 0; j < 4u; j++) {
                    tf[j][0] = tu;
                    tf[j][1] = (yb - f[j][1]) / (yb - y0);
                }
                rm_tri(out, src, out->ntex, 1, white, f[0], f[1], f[2], tf[0], tf[1], tf[2], 0, 0);
                rm_tri(out, src, out->ntex, 1, white, f[0], f[2], f[3], tf[0], tf[2], tf[3], 0, 0);
                rm_tri(out, src, out->ntex, 1, white, f[0], f[2], f[1], tf[0], tf[2], tf[1], 0, 0);
                rm_tri(out, src, out->ntex, 1, white, f[0], f[3], f[2], tf[0], tf[3], tf[2], 0, 0);
            }
        }
        /* `flush=1`: the side walls carried on from where they end to the back wall, as tall as the back wall is
         * at that end, in the back wall's own picture at its end column (the corner post) */
        if (rm_optf(opt, "flush", 0) != 0.0 && wzn < 1e29 && wx1 > wx0) {
            int e;

            for (e = 0; e < 2; e++) {
                double xe = e == 0 ? wx0 : wx1, ytop = -1e30, tu = (xe - xa) / (xb - xa), sgn = e == 0 ? -1.0 : 1.0, zb0 = 1e30;

                for (q = 0; q < nq; q++) {
                    for (j = 0; j < 2u; j++) {
                        if (fabs(quad[q][j][0] - xe) < 0.6 && quad[q][j][1] > ytop) {
                            ytop = quad[q][j][1];
                        }
                    }
                }
                for (q = 0; q < nq; q++) {
                    zb0 = quad[q][0][2] < zb0 ? quad[q][0][2] : zb0;
                }
                if (ytop < y0 + 1.0 || wzn <= zb0 + 0.05) {
                    continue;
                }
                tu = tu < 0.002 ? 0.002 : tu > 0.998 ? 0.998 : tu;
                {
                    double a0[3] = { xe, y0, zb0 }, a1[3] = { xe, y0, wzn }, a2[3] = { xe, ytop, wzn }, a3[3] = { xe, ytop, zb0 };
                    double ta0[2] = { tu, 1.0 }, ta1[2] = { tu, 1.0 }, ta2[2] = { tu, (yb - ytop) / (yb - y0) }, ta3[2] = { tu, (yb - ytop) / (yb - y0) };

                    /* (corners counter-clockwise seen from outside: from the west for the west end) */
                    if (sgn < 0.0) {
                        rm_tri(out, src, out->ntex, 1, white, a0, a1, a2, ta0, ta1, ta2, 0, 0);
                        rm_tri(out, src, out->ntex, 1, white, a0, a2, a3, ta0, ta2, ta3, 0, 0);
                        rm_tri(out, src, out->ntex, 1, dark, a0, a2, a1, ta0, ta2, ta1, 0, 0);
                        rm_tri(out, src, out->ntex, 1, dark, a0, a3, a2, ta0, ta3, ta2, 0, 0);
                    } else {
                        rm_tri(out, src, out->ntex, 1, white, a0, a2, a1, ta0, ta2, ta1, 0, 0);
                        rm_tri(out, src, out->ntex, 1, white, a0, a3, a2, ta0, ta3, ta2, 0, 0);
                        rm_tri(out, src, out->ntex, 1, dark, a0, a1, a2, ta0, ta1, ta2, 0, 0);
                        rm_tri(out, src, out->ntex, 1, dark, a0, a2, a3, ta0, ta2, ta3, 0, 0);
                    }
                }
            }
        }
        /* `eaves=1`: each side wall carried up from its top to the roof's underside over it, in its own picture
         * carried on (a hut on posts, whose side walls stop under the slope: through the gap one saw into the hut) */
        if (rm_optf(opt, "eaves", 0) != 0.0) {
            int e;

            for (e = 0; e < 2; e++) {
                const double sgn = e == 0 ? -1.0 : 1.0;
                const Tr *s = NULL;
                double top = -1e30, z0 = 1e30, z1 = -1e30, xs = 0.0, rise = 1e30;

                /* the side wall: the upright triangles that look this way; the highest one is the picture's */
                for (i = 0; i < n0; i++) {
                    if (fabs(tr[i].n[1]) > 0.3 || tr[i].n[0] * sgn < 0.7) {
                        continue;
                    }
                    for (j = 0; j < 3u; j++) {
                        z0 = tr[i].p[j][2] < z0 ? tr[i].p[j][2] : z0;
                        z1 = tr[i].p[j][2] > z1 ? tr[i].p[j][2] : z1;
                        if (tr[i].p[j][1] > top) {
                            top = tr[i].p[j][1];
                            xs = tr[i].p[j][0];
                            s = &tr[i];
                        }
                    }
                }
                if (s == NULL || z1 - z0 < 1.0) {
                    continue;
                }
                /* the roof's underside straight over the wall's top, the lowest along it */
                for (j = 0; j < 5u; j++) {
                    const double o[3] = { xs - sgn * 0.05, top + 0.01, z0 + (z1 - z0) * (0.1 + 0.2 * j) }, up[3] = { 0.0, 1.0, 0.0 };

                    for (i = 0; i < n0; i++) {
                        const double hd = fabs(tr[i].n[1]) > 0.25 ? ray_hit(&tr[i], o, up) : -1.0;

                        if (hd > 0.0 && hd < rise) {
                            rise = hd;
                        }
                    }
                }
                if (rise < 0.05 || rise > 24.0) {
                    continue;
                }
                {
                    /* the picture's place as a function of (z, y) on the wall, from its highest triangle */
                    const double ax = s->p[0][2], ay = s->p[0][1];
                    const double bx = s->p[1][2] - ax, by = s->p[1][1] - ay, cx = s->p[2][2] - ax, cy = s->p[2][1] - ay;
                    const double det = bx * cy - cx * by;
                    double q4[4][3], t4[4][2];
                    int c;

                    if (fabs(det) < 1e-9) {
                        continue;
                    }
                    for (j = 0; j < 4u; j++) {
                        const double zz = j == 0 || j == 3 ? z0 : z1, yy = j < 2 ? top : top + rise;

                        q4[j][0] = xs;
                        q4[j][1] = yy;
                        q4[j][2] = zz;
                        for (c = 0; c < 2; c++) {
                            const double d1 = (double)s->uv[1][c] - s->uv[0][c], d2 = (double)s->uv[2][c] - s->uv[0][c];
                            const double mz = (d1 * cy - d2 * by) / det, my = (d2 * bx - d1 * cx) / det;

                            t4[j][c] = s->uv[0][c] + mz * (zz - ax) + my * (yy - ay);
                        }
                    }
                    /* (looking out: from the east for the east wall) */
                    if (sgn > 0.0) {
                        rm_tri(out, s->id, -1, 1, s->rgb, q4[0], q4[2], q4[1], t4[0], t4[2], t4[1], 0, 0);
                        rm_tri(out, s->id, -1, 1, s->rgb, q4[0], q4[3], q4[2], t4[0], t4[3], t4[2], 0, 0);
                    } else {
                        rm_tri(out, s->id, -1, 1, s->rgb, q4[0], q4[1], q4[2], t4[0], t4[1], t4[2], 0, 0);
                        rm_tri(out, s->id, -1, 1, s->rgb, q4[0], q4[2], q4[3], t4[0], t4[2], t4[3], 0, 0);
                    }
                }
            }
        }
        /* `inset`'s return walls: from the wall that stays to the one set in, both sides, in plain stone */
        for (q = 0; q < nret; q++) {
            const double tu = plain < 1e29 ? (plain - xa) / (xb - xa) : 0.5;
            double tb0[2] = { tu, 1.0 }, tt0[2] = { tu, (yb - ret[q][3]) / (yb - y0) };
            double c0[3] = { ret[q][0], y0, ret[q][1] }, c1[3] = { ret[q][0], y0, ret[q][2] };
            double c2[3] = { ret[q][0], ret[q][3], ret[q][2] }, c3[3] = { ret[q][0], ret[q][3], ret[q][1] };

            /* (both ways: from the wing's side and from the set-in block's) */
            rm_tri(out, src, out->ntex, 1, white, c0, c1, c2, tb0, tb0, tt0, 0, 0);
            rm_tri(out, src, out->ntex, 1, white, c0, c2, c3, tb0, tt0, tt0, 0, 0);
            rm_tri(out, src, out->ntex, 1, white, c0, c2, c1, tb0, tt0, tb0, 0, 0);
            rm_tri(out, src, out->ntex, 1, white, c0, c3, c2, tb0, tt0, tt0, 0, 0);
            /* the set-in block's own side wall in that plane (painted dark, above the wing's roof its side) reached
             * the old back line: its corners there go to the new one, so it does not stand in the step */
            for (i = 0; i < n0; i++) {
                int hit = fabs(tr[i].n[0]) > 0.9, at_old = 0;
                double pp[3][3], tt[3][2];

                for (j = 0; j < 3u && hit; j++) {
                    hit = fabs(tr[i].p[j][0] - ret[q][0]) < 0.05;
                    at_old |= fabs(tr[i].p[j][2] - ret[q][1]) < 0.05;
                }
                if (!hit || !at_old) {
                    continue;
                }
                for (j = 0; j < 3u; j++) {
                    for (k = 0; k < 3; k++) {
                        pp[j][k] = tr[i].p[j][k];
                    }
                    if (fabs(pp[j][2] - ret[q][1]) < 0.05) {
                        pp[j][2] = ret[q][2];
                    }
                    tt[j][0] = tr[i].uv[j][0];
                    tt[j][1] = tr[i].uv[j][1];
                }
                rm_drop(out, tr[i].id);
                rm_tri(out, tr[i].id, -1, tr[i].bt != NULL ? tr[i].bt->cull : 1, tr[i].rgb, pp[0], pp[1], pp[2], tt[0], tt[1], tt[2], 0, 0);
            }
        }
        /* `ledge=1`: a roof slope that looks to the back and ends short of the back wall, at the wall's top (a
         * wing's roof behind a parapet): a level ledge from the slope's foot back to the wall, at that height, in the
         * wall's plain stone; seen from behind the roof then meets the wall, and nobody looks down into the house */
        if (rm_optf(opt, "ledge", 0) != 0.0) {
            const double tu = plain < 1e29 ? (plain - xa) / (xb - xa) : 0.5;

            for (i = 0; i < n0; i++) {
                double ylo = 1e30, ex0 = 1e30, ex1 = -1e30, ez = 0.0;
                int nlow = 0;

                if (!(tr[i].n[1] > 0.25 && tr[i].n[1] < 0.98 && tr[i].n[2] < -0.3)) {
                    continue;
                }
                for (j = 0; j < 3u; j++) {
                    ylo = tr[i].p[j][1] < ylo ? tr[i].p[j][1] : ylo;
                }
                for (j = 0; j < 3u; j++) {
                    if (tr[i].p[j][1] < ylo + 0.3) {
                        ex0 = tr[i].p[j][0] < ex0 ? tr[i].p[j][0] : ex0;
                        ex1 = tr[i].p[j][0] > ex1 ? tr[i].p[j][0] : ex1;
                        ez = tr[i].p[j][2];
                        nlow++;
                    }
                }
                if (nlow < 2 || ex1 - ex0 < 0.5) {
                    continue;               /* (the slope's foot is a corner, not an edge) */
                }
                for (q = 0; q < nq; q++) {
                    double qx0l = 1e30, qx1l = -1e30, qtop = -1e30, zq = quad[q][0][2], a0, a1;

                    if (qside[q]) {
                        continue;
                    }
                    for (j = 0; j < 4u; j++) {
                        qx0l = quad[q][j][0] < qx0l ? quad[q][j][0] : qx0l;
                        qx1l = quad[q][j][0] > qx1l ? quad[q][j][0] : qx1l;
                        qtop = quad[q][j][1] > qtop ? quad[q][j][1] : qtop;
                    }
                    a0 = ex0 > qx0l ? ex0 : qx0l;
                    a1 = ex1 < qx1l ? ex1 : qx1l;
                    if (a1 - a0 < 0.5 || zq > ez - 0.5 || fabs(qtop - ylo) > 1.5) {
                        continue;           /* (not under it, not behind it, or not as tall as its foot) */
                    }
                    {
                        const double tv = (yb - ylo) / (yb - y0) + 0.5 / Hm;
                        double c0[3] = { a0, ylo, zq }, c1[3] = { a1, ylo, zq }, c2[3] = { a1, ylo, ez }, c3[3] = { a0, ylo, ez };
                        double tt[2] = { tu, tv };

                        /* (looking up) */
                        rm_tri(out, src, out->ntex, 1, white, c0, c2, c1, tt, tt, tt, 0, 0);
                        rm_tri(out, src, out->ntex, 1, white, c0, c3, c2, tt, tt, tt, 0, 0);
                    }
                }
            }
        }
        if (out->fail || out->ntri == first) {
            free(px);
            goto done;
        }
        out->tex[out->ntex].w = Wm;
        out->tex[out->ntex].h = Hm;
        out->tex[out->ntex].rgba = px;
        out->ntex++;
    }
done:
    if (!out->fail) {
        rm_seal(b, nb, out, 0.7);
    }
    free(tr);
    free(ed);
    free(minz);
    free(quad);
    free(qside);
}
